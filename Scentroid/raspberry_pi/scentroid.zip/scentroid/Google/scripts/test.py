from config import config_current_id

print config_current_id
