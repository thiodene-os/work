/*
 * Copyright (C) 2004-2006 Atmel Corporation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#ifndef _UAPI__ASM_TYPES_H
#define _UAPI__ASM_TYPES_H

#include "../../asm-generic/int-ll64.h"

#endif /* _UAPI__ASM_TYPES_H */
