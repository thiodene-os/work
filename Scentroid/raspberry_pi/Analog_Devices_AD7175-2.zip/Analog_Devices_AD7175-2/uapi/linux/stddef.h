#include "../../linux/compiler.h"

#ifndef __always_inline
#define __always_inline inline
#endif
