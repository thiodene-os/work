#ifndef _LINUX_BYTEORDER_LITTLE_ENDIAN_H
#define _LINUX_BYTEORDER_LITTLE_ENDIAN_H

#include "../../uapi/linux/byteorder/little_endian.h"

#include "generic.h"
#endif /* _LINUX_BYTEORDER_LITTLE_ENDIAN_H */
