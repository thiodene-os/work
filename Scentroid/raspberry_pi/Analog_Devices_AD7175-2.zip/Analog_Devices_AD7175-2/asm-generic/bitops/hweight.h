#ifndef _ASM_GENERIC_BITOPS_HWEIGHT_H_
#define _ASM_GENERIC_BITOPS_HWEIGHT_H_

#include "arch_hweight.h"
#include "const_hweight.h"

#endif /* _ASM_GENERIC_BITOPS_HWEIGHT_H_ */
