from AD7175 import ADC7175

adc = ADC7175()
adc.init()
adc.reset()
adc.enable_channel(ADC7175.CH0, True, ADC7175.AIN0, None)
adc.enable_channel(ADC7175.CH1, True, ADC7175.AIN1, None)
adc.enable_channel(ADC7175.CH2, True, ADC7175.AIN2, None)
adc.enable_channel(ADC7175.CH3, True, ADC7175.AIN3, None)
adc.enable_channel(ADC7175.CH4, True, ADC7175.AIN4, None)
adc.enable_channel(ADC7175.CH5, True, ADC7175.AIN5, None)
adc.enable_channel(ADC7175.CH6, True, ADC7175.AIN6, None)
adc.enable_channel(ADC7175.CH7, True, ADC7175.AIN7, None)
adc.enable_channel(ADC7175.CH8, True, ADC7175.AIN8, None)
adc.enable_channel(ADC7175.CH9, True, ADC7175.AIN9, None)
adc.enable_channel(ADC7175.CH10, True, ADC7175.AIN10, None)
adc.enable_channel(ADC7175.CH11, True, ADC7175.AIN11, None)
adc.enable_channel(ADC7175.CH12, True, ADC7175.AIN12, None)
adc.enable_channel(ADC7175.CH13, True, ADC7175.AIN13, None)
adc.enable_channel(ADC7175.CH14, True, ADC7175.AIN14, None)
adc.enable_channel(ADC7175.CH15, True, ADC7175.AIN15, None)
adc.set_filter_speed(ADC7175.FILTER0, ADC7175.SPS_500)
#adc.set_filter_speed(ADC7175.FILTER0, ADC7175.SPS_1000)
adc.set_setup_coding_mode(ADC7175.SETUP0, ADC7175.UNIPOLAR)
#adc.set_data_mode(ADC7175.CONTINUOUS_READ_MODE)
adc.set_data_mode(ADC7175.CONTINUOUS_CONVERSION_MODE)

count = 0
data = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
while count < 100:
    channel, ready = adc.get_status()
    if ready:
    	data[channel].append(adc.get_data())
        count += 1
for i in range(16):
    print("AIN%i: %s" % (i, data[i]))
