from kivy.graphics import Color, Ellipse, Line, InstructionGroup, Rectangle, Bezier
from kivy.properties import ListProperty, NumericProperty, ObjectProperty, StringProperty
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.uix.popup import Popup
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.clock import Clock
import re
from kivy_classes.ElementsStylesStrings import lock_image_left, lock_image_right, lock_button_source, lock_line_top, lock_line_bot, welcome_text_input_border_color, welcome_text_input_hint_text, welcome_title_text, welcome_lock_button, welcome_login_button, main_button_source


class MyTextInput(TextInput):
    hint_text = StringProperty(welcome_text_input_hint_text)
    color = StringProperty(welcome_text_input_border_color)
    pat = re.compile('[^0-9a-zA-Z]')

    def insert_text(self, substring, from_undo=False):
        if substring != '.':
            pat = self.pat
            if '.' in self.text:
                s = re.sub(pat, '', substring)
            else:
                s = '.'.join([re.sub(pat, '', s) for s in substring.split('.', 1)])
            return super(MyTextInput, self).insert_text(s, from_undo=from_undo)


class CircleBar(Widget):
    value = 0
    circle1 = None
    circle2 = None
    circle3 = None
    circle1_color = None
    circle2_color = None
    circle3_color = None

    def __init__(self, **kwargs):
        super(CircleBar, self).__init__(**kwargs)
        self.declaration()

    def declaration(self):
        with self.canvas:
            self.canvas.clear()

            # color for the inner line of the loading circle bar
            self.circle1_color = Color(1, 1, 1)
            self.circle1 = Line(ellipse=(300, 100, 200, 200, 0, 0), width=0)
            # color for the center line of the loading circle bar
            self.circle2_color = Color(0, 1, 1)
            self.circle2 = Line(ellipse=(299, 99, 201, 201, 0, 0), width=0)
            # color for the outer line of the loading circle bar
            self.circle3_color = Color(1, 1, 1)
            self.circle3 = Line(ellipse=(250, 50, 300, 300, 0, 0), width=0)

    def init(self):
        self.circle1.width = 1.5
        self.circle3.width = 1.5
        self.circle1.ellipse = (300, 100, 200, 200, 0, 360)
        self.circle3.ellipse = (290, 90, 220, 220, 0, 360)

    def draw(self):
        self.circle2.width = 4
        self.circle2.ellipse = (295, 95, 210, 210, 0, self.value * 3.6)

    def test(self):
        self.circle1.width = 1.5
        self.circle2.width = 4
        self.circle3.width = 1.5
        self.circle1.ellipse = (300, 100, 200, 200, 0, 360)
        self.circle2.ellipse = (295, 95, 210, 210, 0, 360)
        self.circle3.ellipse = (290, 90, 220, 220, 0, 360)

    def set_value(self, value):
        # Update the progress bar value
        self.value = value
        # Draw all the elements
        self.draw()

    def hide_circles(self):
        self.circle1.width = 0.001
        self.circle2.width = 0.001
        self.circle3.width = 0.001
        self.circle1.ellipse = (300, 100, 200, 200, 0, 0)
        self.circle2.ellipse = (295, 95, 210, 210, 0, 0)
        self.circle3.ellipse = (290, 90, 220, 220, 0, 0)

    def show_circles(self):
        self.circle1.width = 1.5
        self.circle2.width = .001
        self.circle3.width = 1.5
        self.circle1.ellipse = (300, 100, 200, 200, 0, 360)
        self.circle2.ellipse = (295, 95, 210, 210, 0, 0)
        self.circle3.ellipse = (290, 90, 220, 220, 0, 360)


class LoadingBar(Widget):
    value = 0
    load_bar_color = None
    load_bar = None
    bot_line = None
    top_line = None
    left_line = None
    right_line = None

    def __init__(self, **kwargs):
        super(LoadingBar, self).__init__(**kwargs)
        self.draw()

    def draw(self):
        self.pos = [100, 150]
        self.size = [600, 50]
        with self.canvas:
            self.canvas.clear()

            # color for boarding bar
            self.load_bar_color = Color(1, 1, 1)
            self.load_bar = Rectangle(pos=[100, 200], size=[self.value * 6, 50])

            # color for borders of the loading bar
            Color(1, 1, 1)
            self.bot_line = Line(points=(self.pos[0] - 1, self.pos[1], self.pos[0] + self.size[0], self.pos[1]))
            self.top_line = Line(points=(self.pos[0] - 1, self.pos[1] + self.size[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]))
            self.left_line = Line(points=(self.pos[0], self.pos[1], self.pos[0], self.pos[1] + self.size[1]))
            self.right_line = Line(points=(self.pos[0] + self.size[0], self.pos[1], self.pos[0] + self.size[0], self.pos[1] + self.size[1]))

    def redraw(self):
        self.load_bar.size = [self.value * 6, 40]

    def set_color(self, color):
        self.load_bar_color = color

    def set_value(self, value):
        # Update the progress bar value
        self.value = value
        # Draw all the elements
        self.redraw()


class UnlockButton(ButtonBehavior, Image):
    angle = NumericProperty(0)
    img = StringProperty(lock_button_source)

    def __init__(self, **kwargs):
        super(UnlockButton, self).__init__(**kwargs)


class LockButton(ButtonBehavior, Image):
    img = StringProperty(welcome_lock_button)


class LoginButton(ButtonBehavior, Image):
    img = StringProperty(welcome_login_button)


class MenuButton(ButtonBehavior, Image):
    img = StringProperty(main_button_source)


class LockLineTop(Widget):
    def __init__(self, **kwargs):
        super(LockLineTop, self).__init__(**kwargs)
        self.ig = InstructionGroup()
        self.color = lock_line_top
        self.line = Line(points=[400, 287.5, 400, 500], width=1)
        self.ig.add(self.color)
        self.ig.add(self.line)
        self.canvas.add(self.ig)


class LockLineBot(Widget):
    def __init__(self, **kwargs):
        super(LockLineBot, self).__init__(**kwargs)
        self.ig = InstructionGroup()
        self.color = lock_line_bot
        self.line = Line(points=[400, 0, 400, 192.5], width=1)
        self.ig.add(self.color)
        self.ig.add(self.line)
        self.canvas.add(self.ig)


class ImageRight(Image):
    img = StringProperty(lock_image_right)


class ImageLeft(Image):
    img = StringProperty(lock_image_left)
