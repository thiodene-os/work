from kivy.graphics import Color

main_background = './images/background.png'

lock_image_left = './images/background_left.png'
lock_image_right = './images/background_right.png'
lock_button_source = './icons/123/s_blue_circle.png'
# lock_line_top = Color(.93, .38, .31, 1)
# lock_line_bot = Color(.99, .85, 0, 1)
lock_line_top = Color(0, .66, 1, 1)
lock_line_bot = Color(0, .66, 1, 1)

welcome_lock_button = './icons/123/lock_circle.png'
welcome_login_button = './icons/123/s_circle.png'
welcome_text_input_border_color = '#3f92db'
welcome_error_login_text_color = .86, .08, .24, 1
welcome_text_input_back_color = 0, 0, 0, .6
welcome_title_text = 'WELCOME'
welcome_text_input_hint_text = 'Please, enter the ID number to proceed'
welcome_error_login_text = 'Incorrect ID, please enter correct ID'

loading_title_text = 'Greetings '
loading_message_text = 'Please wait while system is getting ready'
loading_load_text_flush_text = 'Flushing: '
loading_load_text_absolute_text = 'Saving absolute zero values: '
loading_load_text_relative_text = 'Saving relative zero values: '
loading_load_text_finish_text = 'Finished'
# loading bar and border colors can not be set in here, in order to change them find LoadingBar in ElementsMisc.py and set the color values in there

main_button_source = './icons/123/start_circle.png'
main_intro_text = 'System is ready, please press the button to proceed'
main_inhale_text = 'Get ready to exhale'
main_inhale_end_text = 'Exhale'
main_exhale_text = 'Please, exhale into the tube'
main_exhale_pass_text = 'Success'
main_exhale_failed_text = 'Something went wrong, please try again'
main_exhale_end_text = 'Good job'
# loading circle bar and border colors can not be set in here, in order to change them find CircleBar in ElementsMisc.py and set the color values in there

save_load_saving = 'Saving data : '
save_load_flushing = 'Flushing: '
save_load_title_text = 'Success'
save_load_message_text = 'Please while system analyze and save data gathered'
