config_flush_time = 1
config_absolute_time = 1
config_relative_time = 1
config_inhale_time = 1
config_exhale_time = 10
config_current_id = 1
