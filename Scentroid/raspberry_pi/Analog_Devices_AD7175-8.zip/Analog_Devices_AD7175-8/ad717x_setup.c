#include "ad7175_8_regs.h"


/* Create a new fdriver instance */
struct ad717x_device my_ad7175_8;
struct ad717x_device *ad7175_8_handler = &my_ad7175_8;

/* Other variables */

long timeout = 1000;
long ret;
long sample;



/* Initialize the driver instance and use the ad7175_8_regsa array defined in ad7175_8_regs.h */
#define AD7175_8_INIT
AD717X_Setup(ad7175_8_handler, AD7175_8_SLAVE_ID, (ad717x_st_reg *)&ad7175_8_regs,
sizeof(ad7175_8_regs) / sizeof(ad7175_8_regs[0]));

/* Redad data from the ADC */
ret = AD717X_WaitForReady(ad7175_8_handler, timeout);
if (ret < 0)
  /* Something went wrong, check the value of ret! */

ret = AD717X_ReadData(ad7175_8_handler, &sample);
if (ret <0)
  /* Something went wrong , check the value of ret! */















