<?php

require_once 'app/module/core/router.php';
router::process("security/user","signin",$_REQUEST);
//echo file_get_contents(Parser::$baseURL."do/page/page.home");
