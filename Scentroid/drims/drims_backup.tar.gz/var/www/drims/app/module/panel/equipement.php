<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
require_once realpath(dirname(__FILE__)).'/sample.php';
/* ORM container for equipements */
class equipement extends entity{
		public $name;
		public $sn;
		public $secret; #ALTER TABLE `equipement` ADD `secret` VARCHAR(255) NOT NULL AFTER `sn`;
        public $status;
		public $calibratedate;
        public $company;
        public $category;  //ALTER TABLE `equipement` ADD `category` VARCHAR(255) NULL AFTER `company`;
        public $extra;
		public $creator;
		public $createdat;
		public static function load($id, $condition = null, $join=null){
		
			$obj= parent::load($id, $condition);
			$obj= arrayit($obj);
		
			for($i=0; $i<count($obj); $i++){
				$obj[$i]->extra= json_decode($obj[$i]->extra);
			}
			if(count($obj) ==1 ){
				return $obj[0];
			}else
				return $obj;
		
		
		}
		public function save(){
			$this->extra= json_encode($this->extra);
			parent::save();
			$this->extra= json_decode($this->extra);
				
		}
		public function getStatus($ls){ //$lastSample
			if($this->extra->transmitrate){
				if($ls){
					if(time()-$ls->sampledat > 2* ($this->extra->transmitrate )){
						return "danger";
					}else if(time()-$ls->sampledat > 1.2* ($this->extra->transmitrate )){
						return "warning";
					}else 
						return "success";
				}else 
					return "warning";
			}else{
				return "success";
			}
		}
		
}