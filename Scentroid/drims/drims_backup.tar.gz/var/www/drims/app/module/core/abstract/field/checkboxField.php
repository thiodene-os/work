<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
class checkboxField extends field{
	
	public $options;
	
	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		$this->options= $values;
		
	}
	public function render(){
		$str.= "\n";
		$str .= '<div class="form-group">';
		$str.= '<label for="field_'.$this->id.'" class="col-xs-2 control-label">'.l($this->label).'</label>';
		for($i=0; $i<count($this->options); $i++){
			$key=$this->options[$i];
			if($this->value == $key){
				$str.='<label class="checkbox-inline"><input  type="checkbox" value="'.$key.'" name="'.$this->name.'[]" checked="checked"> '.l($key).' </label>';
			}else{
				$str.='<label class="checkbox-inline"><input type="checkbox"  value="'.$key.'" name="'.$this->name.'[]" > '.l($key).' </label>'; 
			}
		}
		$str .= "</div>\n";
		$str.= "\n";
		return $str."\n";
	}
}