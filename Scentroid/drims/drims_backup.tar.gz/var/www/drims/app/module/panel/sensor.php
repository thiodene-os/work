<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/* sensor ORM Handler */
class sensor extends entity{
		public $name;
		public $equipement; 
		public $type;
		public $packet_id;
		public $dataunit;
		public $calibrationfactors;
		public $alarm_max_value;
		public $alarm_value_total;
		public $alarm_value_num;
		public $extra;
		public $creator;
		public $createdat;
		public static function load($id, $condition = null, $join=null){
		
			$obj= parent::load($id, $condition);
			$obj= arrayit($obj);
		
			for($i=0; $i<count($obj); $i++){
				$obj[$i]->extra= json_decode($obj[$i]->extra);
				$obj[$i]->calibrationfactors= json_decode($obj[$i]->calibrationfactors);
				$obj[$i]->type= $obj[$i]->getType();
			}
			if(count($obj) ==1 ){
				return $obj[0];
			}else
				return $obj;
		
		
		}
		public function save(){
			$this->type= $this->getType();
			$this->extra= json_encode($this->extra);
			$this->calibrationfactors= json_encode($this->calibrationfactors);
			parent::save();
			$this->extra= json_decode($this->extra);
			$this->calibrationfactors= json_decode($this->calibrationfactors);
				
		}
		public static function getByName($name, $eqid) {
			return sensor::load ( null, array (
					"`name`='" . $name . "'",
					"`equipement`='" . $eqid . "'"
			) );
		}

		public static function getByLocation($location, $eqid) {
            return arrayit(sensor::load ( null, array (
                "`packet_id` LIKE '%" . $location . "'",
                "`equipement`='" . $eqid . "'"
            )));
        }

        public static function getAllLocations($eqid) {
		    $locations = array();
		    $sensors = sensor::load(null, array("`equipement`='" . $eqid . "'"));
		    $sensors = arrayit($sensors);
		    for($i=0; $i< count($sensors); $i++){
		        if( $sensors[$i]->packet_id && !is_numeric($sensors[$i]->packet_id[strlen($sensors[$i]->packet_id)-1])){
		            $locations[] = $sensors[$i]->packet_id[strlen($sensors[$i]->packet_id)-1];
                }
            }
            sort($locations);
            return array_unique($locations);
        }

		public  function getType(){
			return sensor::getTypeFromName($this->name);
		}
		public static function getTypeFromName($name){
			$name =strtolower($name);
			if(strstr($name, "humidity") !== False)
				$type = "humidity";
			else if(strstr($name, "temperature") !== False)
				$type = "temperature";
			else if(strstr($name, "pid") !== False)
				$type = "pid";
			else
				$type= "chemical";
			return $type;
		}
		/* PID coefficients for sensors */
		public static $pids = array(
			"Isobutylene"=>100
			,"Acetaldehyde"=>21
			,"Acetic Acid"=>3
			,"Acetic Anhydride"=>25
			,"Acetone"=>140
			,"Acrolein"=>25
			,"Acrylic Acid"=>36
			,"Allyl alcohol"=>48
			,"Allyl chloride"=>22
			,"Ammonia"=>12
			,"Amyl acetate"=>56
			,"Arsine"=>40
			,"Asphalt"=>100
			,"Benzaldehyde"=>117
			,"Benzene"=>200
			,"Benzenethiol"=>143
			,"Benzonitrile"=>141
			,"Benzyl alcohol"=>80
			,"Benzyl chloride"=>182
			,"Benzyl formate"=>130
			,"Biphenyl"=>250
			,"Bis"=>33
			,"Bromine"=>5
			,"Bromobenzene"=>143
			,"Bromoethane"=>20
			,"Bromoethyl methyl ether"=>40
			,"Bromoform"=>36
			,"Bromopropane"=>77
			,"BTEX"=>200
			,"Butadiene"=>120
			,"Butadiene diepoxide"=>25
			,"Butane n-"=>2
			,"Butanol 1-"=>25
			,"Butene 1-"=>77
			,"Butoxyethanol"=>91
			,"Butyl acetate n-"=>41
			,"Butyl acrylate n-"=>67
			,"Butyl lactate"=>40
			,"Butyl mercaptan"=>185
			,"Butylamine 2-"=>111
			,"Butylamine n-"=>100
			,"Camphene"=>222
			,"Carbon disulfide"=>71
			,"Carbon tetrabromide"=>33
			,"Carvone R-"=>100
			,"Chlorine dioxide"=>100
			,"Chloro-1 3-butadiene 2-"=>30
			,"Chlorobenzene"=>220
			,"Chloroethanol 2-"=>10
			,"Chloroethyl methyl ether 2-"=>40
			,"Chlorotoluene  p-"=>200
			,"Chlorotoluene o-"=>220
			,"Chlorotrifluoroethylene"=>100
			,"Citral"=>100
			,"Citronellol"=>100
			,"Cresol m-"=>95
			,"Cresol o-"=>95
			,"Cresol p-"=>95
			,"Crotonaldehyde"=>100
			,"Cumene"=>170
			,"Cyclohexane"=>77
			,"Cyclohexanol"=>34
			,"Cyclohexanone"=>91
			,"Cyclohexene"=>133
			,"Cyclohexylamine"=>102
			,"Cyclopentane"=>25
			,"Decane n-"=>96
			,"Diacetone alcohol"=>125
			,"Dibenzoyl peroxide"=>125
			,"Dibromochloromethane"=>10
			,"Dibromoethane 1 2-"=>50
			,"Dibutyl hydrogen phosphate"=>25
			,"Dichloro-1-propene 2 3-"=>70
			,"Dichloroacetylene"=>20
			,"Dichlorobenzene o-"=>200
			,"Dichloroethene 1 1-"=>105
			,"Dichloroethylene 1 2- "=>133
			,"Dichloromethane"=>3
			,"Dicyclopentadiene"=>110
			,"Diesel Fuel"=>130
			,"Diethyl ether"=>110
			,"Diethyl maleate"=>50
			,"Diethyl phthalate"=>100
			,"Diethyl sulphate"=>33
			,"Diethyl sulphide"=>180
			,"Diethylamine"=>100
			,"Diethylaminoethanol 2-"=>40
			,"Diethylaminopropylamine 3-"=>100
			,"Dihydrogen selenide"=>100
			,"Dihydroxybenzene 1 2"=>100
			,"Dihydroxybenzene 1 3"=>100
			,"Diisobutylene"=>156
			,"Diisopropyl ether"=>150
			,"Diisopropylamine"=>140
			,"Diketene"=>45
			,"Dimethoxymethane"=>71
			,"Dimethyl cyclohexane  1 2-"=>95
			,"Dimethyl disulphide"=>435
			,"Dimethyl ether"=>80
			,"Dimethyl phthalate"=>100
			,"Dimethyl sulphide"=>200
			,"Dimethylacetamide N N-"=>75
			,"Dimethylamine"=>70
			,"Dimethylaminoethanol"=>70
			,"Dimethylaniline NN-"=>167
			,"Dimethylbutyl acetate"=>60
			,"Dimethylethylamine NN-"=>125
			,"Dimethylformamide"=>110
			,"Dimethylheptan-4-one  2 6-"=>125
			,"Dimethylhydrazine 1 1-"=>100
			,"Dinitrobenzene  m-"=>33
			,"Dinitrobenzene  p-"=>20
			,"Dinonyl phthalate"=>100
			,"Dioxane 1 2-"=>67
			,"Dipentene"=>110
			,"Diphenyl ether"=>125
			,"Disulphur dichloride"=>33
			,"Di-tert-butyl-p-cresol"=>100
			,"Divinylbenzene"=>250
			,"Dodecanol"=>110
			,"Epichlorohydrin"=>15
			,"Epoxypropyl isopropyl ether 2 3-"=>90
			,"Ethanol"=>10
			,"Ethanolamine"=>33
			,"Ethoxy-2-propanol 1-"=>50
			,"Ethoxyethanol 2-"=>3
			,"Ethoxyethyl acetate 2-"=>33
			,"Ethyl (S)-(-)-lactate"=>33
			,"Ethyl acetate"=>28
			,"Ethyl acrylate"=>50
			,"Ethyl amine"=>100
			,"Ethyl benzene"=>185
			,"Ethyl butyrate"=>105
			,"Ethyl cyanoacrylate"=>67
			,"Ethyl decanoate"=>56
			,"Ethyl formate"=>3
			,"Ethyl hexanoate"=>38
			,"Ethyl hexanol"=>67
			,"Ethyl hexyl acrylate 2-"=>100
			,"Ethyl mercaptan"=>145
			,"Ethyl octanoate"=>40
			,"Ethylene"=>13
			,"Ethylene glycol"=>5
			,"Ethylene oxide"=>7
			,"Ferrocene"=>125
			,"Formamide"=>50
			,"Furfural"=>70
			,"Furfuryl alcohol"=>50
			,"Gasoline vapors"=>95
			,"Gasoline vapors 92 octane"=>125
			,"Germane"=>10
			,"Glutaraldehyde"=>111
			,"Heptan-2-one"=>140
			,"Heptan-3-one"=>133
			,"Heptane n-"=>50
			,"Hexamethyldisilazane"=>10
			,"Hexamethyldisiloxane"=>350
			,"Hexan-2-one"=>125
			,"Hexane n-"=>25
			,"Hexene 1-"=>110
			,"Hydrazine"=>33
			,"Hydrogen peroxide"=>25
			,"Hydrogen sulfide"=>25
			,"Hydroxypropyl acrylate 2-"=>67
			,"Iminodi"=>110
			,"Iminodiethanol"=>60
			,"Indene"=>220
			,"Iodine"=>667
			,"Iodoform"=>67
			,"Iodomethane"=>250
			,"Isoamyl acetate"=>60
			,"Isobutane"=>15
			,"Isobutanol"=>30
			,"Isobutyl acetate"=>45
			,"Isobutyl acrylate"=>80
			,"Isobutyraldehyde"=>80
			,"Isodecanol"=>110
			,"Isononanol"=>67
			,"Isooctane"=>90
			,"Isooctanol"=>60
			,"Isopentane"=>20
			,"Isophorone"=>133
			,"Isoprene"=>140
			,"Isopropanol"=>20
			,"Isopropyl acetate"=>50
			,"Isopropyl chloroformate"=>60
			,"Jet Fuel JP-5"=>150
			,"Jet Fuel JP-8"=>150
			,"Kerosene"=>120
			,"Ketene"=>33
			,"Maleic anhydride"=>50
			,"Mercaptoacetic acid"=>100
			,"Mesitylene"=>300
			,"Methacrylic acid"=>40
			,"Methacrylonitrile"=>20
			,"Methanol"=>1
			,"Methoxyethanol 2-"=>40
			,"Methoxyethoxyethanol 2-"=>70
			,"Methoxypropan-2-ol"=>33
			,"Methoxypropyl acetate"=>80
			,"Methyl acetate"=>20
			,"Methyl acrylate"=>30
			,"Methyl bromide"=>50
			,"Methyl cyanoacrylate"=>20
			,"Methyl ethyl ketone"=>130
			,"Methyl ethyl ketone peroxides"=>125
			,"Methyl isobutyl ketone"=>125
			,"Methyl isothiocyanate"=>167
			,"Methyl mercaptan"=>140
			,"Methyl methacrylate"=>60
			,"Methyl propyl ketone"=>130
			,"Methyl salicylate"=>80
			,"Methyl sulphide"=>200
			,"Methyl t-butyl ether"=>125
			,"Methyl-2-propen-1-ol  2-"=>90
			,"Methyl-2-pyrrolidinone N-"=>110
			,"Methyl-5-hepten-2-one 6-"=>125
			,"Methylamine"=>70
			,"Methylbutan-1-ol 3-"=>30
			,"Methylcyclohexane"=>90
			,"Methylcyclohexanol 4-"=>40
			,"Methylcyclohexanone 2-"=>100
			,"Methylheptan-3-one 5-"=>133
			,"Methylhexan-2-one 5-"=>133
			,"Methylhydrazine"=>80
			,"Methyl-N-2"=>33
			,"Methylpent-3-en-2-one"=>140
			,"Methylpentan-2-ol"=>40
			,"Methylpentane-2 4-diol"=>25
			,"Methylstyrene"=>200
			,"Mineral oil"=>125
			,"Mineral spirits"=>125
			,"Naphthalene"=>230
			,"Nitric oxide"=>15
			,"Nitroaniline 4-"=>125
			,"Nitrobenzene"=>60
			,"Nitrogen dioxide"=>10
			,"Nitrogen trichloride"=>100
			,"Nonane n-"=>80
			,"Norbornadiene 2 5-"=>167
			,"Octachloronaphthalene"=>100
			,"Octane n-"=>60
			,"Octene 1-"=>140
			,"Oxydiethanol 2 2-"=>25
			,"Paraffin wax fume"=>100
			,"Paraffins"=>105
			,"Pentacarbonyl iron"=>100
			,"Pentan-2-one"=>125
			,"Pentan-3-one"=>125
			,"Pentandione"=>133
			,"Pentane n-"=>15
			,"Peracetic acid"=>50
			,"Petroleum ether"=>110
			,"Phenol"=>85
			,"Phenyl propene 2-"=>230
			,"Phenyl-2 3-epoxypropyl ether"=>125
			,"Phenylenediamine p-"=>167
			,"Phosphine"=>50
			,"Picoline 3-"=>110
			,"Pinene"=>315
			,"Pinene alpha"=>315
			,"Piperidine"=>110
			,"Prop-2-yn-1-ol"=>80
			,"Propan-1-ol"=>20
			,"Propane-1 2-diol"=>10
			,"Propene"=>70
			,"Propionaldehyde"=>60
			,"Propionic acid"=>15
			,"Propyl acetate n-"=>40
			,"Propylene oxide"=>15
			,"Propyleneimine"=>80
			,"Pyridine"=>133
			,"Pyridylamine 2-"=>125
			,"Styrene"=>230
			,"Terphenyls"=>167
			,"Terpinolene"=>210
			,"Tert-butanol"=>40
			,"Tetrabromoethane"=>50
			,"Tetracarbonylnickel"=>100
			,"Tetrachloroethylene"=>140
			,"Tetrachloronaphthalenes"=>100
			,"Tetraethyl orthosilicate"=>50
			,"Tetrafluoroethylene"=>100
			,"Tetrahydrofuran"=>65
			,"Tetramethyl succinonitrile "=>100
			,"Therminol"=>100
			,"Toluene"=>200
			,"Toluene-2 4-diisocyanate"=>60
			,"Toluenesulphonyl chloride p-"=>33
			,"Toluidine o-"=>200
			,"Tributyl phosphate"=>20
			,"Tributylamine"=>100
			,"Trichlorobenzene"=>180
			,"Trichloroethylene"=>150
			,"Trichlorophenoxyacetic acid"=>100
			,"Triethylamine"=>110
			,"Trimethylamine"=>200
			,"Trimethylbenzene"=>300
			,"Trimethylbenzene mixtures"=>300
			,"Turpentine"=>167
			,"Undecane"=>110
			,"Vinyl acetate"=>90
			,"Vinyl bromide"=>100
			,"Vinyl chloride"=>50
			,"Vinyl-2-pyrrolidinone"=>110
			,"Xylene m-"=>230
			,"Xylene mixed isomers"=>230
			,"Xylene o-"=>167
			,"Xylene p-"=>180
			,"Xylidine"=>140
				
		);
	public static $special_sensors= array(
		"Chemical",
		"Carbon Dioxide  (high concentration)",
		"Carbon Dioxide (low concentration)",
		"Carbon Monoxide (low concentration)",
		"Carbon Monoxide  (high concentration)",
		"Chlorine",
		"Ethylene Oxide ",
		"Hydrogen",
		"Hydrogen Chloride",
		"Hydrogen Cyanide",
		"Ammonia",
		"Ozone and Nitrogen Dioxide",
		"Phosphine (low concentration)",
		"Phosphine (high concentration)",
		"Hydrogen Sulfide (ppb)",
		"Hydrogen Sulfide (ppm)",
		"Nitrogen Oxide",
		"Carbon Monoxide and Hydrogen Sulfide",
		"Ethanol",
		"Methane (LEL)",
		"Nitric Oxide (low concentration)",
		"Nitric Oxide (high concentration)",
		"Nitrogen Dioxide (low concentration)",
		"Nitrogen Dioxide (high concentration)",
		"Oxygen 0-20% (0.10%)",
		"Oxygen 0-100% (1%)",
		"Total VOCs (ppb) - PID",
		"Total VOCs (ppm) - PID",
		"Sulfur Dioxide (high concentration)",
		"Sulfur Dioxide (low concentration)"
		);
	
}