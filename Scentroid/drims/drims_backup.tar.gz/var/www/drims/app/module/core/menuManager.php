<?php
require_once(realpath(dirname(__FILE__))."/abstract/entity.php");
require_once(realpath(dirname(__FILE__))."/moduleManager.php");

class menuManager extends module{
	
	
}