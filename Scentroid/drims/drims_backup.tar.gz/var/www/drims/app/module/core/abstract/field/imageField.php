<?php
require_once(realpath(dirname(__FILE__)."/..")."/field.php");
require_once(realpath(dirname(__FILE__))."/fileField.php");
class imageField extends fileField{
	
}