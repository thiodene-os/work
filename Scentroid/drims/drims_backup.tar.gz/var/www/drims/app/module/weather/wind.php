<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/*
 * Wind data container.
 */
class wind  extends entity{
	public $id;
	public $location;
	public $chill;
	public $speed;
	public $direction;
	public $createdat;

}