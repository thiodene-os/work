<?php
class Parser {
	public static $baseURL= "http://drims.scentroid.com/";
	//public static $baseURL= "http://artaveh.com/panel/";
	public static $obj= null;
	
	public  $ajax = false;
	public  $mobile= false;
	public  $sms= false;
	public static $appname= "sims";
	public static $vars= array();
	public static $blocks= array();
	public static function get(){
		if(self::$obj == null){
			self::$obj = new Parser();
			$baseurl = self::$baseURL;
		}
		return self::$obj;
	}
	private  function Parser(){
	
	}
	public function setVar($key,$value){
		self::$vars[$key] = $value;
	} 
	
	public function getVar($key){
		return self::$vars[$key];
	}
	
	public  function parse($url){
		//$this->insert("usernav", "usernav");
		
		foreach (self::$vars as $key => $value)
			$$key = $value;
	
		ob_start();
		$text = file_get_contents(realpath(dirname(__FILE__))."/../../../theme/".self::$appname."/".$url.".php");
		foreach (self::$blocks as $key => $value)
			$text = str_replace("{sh:".$key."}", $value, $text);
		
		eval('?>' . $text . '<?php;');
	
		/*
		if(self::$obj->ajax== true){
			
		}else if(self::$obj->mobile == true){
			header('Content-Type: text/json; charset=utf8');
			include(realpath(dirname(__FILE__))."/../View/JSON/".$url.".php");
		}
		
		*/
		
		$content = ob_get_contents();
		$content = preg_replace('~\{sh:.*?\}~', '', $content);
		
		ob_end_clean();
		
		$this->setVar("baseurl", self::$baseURL);
		
		echo  str_replace("{baseurl}",self::$baseURL,$content);
		return;
	}
	public static function icon($name, $size = 1, $effect){
		$icon = array(
			"Advertisment"=>"bullhorn",
			"Diagram"=>"sitemap",
			"Question"=>"question-sign",
			"Answer"=>"info-sign",
			"Gift"=>"gift",
			"Money"=>"money",
			"Login"=>"signout",
			"Logout"=>"signin",
			"ForgetPassword"=>"key",
			"Medical"=>"stethoscope",
			"Legal"=>"legal",
			"Email"=>"envelope",
			"User"=>"user",
			"Payment"=>"credit-card",
			"Saved"=>"save",
			"Star" =>"asterisk",
			"Award"=>"trophy"
				
				
		);
		//
		if($size==1){
			$s = "";
		}elseif($size==2){
			$s = "icon-2x";
		}elseif($size==3){
			$s = "icon-3x";
		}elseif($size==4){
			$s = "icon-4x";
		}
	return "<i class='icon-".$icon[$name]." ".$s."' ></i>";		
	}
	public function redirect($url,$message=null){
		$url = str_replace("{baseurl}", self::$baseURL, $url);
		if($this->mobile == true){
			$obj= new stdClass();
			$obj->type="redirect";
			$obj->message = $message;
			$obj->url= $url;
			echo json_encode($obj);
		}else{
			header("Location: ".$url);
		}
	}
	public static function insert($key, $file){
		self::$blocks[$key] = file_get_contents(realpath(dirname(__FILE__))."/../../../theme/".self::$appname."/".$file.".php");
	}
}

?>