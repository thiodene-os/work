<?php
require_once realpath(dirname(__FILE__)).'/Date.php';
date_default_timezone_set("UTC");
function arrayit($obj){
	if($obj == null){
		return null;
	}
	$out = array();
	if(!is_array($obj)){
		$temp = $obj;
		//$obj= array();
		$out[] = $temp;
	}else 
		$out= $obj;
	
	return $out;
}

function contains($str, $str2){
	if(is_array($str2)){
		$str2 = arrayit($str2);
	}
	for($i=0; $i<count($str2); $i++){
		if(strstr($str, $str2[$i]) !== false){
			return true;
		}
	}
	return false;
}
function startsWith($haystack, $needle) {
	$needles = arrayit($needle);
	foreach($needles as $needle){
		// search backwards starting from haystack length characters from the end
		if( $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== FALSE){
			return true;
		}
	}
	return false;

}
function endsWith($haystack, $needle) {
	$needles = arrayit($needle);
	foreach($needles as $needle){
		// search forward starting from end minus needle length characters
		if( $needle === "" || (($temp = strlen($haystack) - strlen($needle)) >= 0 && strpos($haystack, $needle, $temp) !== FALSE)){
			return true;
		}
	}
	return false;


}

function stddev($sample){
	if(arrayit($sample)){
		$mean = array_sum($sample) / count($sample);
		foreach($sample as $key => $num) $devs[$key] = pow($num - $mean, 2);
		return sqrt(array_sum($devs) / (count($devs) - 1));
	}
}

function arithmetic_mean($a) {
	return array_sum($a)/count($a);
}

function geomean($a) {
	$a= arrayit($a);
	foreach($a as $i=>$n) $mul = $i == 0 ? $n : $mul*$n;
	return pow($mul,1/count($a));
}

function harmonic_mean($a) {
	$sum = 0;
	foreach($a as $n) $sum += 1 / $n;
	return (1/$sum)*count($a);
}

function median($a) {
	sort($a,SORT_NUMERIC);
	return (count($a) % 2) ?
	$a[floor(count($a)/2)] :
	($a[floor(count($a)/2)] + $a[floor(count($a)/2) - 1]) / 2;
}

function modal_score($a) {
	$quant = array();
	foreach($a as $n) $quant["$n"]++;
	$max = 0;
	$mode = 0;
	foreach($quant as $key=>$n) {
		if($n>$max) {
			$max = $n;
			$mode = $key;
		}
	}
	return $mode;
}

function d($timstamp){
	return jDate::date("l j F Y H:i", $timstamp, null, null, 'Asia/Tehran');
}


function ago($ptime)
{
	$etime = time() - $ptime;

	if ($etime < 1)
	{
		return '0 seconds';
	}

	$a = array( 365 * 24 * 60 * 60  =>  'year',
			30 * 24 * 60 * 60  =>  'month',
			24 * 60 * 60  =>  'day',
			60 * 60  =>  'hour',
			60  =>  'minute',
			1  =>  'second'
	);
	$a_plural = array( 'year'   => 'years',
			'month'  => 'months',
			'day'    => 'days',
			'hour'   => 'hours',
			'minute' => 'minutes',
			'second' => 'seconds'
	);

	foreach ($a as $secs => $str)
	{
		$d = $etime / $secs;
		if ($d >= 1)
		{
			$r = round($d);
			return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
		}
	}
}


function removeAttributes($obj, $array){
	if(!is_array($obj)){
		for($i=0; $i<count($array); $i++){
			unset($obj->$array[$i]);
		}	
	}else if(is_array($obj)){
		for($i=0; $i<count($array); $i++){
			for($j=0; $j<count($obj); $j++){
				unset($obj[$j]->$array[$i]);
			}
		}
	}
	
	return $obj;
}

function parseSettings($type){
	$text= file_get_contents(realpath(dirname(__FILE__))."/../settings/setting_keys.csv");
	$text = explode("\n",$text);
	
	if($type == "sensor"){
		for($i=77; $i<87; $i++){
			$line = explode(",", $text[$i]);
			if($line[2] != "RESERVED")
				$output[$line[0]][] = array($line[1], $line[2],$line[3],$line[4], $line[5]);
		}
	}
	if($type == "equipement"){
		for($i=12; $i<77; $i++){
			$line = explode(",", $text[$i]);
			if($line[2] != "RESERVED" && $line[1])
				$output[$line[0]][] = array($line[1], $line[2],$line[3],$line[4], $line[5]);
		}
	}
	return $output;
}
function const2word($const){
	$const= str_replace("_KEY_NAME", "", $const);
	return ucwords(strtolower(str_replace("_", " ", $const)));
}
function setting_key_name_to_id($name){
	$text= file_get_contents(realpath(dirname(__FILE__))."/../settings/setting_keys.csv");
	$text = explode("\n",$text);
	for($i=0; $i<count($text); $i++){
		$line = explode(",", $text[$i]);
		if($line[2]==$name)
			return "".sprintf('%d',$line[3]);
	}
	return "unknown";
}
function setting_key_id_to_name($key_id){
	$text= file_get_contents(realpath(dirname(__FILE__))."/../settings/setting_keys.csv");
	$text = explode("\n",$text);
	//$key_number =(int) mb_strcut($key_id, 1, mb_strlen($key_id));
	$key_number =(int) $key_id;
	while($key_number>80)
		$key_number-=10;
	for($i=0; $i<count($text); $i++){
		$line = explode(",", $text[$i]);
		if($line[3]==$key_number)
			return $line[2];
	}
	return "unknown";
}
function setting_key_id_from_sensor_packet_id($sensor_packet_id,$key_id){
	$sensor_number = mb_strcut($sensor_packet_id, 1, mb_strlen($sensor_packet_id));
	$sensor_number = (int) $sensor_number;
	$key_number = (int) $key_id; //mb_strcut($key_id, 1, mb_strlen($key_id))

	return "".sprintf('%d',$key_number+$sensor_number*10);
}
function sensor_packet_id_from_setting_key_id($key_id){
	$key_id -=70;
	$packet_id = (int) $key_id/10 ;
	return "S".sprintf('%02d',$packet_id);
	
}

?>