<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
require_once realpath(dirname(__FILE__)).'/../security/user.php';
require_once realpath(dirname(__FILE__)).'/../panel/equipement.php';
require_once realpath(dirname(__FILE__)).'/../panel/setting.php';

require_once realpath(dirname(__FILE__)).'/../panel/equipementManager.php';

require_once realpath(dirname(__FILE__)).'/../panel/sample.php';
require_once realpath(dirname(__FILE__)).'/../panel/notification.php';

require_once realpath(dirname(__FILE__)).'/../security/company.php';
require_once realpath(dirname(__FILE__)).'/../panel/sensor.php';

require_once realpath(dirname(__FILE__)).'/../panel/logManager.php';
require_once realpath(dirname(__FILE__)).'/../core/helper/mailer.php';

/*
 * API endpoint for the scentines
 */
class v1Manager extends module{
	/*
	 * Simple echoer 
	 */
	public static function echomsg($Request){
		echo $Request['msg'];
		logManager::push("System", "--", "Echoed:".$Request['msg']);
	}
	/*
	 * Simple dumper to show what is sent to server
	*/
	public static function dump($Request){
		unset($Request['controller']);
		logManager::push("System", "--", "Dump:".print_r($Request,true));
		echo json_encode("dumped");
	}
	/*
	 * reciever for devices
	 */
	public static function send($Request){
		logManager::push("System", "--", "Device connected:".print_r($Request,true));
		self::check_equipement($Request);
		$equipement = equipement::load(null, array(" `sn`= '".$Request['sn']."'  "));
	
		if($Request['lat'] && !is_numeric($Request['lat'])) {
			$obj = new stdClass();
			$obj->status= "failed";
			$obj->msg= "wrong lat:".$Request['lat'];
			echo json_encode($obj);
			logManager::push("System", "--", "wrong lat:".$Request['lat'], "ERROR");
			die();
		}
		if($Request['lon'] && !is_numeric($Request['lon'])) {
			$obj = new stdClass();
			$obj->status= "failed";
			$obj->msg= "wrong lon:".$Request['lon'];
			echo json_encode($obj);
			logManager::push("System", "--", "wrong lon:".$Request['lon'], "ERROR");
			die();
		}
		
		$company = company::load($equipement->company);
		if(!$Request['lat'] || !$Request['lon'] ){
			logManager::push($company->name, $equipement->name,"No lat/lon Sent, used the previous one:".print_r($Request,true), "WARN");
			$last = sample::load(null,array(
				"order"=> "ORDER BY createdat DESC",
				"limit"=>"LIMIT 1",
				"`lat` IS NOT NULL",
				"`lat` <> '' "
			));
			$Request['lat'] = $last->lat;
			$Request['lon'] = $last->lon;
		}
        if (!$Request['sensor'])
            $Request['sensor'] = array();
        if (!$Request['s'])
            $Request['s'] = array();
        $Request['sensor'] = array_merge($Request['sensor'],$Request['s']);

        foreach($Request['sensor'] as $packet_id => $value){
			$sensor = sensor::load(null, array("`packet_id`= '".$packet_id."'",
					 " `equipement` = '".$equipement->id."' "
			));
			if(!$sensor){
				logManager::push($company->name, $equipement->name, "Data Skipped, No sensor with this packet_id:".$packet_id, "WARN");
				continue;
			}
			$sample = new sample();
			$sample->lat= $Request['lat'];
			$sample->lon= $Request['lon'];
			$sample->value= $value;
			$sample->equipement= $equipement->id;
			$sample->sensor= $sensor->id;
			$sample->state= $Request['state'];
			if (is_numeric($Request['time'])) {
			    if ((int) ($Request['time']) < time() + 5*60*60 ) {
                    $sample->sampledat = (int) ($Request['time']/1000);
                } else {
                    $sample->sampledat = time();
                }
            } else {
                $unformatted = $Request['time'];
                #$unformatted = "27/4/18 19:54:40";
                $unformatted = explode(' ',$unformatted);
                $unformatted[0] =   explode('/',$unformatted[0]);
                $unformatted[1] =   explode(':',$unformatted[1]);
                # this is the format from gps: "25/4/18 0:42:9"
                $year =  2000+ (int)($unformatted[0][2]);
                $month = $unformatted[0][1];
                $day = $unformatted[0][0];
                $hour = $unformatted[1][0];
                $minute = $unformatted[1][1];
                $second= $unformatted[1][2];
                $t = mktime($hour, $minute, $second, $month, $day, $year);
                if ($t and time()- $t < 365*24*60*60 and $t < time() + 5*60*60) { // GPS sensor time sends 00/00/00 0:0:0
                    $sample->sampledat = $t;
                } else {
                    $sample->sampledat = time();
                }


			}
			$sample->createdat= time();
			$sample->save();
			//logManager::push($company->name, $equipement->name, "Saved sample:".$sample->id."- ".$sensor->name.": ".$sample->value);
		}
		$obj = new stdClass();
		$obj->status= "success";
		echo json_encode($obj);

			//check alarm
		//log clean up
		$last_log_id = db::get()->exQuery("SELECT id FROM log ORDER BY id DESC LIMIT 500000,1  ")[0]->id;
		if($last_log_id){
			db::get()->exQuery("DELETE FROM log WHERE id< $last_log_id ");
		}
		die();
		
	}
	
	function save_settings($Request){
		logManager::push("System", "--", "Device trying to save settings:".print_r($Request,true));
		self::check_equipement($Request);
		$equipement = equipement::load(null, array(" `sn`= '".$Request['sn']."'  "));
		$equipementUpdateTime = equipementManager::getUpdatedTime($equipement->id);
		$o = json_decode(str_replace(",}","}",$Request['settings']),true);
					
		if ($o['2'] && $o['3']){
			$dt = strptime($o['2']." ".$o['3'], "%d/%m/%y %H:%M:%S" );
			$time =  mktime($dt['tm_hour'], $dt['tm_min'], $dt['tm_sec'], $dt['tm_mon']+1, $dt['tm_mday'], $dt['tm_year']+1900);
			if($time <= $equipementUpdateTime){
				logManager::push("System", "--", "Device settings are not newer. Skipping:".print_r($Request,true));
				$obj = new stdClass();
				$obj->status= "failed";
				$obj->msg= "Device settings are not newer. Skipping.";
				echo json_encode($obj);
				die();
			}
		}else{
			$obj = new stdClass();
			$obj->status= "failed";
			$obj->msg= "No 'date/time' is sent.";
			echo json_encode($obj);
			logManager::push("System", "--", "No 'date/time' is Sent:".$_SERVER['REMOTE_ADDR'], "ERROR");
			die();
		}
		#saving equipement
		$equipement->extra = new stdClass();
		foreach($o as $key => $value){
			if(4<=$key && $key<=70){
				$key_name= setting_key_id_to_name($key);
				$equipement->extra->$key_name= $value;
			}
		}
		$equipement->extra->updatedat=$time;
		$equipement->save();
		#saving sensor settings
		$sensorExtras = array();
		foreach($o as $key => $value){
			if($key>=71){
				$packet_id = sensor_packet_id_from_setting_key_id($key);
				$sensorExtras[$packet_id][setting_key_id_to_name($key)]= $value;
			}
		}
		
		foreach($sensorExtras as $packet_id => $values){
			$sensor= sensor::load(null, array("packet_id = '".$packet_id."'", "equipement= '".$equipement->id."' "));
			if(!$sensor) echo $packet_id;
			$sensor->extra= new stdClass();
			foreach ($values as $key_name => $key_value){
				$sensor->extra->$key_name = $key_value;
			}
			$sensor->extra->updatedat = $time;
			$sensor->save();
			
		}
		logManager::push("System", "--", "Device saved settings:".print_r($Request,true));
		
		$obj = new stdClass();
		$obj->status= "success";
		$obj->msg= "saved";
		echo json_encode($obj);
	}
	
	public static function check_equipement(&$Request){
		#$Request['sn'] = $Request['sn'];
		if(!$Request['sn']){
			$obj = new stdClass();
			$obj->status= "failed";
			$obj->msg= "No SN Sent";
			echo json_encode($obj);
			logManager::push("System", "--", "No SN Sent:".$_SERVER['REMOTE_ADDR'], "ERROR");
			die();
		}
		$equipement = equipement::load(null, array(" `sn`= '".$Request['sn']."'  "));
		if(!$equipement){
			$obj = new stdClass();
			$obj->status= "failed";
			$obj->msg= "Not equipement with this SN";
			echo json_encode($obj);
			logManager::push("System", "--", "Not equipement with this SN:".$Request['sn'], "ERROR");
			die();
		}
	}
	/*
	 * Sends the settings of a devices with specific SN.
	 */
	public static function settings($Request){
		logManager::push("System", "--", "Device asked for settings:".print_r($Request,true));
		
		self::check_equipement($Request);
		$obj= [];
		$equipement = equipement::load(null, array(" `sn`= '".$Request['sn']."'  "));
		$lastUpdatedTime=equipementManager::getUpdatedTime($equipement->id);
		#date
		$obj["2"]= date("d/m/y",$lastUpdatedTime);
		#time
		$obj["3"]= date("H:i:s",$lastUpdatedTime);
						
		
		#equipement
		foreach($equipement->extra as $key => $v){
			if($key== "updatedat" || $key=="command" || $key=="purgedat") continue;
			if($v == null || $v =="") continue;
			$k = setting_key_name_to_id($key);
			$obj[$k] = $v;
		}
		if($equipement->extra->command){
			$obj["4"]= "1";
			unset($equipement->extra->command);
			$equipement->extra->purgedat = time();
			$equipement->save();
		}
		#sensors
		$sensors = sensor::load(null, array("`equipement` = '".$equipement->id."'"));
		foreach ($sensors as $sensor)
			foreach($sensor->extra as $key => $v){
				if($key== "updatedat" || $key=="command" || $key=="purgedat") continue;
				if($v == null || $v =="") continue;
				$k = setting_key_name_to_id($key);
				$k = setting_key_id_from_sensor_packet_id($sensor->packet_id, $k);
				$obj[$k] = $v;
			}
			
		$obj["sn"]= $Request['sn'];
		$obj["status"]= "success";
		echo json_encode($obj,JSON_NUMERIC_CHECK ); die();
	}
	public  static function send_mail($to, $title, $text){
		mailer::$server = "mail.scentroid.com";
		mailer::$sender = "alarm@scentroid.com";
		mailer::$sender_name = "SIMS Alarm";
		mailer::$password = "salam2030";
		
		mailer::send($to, $title, $text);
	}
    public static function sendMailWithCC($to, $cc, $title, $text){
        mailer::$server = "mail.scentroid.com";
        mailer::$sender = "alarm@scentroid.com";
        mailer::$sender_name = "SIMS Alarm";
        mailer::$password = "salam2030";

        mailer::sendWithCC($to, $cc, $title, $text);
    }
	public static function alarm($Request){
		$sensors = sensor::bulkLoad(0,10000);
		$alarmLast= file_get_contents("alarm_last.txt");
		foreach ($sensors as $s){
			if($s->alarm_max_value && $s->alarm_value_num && $s->alarm_value_total){
				//checking 
				//var_dump($s);
				$samples = sample::load(null,array("limit"=> "LIMIT ". $s->alarm_value_total));
				$samples = array($samples);
				$count =0; 
				for($i=0; $i<count($samples);$i++){
					if($samples[$i]->value >$s->alarm_max_value ){
						if($samples[$i]->createdat < $alarmLast)
							$count++;
					}
				}
				echo $count;
				if($count > $s->alarm_value_num){
					//echo "hereee";
					$equipement = equipement::load($s->equipement);
					//var_dump($equipement);
					//$company = company::load($eqipement->company);
					$manager = user::load(null,array("company = '".$equipement->company."'" ,"`roles` LIKE '%manager%'"));
					self::send_mail($manager->email, "Alarm for sensor ".$s->name, "Value reached more than ".$s->alarm_max_value." in ".$s->alarm_value_num." out of ".$s->alarm_value_total);
					echo "sent an alarm <br>";
				}				
			}
		}
		file_put_contents("alarm_last.txt", time());
	}
	public static function test($Request){
		echo time();
		
	}
	public static function test_email($Request){
	    self::sendMailWithCC('monitor@enviroserv.co.za','support@scentroid.com', 'test','this email is to test an issue reported');
    }
    /*
     * data endpoint
    */
    public static function data($Request){
        unset($Request['controller']);
        $equipement = equipement::load(null, array(" `secret` = '".$Request['secret']."'",
                                     " `sn` = '".$Request['sn']."'",));
        if ( !$equipement ) {
            logManager::push("System", "--", "Wrong secret/sn - Dump:".print_r($Request,true), $type='API.DATA');
            die("Wrong secret/sn");
        } else {
            $company = company::load($equipement->company);
            if (isset($Request['from']) && !is_numeric($Request['from'])
                || isset($Request['to']) && !is_numeric($Request['to'])
                || isset($Request['p']) && !is_numeric($Request['p'])){
                logManager::push($company->name, $equipement->name, "Malicious activity - Dump:".print_r($Request,true));
                die("from/to/p should be numeric");
            }
            $conditions = array();

            if (isset($Request['p']) && isset($Request['latest'])){
                die("you cannot use paging and ask for latest data at the same time");
            }
            if (isset($Request['latest']) && ($Request['from'] || $Request['to'])){
                die("you cannot use latest with from/to.");
            }
            if (isset($Request['from'])){
                $conditions[] = $Request['from'].' <= sampledat ' ;
            }
            if (isset($Request['to'])){
                $conditions[] = ' sampledat <= '.$Request['to'];
            }
            if(!isset($Request['p']) || $Request['p'] < 1){
                $Request['p'] = 1;
            }
            $limit = "limit ".(($Request['p']-1)*30).",30";
            $logCount= logManager::countLogs($company->name, $equipement->name, "API.DATA", time()- 60);
            if ($logCount > 30){
                logManager::push($company->name, $equipement->name, "Access Throttled to API - Dump:".print_r($Request,true), $type='API.DATA.THROTTLED');
                die("Access throttled. you can call this API, 30 times per minute");
            }
            logManager::push($company->name, $equipement->name, "Access to API - Dump:".print_r($Request,true), $type='API.DATA');

            if($Request['sensor']) {
                $sensor_name= $Request['sensor'];
                if (!preg_match('/^[a-zA-Z0-9-_ ]+$/', $sensor_name)){
                    die("sensor name should be only having A-Z,a-z,0-9 and _- and whitespace. we recorded your malicious activity");
                }
                $sensor_raw = sensor::load(null, array("`equipement` = ".$equipement->id, "`name`='$sensor_name'"));
                $conditions[]= "`sensor` IN ($sensor_raw->id)";
                $conditions = implode(" AND ", $conditions);
                $sensors[$sensor_raw->id] = $sensor_raw->name;
                $samples = sample::load(null, array( $conditions, "limit"=> $limit, "order"=> "order by id desc"));
            } else {
                $sensors_raw = sensor::load(null, array("`equipement` = ".$equipement->id));
                if (!$sensors_raw) {
                    die("no sensors has been defined for this equipment");
                }
                $sensor_ids = array();
                foreach($sensors_raw as $k => $sensor){
                    $sensors[$sensor->id] = $sensor->name;
                    $sensor_ids[] = $sensor->id;
                }
                $sensor_ids = implode(",",$sensor_ids);
                $conditions[]= "`sensor` IN ($sensor_ids)";
                $conditions = implode(" AND ", $conditions);

                if( strtolower($Request['latest'])== "true")
                    $limit = "limit 500";

                $samples = sample::load(null, array( $conditions, "limit"=> $limit, "order"=> "order by id desc"));
            }

            $output = array();
            $latestOutputedSamples = array();

            //if we want the latest, skip the rest
            if( strtolower($Request['latest'])== "true"){
                foreach($samples as $sample) {
                    if(!$latestOutputedSamples[$sample->sensor]){
                        $latestOutputedSamples[$sample->sensor] = true;
                        $output [] = array("sensor"=> $sensors[$sample->sensor],
                            "time" => $sample->sampledat,
                            "longitude" => $sample->lon,
                            "latitude" => $sample->lat,
                            "value" => $sample->value);
                    }
                }

            } else{
                foreach($samples as $sample) {
                    $output [] = array("sensor"=> $sensors[$sample->sensor],
                        "time" => $sample->sampledat,
                        "longitude" => $sample->lon,
                        "latitude" => $sample->lat,
                        "value" => $sample->value);
                }
            }

            echo json_encode($output);
        }
    }
    public static function diagnosis($Request){
        unset($Request['controller']);
        $equipement = equipement::load(null, array(" `sn` = '".$Request['sn']."'",));
        if ( !$equipement ) {
            logManager::push("System", "--", "Wrong secret/sn - Dump:".print_r($Request,true), $type='API.DATA');
            die("Wrong secret/sn");
        } else {
            $notificationText = setting::load(null, array("`category` = 'Sensor Diagnosis Messages' ", "`name`='".$Request['issue']."' "));
            if (!$notificationText)
                die("not such issue in our settings:".$Request['issue']);

            $notificationText = $notificationText->value;
            for($i=0; $i<count($Request['param']); $i++){
                $notificationText = str_replace("{".$i."}", $Request['param'][$i],$notificationText);
            }
            $notificationText = str_replace("{ScentinelSN}", $Request['sn'],$notificationText);
            $notificationText = str_replace("{Company}", company::load($equipement->company)->name ,$notificationText);

            $manager = user::load(null,array("company = '".$equipement->company."'" ,"`roles` LIKE '%manager%'"));#
            self::send_mail(
                #$manager->email ,#"saeedzareian+sims@gmail.com",
                "support@scentroid.com",
                "Notification -" . $equipement->name  ,
                $notificationText
            );
            echo "sent a notification";
        }
    }


    public static function inactivity_checker($Request){
        unset($Request['controller']);
        $thresholdHour = 2;
        $equipements = equipement::load(null, array("order" => "order by id asc"));
        $notificationText = setting::load(null, array("`category` = 'Equipment Messages' ", "`name`='inactivity' "));
        $notificationText = $notificationText->value;

        // taking all equipment ids
        $equipementsIds = array();
        foreach ($equipements as $e){
            $equipementsIds[]= $e->id;
        }
        $equipementsIds = implode(',', $equipementsIds);
        // getting latest sample
        $queryResult = DB::get()->exQuery("SELECT max(id) as sample_id, equipement FROM sample where equipement in ($equipementsIds) GROUP BY equipement");
        for($i=0; $i<count($queryResult); $i++) {
            $lastSample[$queryResult[$i]->equipement] = sample::load($queryResult[$i]->sample_id);
            foreach($equipements as $equipement){
                if($queryResult[$i]->equipement == $equipement->id){
                    $lastSample[$queryResult[$i]->equipement]->equipement = $equipement;
                }
            }
        }
        // comparing the sample time with threshold
        foreach($lastSample as $equipmentId => $sample){
            if (time() - $sample->sampledat < $thresholdHour*3600 ) { # we are good, remove it
                unset($lastSample[$equipmentId]);
            }
        }

        //group inactive equipments
        foreach($lastSample as $equipmentId => $sample){
            $group[$sample->equipement->company][] = $sample;
        }

        // reporting
        foreach($group as $company => $samples) {
            $text = $notificationText;
            //$text = "company: ".$company."<br>";
            $manager = user::load(null,array("company = '".$company."'" ,"`roles` LIKE '%manager%'"));
            //$text .= $manager->email."<br>";

            $table_data= array();
            foreach($samples as $sample){
                if ($sample->equipement->notification > time()) {
                    if (notification::count($sample->equipement->id, 10*365*24*3600) <= 2) {
                        $t = "<li>". $sample->equipement->name ." - ".ago($sample->sampledat)."</li>";
                        $n = new notification();
                        $n->equipement = $sample->equipement->id;
                        $n->category = "inactivity";
                        $n->createdat = time();
                        $n->destination =$manager->email;
                        $n->text = $t;
                        $n->save();
                        $table_data[]= $t;
                    } else{
                        if ($sample->equipement->notification  > time()) {
                            $eq =  $equipement::load($sample->equipement->id);
                            $eq->notification= time()-10;
                            $eq->save();
                        }
                    }
                }
            }
            if ($table_data) {
                $companyName = company::load($company)->name;
                $table = "<ul>".implode("", $table_data)."</ul>";
                $text = str_replace("{threshold}", $thresholdHour, $text);
                $text = str_replace("{table}", $table, $text);
                $text = str_replace("{Company}", $companyName, $text);
                echo $text;


                self::sendMailWithCC(
                    $manager->email ,#"saeedzareian+sims@gmail.com",
                    #"saeedzareian+sims@gmail.com",
                    "support@scentroid.com",
                    "Inactivity Notification - ".$companyName." -". count($table_data) ." equipment(s)"  ,
                    $text
                );

            }


        }

    }

    public static function fill_bag($Request) {
        unset($Request['controller']);
        $equipement = equipement::load(null, array(" `sn` = '" . $Request['sn'] . "'",));
        if (!$equipement) {
            logManager::push("System", "--", "Wrong secret/sn - Dump:" . print_r($Request, true), $type = 'API.DATA');
            die("Wrong secret/sn");
        } else {
            if($equipement->extra->command==1) {
                echo "{1}";
                $equipement->extra->command = 0;
                $equipement->save();
            }else {
                echo "{0}";
            }
        }
    }

}
