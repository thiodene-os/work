<?php
require_once realpath(dirname(__FILE__)).'/class.phpmailer.php';

  class mailer{
  	public static $server; 
  	public static $sender;
  	public static $sender_name;
  	public static $password;
  
	public static function send($destMail, $subject, $content){

		$mail=  new PHPMailer();
			
		$mail->IsSMTP();    // set mailer to use SMTP
		//$mail->Host = "mail.http://beporsin.com";    // specify main and backup server
		$mail->Host =self::$server;    // specify main and backup server
		$mail->SMTPSecure = "ssl";
		$mail->SMTPAuth = true;    // turn on SMTP authentication
		$mail->Username = self::$sender;    // SMTP username -- CHANGE --
		$mail->Password = self::$password;    // SMTP password -- CHANGE --
		//$mail->Port = "25";    // SMTP Port
		$mail->Port = "465";    // SMTP Port
		$mail->From =self::$sender;
		$mail->FromName = self::$sender_name;
		$mail->AddAddress($destMail);  // Add a recipient
		//$mail->AddReplyTo('info@beporsin.com', 'Information');
			
			
		$mail->WordWrap = 2000;                                 // Set word wrap to 50 characters
		$mail->IsHTML(true);                                  // Set mail format to HTML
		$mail->CharSet = 'UTF-8';
		$mail->Subject =$subject;
		$mail->Body    = $content;
		// 		$mail->AltBody = $text;
		if(!$mail->Send()) {
			echo 'Message could not be sent.<br>';
			echo 'Mailer Error: ' . $mail->ErrorInfo;
			exit;
		}
		
		
	}

      public static function sendWithCC($destMail, $cc, $subject, $content){

          $mail=  new PHPMailer();

          $mail->IsSMTP();    // set mailer to use SMTP
          //$mail->Host = "mail.http://beporsin.com";    // specify main and backup server
          $mail->Host =self::$server;    // specify main and backup server
          $mail->SMTPSecure = "ssl";
          $mail->SMTPAuth = true;    // turn on SMTP authentication
          $mail->Username = self::$sender;    // SMTP username -- CHANGE --
          $mail->Password = self::$password;    // SMTP password -- CHANGE --
          //$mail->Port = "25";    // SMTP Port
          $mail->Port = "465";    // SMTP Port
          $mail->From =self::$sender;
          $mail->FromName = self::$sender_name;
          $mail->AddAddress($destMail);  // Add a recipient
          $mail->AddCC($cc);  // Add a recipient
          //$mail->AddReplyTo('info@beporsin.com', 'Information');


          $mail->WordWrap = 2000;                                 // Set word wrap to 50 characters
          $mail->IsHTML(true);                                  // Set mail format to HTML
          $mail->CharSet = 'UTF-8';
          $mail->Subject =$subject;
          $mail->Body    = $content;
          // 		$mail->AltBody = $text;
          if(!$mail->Send()) {
              echo 'Message could not be sent.<br>';
              echo 'Mailer Error: ' . $mail->ErrorInfo;
              exit;
          }


      }
	
}