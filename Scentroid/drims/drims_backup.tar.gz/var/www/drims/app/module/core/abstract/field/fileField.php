<?php
require_once(realpath(dirname(__FILE__)."/..")."/field.php");
class fileField extends field{
	

	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		$this->value = json_decode($this->value);
	
	}
	public function render(){
		if($this->extra->required)
			$required= ' required="required" ' ;
		$str .= "\n";
		$str .= '<div class="form-group">';
		//label
		$str .= '<label for="field_'.$this->id.'" id="" class="col-xs-2 control-label">'.l($this->label).'</label>';
		//the field
		$str .= '<div class="col-xs-4">';
		if(!$this->value){
			$str.= '<input type="file" name="'.$this->name.'" class="file '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="'.$this->placeholder.'" '.$required.' >';
		}else{
			$str.= '<input type="file" name="'.$this->name.'" class="file '.$this->cssClass.'" id="field_'.$this->id.'">   <a class="btn btn-mini btn-info" href="{baseurl}'.$this->value->path.'">Download</a> 
						<input type="checkbox" name="'.$this->name.'_delete"> حذف
					';
		}
		$str .= "</div>";
		$str .= "<div class='row'><div class='col-xs-12'>";
		//end of field
		if($this->helperText != "")
			$str .= "<small>".$this->helperText."</small>";
		$str .= '</div></div>';
		$str .= "\n";
		$str .= "</div>\n";
		return $str;
	}
}