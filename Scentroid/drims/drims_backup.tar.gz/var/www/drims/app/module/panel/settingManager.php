<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../security/company.php';

require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/../panel/equipement.php';
require_once realpath(dirname(__FILE__)).'/../panel/sample.php';
require_once realpath(dirname(__FILE__)).'/../panel/sensor.php';
require_once realpath(dirname(__FILE__)).'/../panel/setting.php';



/* settings controller */
class settingManager extends module{
	/* shows the welcome page for admin, limited pages for manager and user */
	public static function edit($Request){
		userManager::checkRole(array("admin"));
		$parser = Parser::get();
		$setting = setting::load(null, array("order"=> "order by id desc"));
        $setting = arrayit($setting);
        $settingGroups = array();
        for($i=0; $i<count($setting); $i++){
            $settingGroups[] = $setting[$i]->category;
        }
        $parser->setVar("setting", $setting);
        $parser->setVar("settingGroups", array_unique($settingGroups));

        if($Request['saved']){
            $parser->setVar("saved", "1");
        }

		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_5", "1");
		
		$parser->insert("contentblock", "settings");
		$parser->parse("single");
	}

    public static function save($Request){
        userManager::checkRole(array("admin"));
        foreach ($Request['setting'] as $r => $v) {
            $s = setting::load(null, array("`name` = '".$r."'"));
            if (!$s) {
                die("wrong setting: ".$r);
            }
            $s->value = $v;
            $s->updatedby = userManager::getUser()->id;
            $s->updatedat = time();
            $s->save();
        }
        $Request['saved']="1";
        self::edit($Request);
    }

}
