<?php
session_start();
//namespace application\Controller;
//if (isset($_COOKIE['PHPSESSID']))
//	session_id($_COOKIE['PHPSESSID']);
/*$baseurl = "http://beporsin.com/";
require_once realpath(dirname(__FILE__)).'/../Model/User.php';
require_once realpath(dirname(__FILE__)).'/../Helper/Parser.php';
require_once realpath(dirname(__FILE__)).'/../Helper/MysqlDB.php';
require_once realpath(dirname(__FILE__)).'/../Controller/logController.php';
require_once realpath(dirname(__FILE__)).'/../Controller/accessController.php';
require_once realpath(dirname(__FILE__)).'/../Controller/statController.php';
*/

require_once realpath(dirname(__FILE__)).'/utility/Language.php';
require_once realpath(dirname(__FILE__)).'/utility/Structurer.php';
require_once realpath(dirname(__FILE__)).'/../core/utility/Parser.php';
error_reporting(E_ALL ^ E_NOTICE);
//error_reporting(E_ALL ^ E_STRICT ^ E_NOTICE);
//error_reporting(0);
class router {
	public static $parser = null;
	public static function process($controllerName,$action, $Request){
		self::cleanRequests();
/*		statController::savehit(null);
		
		if(Access::check($_SERVER['REMOTE_ADDR'], "ip")){
			accessController::showMessage();
			die();
		}
	*/	

		
	/*	self::$parser = Parser::get();
		$baseurl = Parser::$baseURL;
		if($Request['ajax'] == "1"){
			self::$parser->ajax = true;
		}
			
		if($Request['mobile'])
			self::$parser->mobile = true; */
		//->loading controller
		
		//$controllerName = str_replace("do/", "", $controllerName);
		// URL: module/moduleName/something
		$controllerName = explode(("/"), $controllerName);
		 
		require_once (realpath(dirname(__FILE__))."/../".$controllerName[0]."/".$controllerName[1]."Manager.php");

		$controllerName=$controllerName[1]."Manager";
		$o=new $controllerName();
		$o->$action($Request);
	}
	static public function cleanRequests(){
		/*$db = MysqlDB::get();
		
		foreach($_REQUEST as $k => $v){
			if(!is_array($v))
				$_REQUEST[$k] = mysql_real_escape_string($v, $db->con);
			else
				foreach ($v as $k2 => $v2){
				$_REQUEST[$k][$k2] = mysql_real_escape_string($v2,$db->con);
			}
		}
		
		foreach($_SERVER as $k => $v){
			if(in_array($k, array("HTTP_REFERER","REMOTE_ADDR","HTTP_USER_AGENT")))
				$_SERVER[$k] = mysql_real_escape_string($v, $db->con);
		}*/
	}
	public static function getParser(){
		//->loading parser
		self::$parser = Parser::get();
		return self::$parser;
	}	
	public static function strip_word_html($text, $allowed_tags = '<b><i><sup><sub><em><strong><u><br><ul><li><ol><a><p><span>'){

		mb_regex_encoding('UTF-8');
		//replace MS special characters first
		$search = array('/&lsquo;/u', '/&rsquo;/u', '/&ldquo;/u', '/&rdquo;/u', '/&mdash;/u');
		$replace = array('\'', '\'', '"', '"', '-');
		$text = preg_replace($search, $replace, $text);
		//make sure _all_ html entities are converted to the plain ascii equivalents - it appears
		//in some MS headers, some html entities are encoded and some aren't
		//$text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
		//try to strip out any C style comments first, since these, embedded in html comments, seem to
		//prevent strip_tags from removing html comments (MS Word introduced combination)
		if(mb_stripos($text, '/*') !== FALSE){
			$text = mb_eregi_replace('#/\*.*?\*/#s', '', $text, 'm');
		}
		//introduce a space into any arithmetic expressions that could be caught by strip_tags so that they won't be
		//'<1' becomes '< 1'(note: somewhat application specific)
		$text = preg_replace(array('/<([0-9]+)/'), array('< $1'), $text);
		$text = strip_tags($text, $allowed_tags);
		//eliminate extraneous whitespace from start and end of line, or anywhere there are two or more spaces, convert it to one
		$text = preg_replace(array('/^\s\s+/', '/\s\s+$/', '/\s\s+/u'), array('', '', ' '), $text);
		//strip out inline css and simplify style tags
		$search = array('#<(strong|b)[^>]*>(.*?)</(strong|b)>#isu', '#<(em|i)[^>]*>(.*?)</(em|i)>#isu', '#<u[^>]*>(.*?)</u>#isu');
		$replace = array('<b>$2</b>', '<i>$2</i>', '<u>$1</u>');
		$text = preg_replace($search, $replace, $text);
		//on some of the ?newer MS Word exports, where you get conditionals of the form 'if gte mso 9', etc., it appears
		//that whatever is in one of the html comments prevents strip_tags from eradicating the html comment that contains
		//some MS Style Definitions - this last bit gets rid of any leftover comments */
		$num_matches = preg_match_all("/\<!--/u", $text, $matches);
		if($num_matches){
			$text = preg_replace('/\<!--(.)*--\>/isu', '', $text);
		}
		$text = preg_replace('/(<[^>]+) style=".*?"/i', '$1', $text);
		$text = preg_replace('/(<[^>]+) class=".*?"/i', '$1', $text);
		$text = preg_replace('/(<[^>]+) dir=".*?"/i', '$1', $text);
		$text = preg_replace('/(<[^>]+) lang=".*?"/i', '$1', $text);

		return $text;
	}
}

$_GET['controller'] = strtolower($_GET['controller']);
$ent = explode(".", $_GET['controller']);
if($ent[0]!= ""){
	if($_FILES != null){
		$_REQUEST['uploaded_files'] = $_FILES;
	}
	router::process($ent[0],$ent[1], $_REQUEST);
}
	

?>