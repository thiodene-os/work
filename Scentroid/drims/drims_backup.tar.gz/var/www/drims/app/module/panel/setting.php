<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/* setting ORM container */
class setting  extends entity{
		public $category;
		public $name;
		public $value;
		public $updatedby;
        public $updatedat;
}