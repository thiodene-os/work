<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/*
 * ORM Object to keep a user.
 */
class user extends entity{
		public $email;
		public $username;
		public $password;
		public $name;
		public $family;
		public $image;
		public $company;
		public $birthdate; //day, month, year
		public $gender; 
		public $location; //country, city, lon, lat
		public $tel;
		public $roles;
		public $extra; //last login , activated, 
		public $createdat;
		public $expireat;
		public  function __construct(){
			
		}
		public static function load($id, $condition = null, $join=null){
			
		   $user= parent::load($id, $condition);
		   $user= arrayit($user);
		   
		   for($i=0; $i<count($user); $i++){
		   	$user[$i]->location= json_decode($user[$i]->location);
		   	$user[$i]->birthdate= json_decode($user[$i]->birthdate);
		   	$user[$i]->roles= arrayit(json_decode($user[$i]->roles));
		   	$user[$i]->extra= json_decode($user[$i]->extra);
		   }
		   if(count($user) ==1 ){
		   	return $user[0];
		   }else 
		   return $user; 
				
			
		}
		public function save(){
			$this->location= json_encode($this->location);
			$this->birthdate= json_encode($this->birthdate);
			$this->roles= json_encode($this->roles);
			$this->extra= json_encode($this->extra);
			parent::save();
		}
		
		public function hasPermission($place){
			return permission::roleHasPermission($this->id, $place);
		}
		public static function getUserNameAndFamilyById($id){
			if($id == null){
				return null;
			}
			$user = user::load($id);
			return $user->name." ".$user->family;
		}
		public function getCompany(){
			return company::load($this->company);
		}
	
}