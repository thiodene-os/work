<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/* ORM container for equipements */
class notification extends entity{
		public $title;
		public $text;
        public $category;
        public $equipement;
        public $destination;
		public $createdat;

    public static function count($equipmentId, $intervalHour){
        $conds = array(" `equipement` = ".$equipmentId, " `createdat` > ".(time() - $intervalHour*3600));
        return parent::count($conds);
    }
}