<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';


class pageManager extends module{
	/*
	 * Shows home page.
	 */
	public static function home($Request){
		$parser = Parser::get();
		$parser->parse("home"); 
		
	}
	
}
