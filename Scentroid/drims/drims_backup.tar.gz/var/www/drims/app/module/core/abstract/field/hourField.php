<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
require_once(realpath(dirname(__FILE__))."/../../utility/Date.php");
class hourField extends field{
	

	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		 
		$date = new jDate();
		$this->value = $value;
		///$this->value= time();
		$str= explode(":",$this->value);
		$this->value= new stdClass();
		$this->value->hour = $str[0];
		$this->value->minute = $str[1];
		$this->value->second = $str[2];
		
	}
	public function render(){
		if($this->extra->required)
			$required= ' required="required" ' ;
		$str .= "\n";
		$str .= '<div class="form-group">';
		//label		
		$str .= '<label for="field_'.$this->id.'" id="" class="col-xs-2 control-label">'.l($this->label).'</label>';		
		//the field
		$str .= '<div class="col-md-6 ">';
		if(!$this->value){
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[second]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="49" '.$required.' ></div>';
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[minute]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="45" '.$required.' ></div>';
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[hour]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="21" '.$required.' ></div>';
			
		}else{
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[second]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="35" '.$required.' value="'.htmlspecialchars($this->value->second).'"></div>';
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[minute]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="25" '.$required.' value="'.htmlspecialchars($this->value->minute).'"></div>';
			$str.= '<div class="col-md-2"><input name="'.$this->name.'[hour]" class=" form-control '.$this->cssClass.'" id="field_'.$this->id.'" placeholder="21" '.$required.' value="'.htmlspecialchars($this->value->hour).'"></div>';
		}
		$str .= "</div>";
		$str .= "<div class='row'><div class='col-xs-12'>";
		//end of field
		if($this->helperText != "")
		$str .= "<small>".$this->helperText."</small>";
		$str .= '</div></div>';
		$str .= "</div>\n";
		return $str;
	}
}