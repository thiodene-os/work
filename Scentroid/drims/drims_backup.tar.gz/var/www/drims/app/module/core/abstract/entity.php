<?php
require_once(realpath(dirname(__FILE__))."/db.php");
class entity{
	public $id = null;
	
	
	public function fill($values){
		foreach($values as $k => $v){
			if(!is_string($v)){
				$v= json_encode($v);
			}
			$this->$k  = $v;
		}		
	}
	public function save(){
		
		$dbCols =self::getTableFields();
		
		if($this->id != null){//update
			$str= "UPDATE `".strtolower(get_called_class())."` SET ";
			$vals = array();
			foreach(get_object_vars($this) as $k => $v){
				if(in_array($k, array("id")) ||  !in_array($k, $dbCols))
					continue;
				$vals []= "`".$k."`='".mysqli_escape_string(db::get()->con,$v)."' ";
			}
			$str .= implode(", ", $vals);
			$str .= " WHERE `id`= '".$this->id."' ";
		}else{//update
			$str= "INSERT INTO `".strtolower(get_called_class())."` ";
			$cols = array();
			$vals = array();
			foreach(get_object_vars($this) as $k => $v){
				if(in_array($k, array("id")) || !in_array($k, $dbCols))
					continue;
				$cols [] = "`".$k."`";
				$vals [] = "'".mysqli_escape_string(db::get()->con,$v)."'";
			}
			$str .= "(".implode(",", $cols).") VALUES (".implode(",", $vals).")";
		}
		db::get()->exQuery($str);
		if($this->id == null){//insert
				$this->id  = db::get()->lastId();
		}
		
	}
	public static function load($id, $condition = null, $join = null){
		if($id ==  null && $condition == null){
			return -2;
		}
		if($id != null)
			$condition []= " `".strtolower(get_called_class())."`.`id` = '$id' ";
		$orderAndLimit = "";
		if($condition ['order']){
			$orderAndLimit .=$condition ['order'] ;
			unset($condition ['order']);
		}
		if($condition ['limit']){
			$orderAndLimit .= " ".$condition ['limit'] ;
			unset($condition ['limit']);
		}
		
		
		$condition= implode(" AND ", $condition);
		if($condition != ""){
			$condition =" WHERE ".$condition;
		}
		if($join == null){
		 	$str= " SELECT * FROM `".strtolower(get_called_class())."` ".$condition . " ".$orderAndLimit;
		}else{
			$str= " SELECT * FROM `".strtolower(get_called_class())."`,`".$join."` ".$condition . " ".$orderAndLimit;
		}
		$obj = db::get()->exQuery($str);
		
		for($i=0; $i<count($obj); $i++){
			$obj[$i] =self::recast(get_called_class(), $obj[$i]);
		}
		
		if(count($obj)==1)
			return $obj[0];
		else 
			return $obj;
	}
	public static function count( $condition = null, $join = null){
		if($condition == null){
			return -2;
		}
		
		$orderAndLimit = "";
		if($condition ['order']){
			$orderAndLimit .=$condition ['order'] ;
			unset($condition ['order']);
		}
		if($condition ['limit']){
			$orderAndLimit .= " ".$condition ['limit'] ;
			unset($condition ['limit']);
		}
		
		if($condition == null )
			$condition = array();
		
		$condition= implode(" AND ", $condition);
		
		if($condition){
			$condition =" WHERE ".$condition;
		}
		 $str= " SELECT COUNT(*) as number FROM `".strtolower(get_called_class())."` ".$condition . " ".$orderAndLimit;
		
		$obj = db::get()->exQuery($str);
		
		return $obj[0]->number;
		
	}
	public static function delete($id,$condition = null){
		if($id ==  null && $condition==null){
			return -2;
		}
		if($condition != null){
			$condition= implode(" AND ", $condition);
			$str= "DELETE FROM `".strtolower(get_called_class())."` WHERE ".$condition;
		}else{
			$str= "DELETE FROM `".strtolower(get_called_class())."` WHERE `id` = '".$id."'  ";
		}
		db::get()->exQuery($str);
		//echo $str;
	}
	private static function getTableFields(){

		$cols = db::get()->exQuery("SHOW columns FROM `".strtolower(get_called_class())."`");
		$list = array();
		foreach ($cols as $k => $col){
			$list[]= $col->Field;
		}
		return $list;
	}
	public  function getRelatedEntity($type,$condition =null){
		if($type ==  null && $condition != null){
			return -2;
		}
		
		$orderAndLimit = "";
		if($condition ['order']){
			$orderAndLimit .=$condition ['order'] ;
			unset($condition ['order']);
		}
		if($condition ['limit']){
			$orderAndLimit .= " ".$condition ['limit'] ;
			unset($condition ['limit']);
		}
		
		
		$tables = array(get_called_class(), $type);
		sort($tables);
		$join_table_name= "join_".implode("_",$tables);
		
		$joinstr= "JOIN `".strtolower($join_table_name)."` ON  (`".strtolower($type)."`.`id` = `".strtolower($join_table_name)."`.`".strtolower($type)."Id` ) ";
		if(!is_array($condition))
			$condition = array();
		$condition[] = "`".get_called_class()."Id`= '".$this->id."'";
		$condition= implode(" AND ", $condition);
		
		$str= " SELECT * FROM `".strtolower($type)."` ".$joinstr." WHERE ".$condition." ".$orderAndLimit ;
		
		$obj = db::get()->exQuery($str);
		
		for($i=0; $i<count($obj); $i++){
			$obj[$i] = self::recast($type, $obj[$i]);
		}
		
		if(count($obj)==1)
			return $obj[0];
		else
			return $obj;
	}
	public  function setRelatedEntity($type,$typeId){
		$tables = array(get_called_class(), $type);
		sort($tables);
		$join_table_name= "join_".implode("_",$tables);
		
		if($tables[1] == $type){
			$values= " '".$typeId."','".$this->id."' ";
		}else{
			$values= " '".$this->id."','".$typeId."' ";
		}
		
		$str= "INSERT INTO `".strtolower($join_table_name)."` (`".strtolower(get_called_class())."Id`,`".strtolower($type)."Id`) VALUES ($values) ";
		db::get()->exQuery($str);
	}
	
	public  function removeRelatedEntity($type,$typeId){
		$tables = array(get_called_class(), $type);
		sort($tables);
		$join_table_name= "join_".implode("_",$tables);
		
		$values= "`".$type."Id` =  '".$typeId."' AND `".get_called_class()."Id` = '".$this->id."' ";
	
		$str= "DELETE  FROM `".strtolower($join_table_name)."` WHERE  $values";
		db::get()->exQuery($str);
	}
	
	public  function removeMyRelationTo($type){
		$tables = array(get_called_class(), $type);
		sort($tables);
		$join_table_name= "join_".implode("_",$tables);
	
		$values= "`".get_called_class()."Id` = '".$this->id."' ";
	
		echo $str= "DELETE  FROM  `".strtolower($join_table_name)."` WHERE  $values";
		db::get()->exQuery($str);
	}
	
	
	private static function recast($className, stdClass &$object){
		if (!class_exists($className)){
			echo sprintf('Inexistant class %s.', $className);
		}
	
		$new = new $className();
	
		foreach($object as $property => &$value)
		{
			$new->$property = &$value;
			unset($object->$property);
		}
		unset($value);
		$object = (unset) $object;
		return $new;
	}
	public static function bulkLoad($start=0, $limit=30,$condition=""){
		
		if($limit != -1)		$limitation= " LIMIT $start, $limit ";
		if($condition !="" ) $condition = " WHERE ".$condition;
		
		$str= " SELECT * FROM `".strtolower(get_called_class())."` ".$condition;
		return db::get()->exQuery($str);
	}
	
}	