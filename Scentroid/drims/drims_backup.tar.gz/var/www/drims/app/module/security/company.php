<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
class company extends entity{
		public $name;
		public $logo; 
		public $tel;
		public $city;
		public $alarm_email;
		public $timezone;
		public $address;
		public $manager;
		public $extra; //ALTER TABLE `company` ADD `extra` TEXT NULL AFTER `manager`;
        public $creator;
		public $createdat;

    public static function load($id, $condition = null, $join=null){

        $obj= parent::load($id, $condition);
        $obj= arrayit($obj);

        for($i=0; $i<count($obj); $i++){
            $obj[$i]->extra= json_decode($obj[$i]->extra);
        }
        if(count($obj) ==1 ){
            return $obj[0];
        }else
            return $obj;


    }
    public function save(){
        $this->extra= json_encode($this->extra);
        parent::save();
        $this->extra= json_decode($this->extra);

    }
		
}