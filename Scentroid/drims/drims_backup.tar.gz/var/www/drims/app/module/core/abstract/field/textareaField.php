<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
class textareaField extends field{

	
	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		
	
	}
	public function render(){
	
		if($this->required)
			$required= ' required="required" ' ;
		$str .= "\n";
		$str .= '<div class="form-group">';
		//label
		$str .= '<label for="field_'.$this->id.'" id="" class="col-xs-2 control-label">'.l($this->label).'</label>';
		//the field
		$str .= '<div class="col-xs-10">';
		if($this->extras->editor != null){
			$editor = "editor";
		}
		if(!$this->value){
			$str.= '<textarea name="'.$this->name.'" class="text '.$this->cssClass.' '.$editor.' form-control" id="field_'.$this->id.'" rows=10 ></textarea>'; 
		}else{
			if(!$editor){
				$this->value= htmlspecialchars($this->value);
			}else{
				$this->value= nl2br($this->value);
			}
			
			$str.= '<textarea name="'.$this->name.'" class="text '.$this->cssClass.' '.$editor.' form-control" id="field_'.$this->id.'" rows=10>'.
					$this->value			
			.'</textarea>';
		}
		$str .= "</div>";
		$str .= "<div class='row'><div class='col-xs-12'>";
		//end of field
		if($this->helperText != "")
			$str .= "<small>".$this->helperText."</small>";
		$str .= '</div></div>';
		$str .= "</div>\n";
		
		$str .= "\n";
		
		return $str;
	}
	
}