<?php
require_once realpath(dirname(__FILE__)).'/../../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/../../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/form.php';
class module {
	
	public $info;
	public static function getInfo(){
		$rc = new ReflectionClass(get_called_class());
		if(file_exists(dirname($rc->getFileName())."/info"))
		return file_get_contents(dirname($rc->getFileName())."/info");
		else return null;
	} 
	function __construct(){
		$rc = new ReflectionClass(get_called_class());
		if(!file_exists(dirname($rc->getFileName())."/info"))
			return;
		$info = file_get_contents(dirname($rc->getFileName())."/info");
		$info = explode("\r\n", $info);
		for($i=0; $i<count($info);$i++){
			
			$info[$i]= explode (":",$info[$i],2);
			
			for($j=0; $j<count($info[$i]); $j++){
				$info[$i][$j]=trim ($info[$i][$j]);
			}
			$this->info[$info[$i]['0']] = $info[$i]['1'];
		}
	}
	public static function settings($Request){
		if($Request['op'] == "save"){
			$className = get_called_class();
			$className = str_replace("Manager", "", $className);
			if(class_exists($className)){
				$vars= get_class_vars($className);
				foreach($vars as $var){
					$myobject = new $className();
					//to do: load attributes and  check required
					$myobject->$var = $Request[$var];
					$myobject->save();
				}
			}else 
				die("CLASS ".$className." NOT EXIST");			
			
		}else if($Request['op'] == "list"){
			$start= $Request['start']; if(!$start)  $start=0;
			$limit= $Request['limit']; if(!$limit)  $limit=30;
			$load = $className::load(); 
		}
		
	}
	
	
	public static function page($Request){
		
		
	}
	
	
}

?>