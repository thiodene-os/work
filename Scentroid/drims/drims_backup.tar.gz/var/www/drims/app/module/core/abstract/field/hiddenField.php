<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
class hiddenField extends field{
	

	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		
	}
	public function render(){
		
		$str .= "\n";
		if($this->value == ""){
			$str.= '<input name="'.$this->name.'" type="hidden" id="field_'.$this->id.'"  >'; 
		}else{			
			$str.= '<input name="'.$this->name.'" type="hidden" id="field_'.$this->id.'" value="'.htmlspecialchars($this->value).'">';
		}
		
		$str .= "\n";
		return $str;
	}
}