<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';

require_once(realpath(dirname(__FILE__))."/user.php");
require_once(realpath(dirname(__FILE__))."/company.php");

/*
 * User managerment handler.
 */
class userManager extends module{
	/* Shows login page 
	 * 
	 */
	public static function login($Request){
		$user = user::load(null,array("LOWER(email)='".trim(strtolower($Request['email']))."'" , "password='".md5(trim($Request['password']))."' " ));
		if(!$user){
			$parser = Parser::get();
			$parser->setVar("error", "Wrong credentials");
			$parser->parse("login");
			//$parser->redirect("{baseurl}do/security/user.signin", l("Wrong Password"));
		}else{
		
			$_SESSION['userId'] = $user->id;
			$parser = Parser::get();
			if ($user->expireat != "0" && $user->expireat < time() ){
                $parser->redirect("{baseurl}do/security/user.reset", l("Welcome"));
            }else if(userManager::hasRole("admin")){
				$parser->redirect("{baseurl}do/panel/panel.overview", l("Welcome"));
			}else{
				$parser->redirect("{baseurl}do/panel/panel.welcome", l("Welcome"));
			}
		}
	}
	/* Handles logout link 
	 * 
	 */
	public static function logout($Request){
		unset($_SESSION['userId']);
		$parser = Parser::get();
			$parser->redirect("{baseurl}do/security/user.signin", l("Logged Out"));
	}
	/*
	 * check if user is loggined. we use this in condtions,
	 */
	public static function isLogined(){
		if(isset($_SESSION['userId'])){
			return true;
		}
		return false;
	}
	/*
	 * get user from database if user is logined.
	 */
	public static function getUser(){
		if(self::isLogined()){
			return user::load($_SESSION['userId']);
		}
		return null;
	}
	/*
	 * check if user has a role or any of the roles in a array (OR)
	 */
	public static function hasRole($roles){
		$user= self::getUser();
		if(!$user){
			return false;
		}
		
		$roles = arrayit($roles);
		if(!$user->roles){
			$user->roles =array();
		}
		if(in_array("admin", $user->roles)){
			return true;
		}
		foreach($roles as $role){
			if(in_array($role, $user->roles)){
				return true;
			}
		}
		return false;
	}
	/*
	 * if user has not the role(s), redirects to login page.
	 */
	public static function checkRole($roles){
		
		if(!self::hasRole($roles)){
			$parser = Parser::get();
			$parser->redirect("{baseurl}do/security/user.signin");
		}
	}
	/*
	 * registers user.
	 */
	public static function register($Request){
		$user = User::load(null,array("email='".$Request['email']."' " ));
		if($user){
			echo "You Registered Before";
			return;
		}
		$user = new user();
		$user->email = $Request['email'];
		$user->password = md5($Request['password']);
		$user->save();
		if($user->id){
			echo "Registered Successfully";
		}else{
			echo "Registration Failed";
		}
		
	}
	public static function activate($Request){
		
	}
	/*
	 * Shows the user management page. the empty page. the contents are loaded form ajaxlist
	 */
	public static function page($Request){
		userManager::checkRole(array("admin","manager"));
		
		$parser = Parser::get();
		$parser->setVar("company", arrayit(company::load(null,array("order"=>"ORDER BY id DESC"))));
		
		if(userManager::hasRole("admin")){
				
			$parser->setVar("menu_1", "1");
			$parser->setVar("menu_1_2", "1");
		}else{
 			$parser->setVar("menu_2", "1");
 			$parser->setVar("menu_2_3", "1");
		}
		
	
		$parser->insert("contentblock", "list-user");
		$parser->parse("single");
		
	}
	/*
	 * shows the login page. if logined, shows the welcome page.
	 */
	public static function signin($Request){//loginpage
		$parser = Parser::get();
		if(userManager::isLogined()){
			if(userManager::hasRole("admin")){
				$parser->redirect("{baseurl}do/panel/panel.overview");				
			}else{
				$parser->redirect("{baseurl}do/panel/panel.welcome");
			}
			
		}else{
			$parser->parse("login");
		}
		
	}
	/*
	 * we don't have register yet. just to keep it for later.
	 */
	public static function signup($Request){//registerpage
		$parser = Parser::get();
		$parser->parse("register"); 
	}
	/*
	 * Shows a page to add user.
	 */
	public static function add($Request){
		userManager::checkRole(array("admin","manager"));
		
		$parser = Parser::get();
		if($Request['edit']){
			$obj= user::load($Request['edit']);
			$parser->setVar("obj", $obj);
            $companyExtra = company::load($obj->company)->extra;
            $equipmentCategories = array();
            if($companyExtra->equipment_category)
                $equipmentCategories = explode("\r\n",$companyExtra->equipment_category);
            $parser->setVar("equipmentCategories", $equipmentCategories );
		}
		$parser = Parser::get();
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_2", "1");
		$parser->setVar("menu_5", "1");
		$parser->setVar("menu_5_3", "1");
		$parser->setVar("roles", array("manager","user"));
		$parser->setVar("companies", company::bulkLoad(0,1000));
		$parser->insert("contentblock", "add-user");
		$parser->parse("single");
	}
	/*
	 * Save a user submitted from add page.
	 */
	public static function save($Request){
		userManager::checkRole(array("admin", "manager"));
		if(userManager::hasRole("manager") && !userManager::hasRole("admin")){
			$Request['company']= userManager::getUser()->company;
			$Request['role'] = 'user';
		}
		
		$obj = new user();
		if($Request['id']){
			$obj= user::load($Request['id']);
		}else{
			$obj->createdat= time();
				
		}
		$obj->id = $Request['id'];
		$obj->creator= userManager::getUser()->id;
		$obj->location= $Request['location'];
		if($Request['password']!="")
			$obj->password= md5($Request['password']);
		
		$obj->company= $Request['company'];
		$obj->gender= $Request['gender'];
		
		$obj->name= $Request['name'];
		$obj->family= $Request['family'];
		$obj->roles= array($Request['role']);
		
		$obj->tel= $Request['tel'];
		$obj->email= $Request['email'];
		$obj->createdat =time();
		if($Request['expireat']) {
		    if ($Request['expireat'] == "never") {
                $obj->expireat = 0;
            }else if (strtotime($Request['expireat']) >= time()){
                $obj->expireat=strtotime($Request['expireat']);
            } else {
                die("you should enter valid expire time for now or future. Past times are not acceptable");
            }
        }
        if($Request['extra']){
            $a = $Request['extra'];
            foreach($a as $k=>$v){
                $obj->extra->$k= $v;
            }
            $obj->extra->updatedat= time();
        }
		$obj->save();
		if($Request['role']=="manager"){
			$company = company::load($Request['company']);
			$company->manager= $obj->id;
			$company->save();
		}
		$parser= Parser::get();
		$parser->redirect("{baseurl}do/security/user.page");
	}
	/*
	 * Handles edit user page.
	 */
	public static function edit($Request){
		userManager::checkRole(array("admin","manager"));
		
		$Request['edit']= $Request['id'];
		self::add($Request);
	}
	/*
	 * Handles ajax list of users.
	 */
	public static function ajaxlist($Request){
		userManager::checkRole(array("admin","manager"));
	
		$cols = array("name","family","company","gender","tel","email","id");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}
		if(!$Request['length'])
			$Request['length']= 10;
		$company= userManager::getUser()->getCompany();
		
		
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `name` LIKE '%".$Request['search']['value']."%'  "
			." OR `name` LIKE '%".$Request['search']['value']."%'  OR `name` = '".$Request['search']['value']."'   "
			." OR `family` LIKE '%".$Request['search']['value']."%'  OR `family` = '".$Request['search']['value']."'  "
			." OR `email` LIKE '%".$Request['search']['value']."%'  OR `email` = '".$Request['search']['value']."'  "		
			;
				
		}
		
		if(!userManager::hasRole("admin")){
			if(trim(userManager::getUser()->company))
				$conds[] = " `company` = '".userManager::getUser()->company."' ";
		}
		if(userManager::hasRole(array("admin") && $Request['company'])){
			if(trim($Request['company']))
			$conds[] = " `company` = '".$Request['company']."' ";
		}
		$objs= user::load(null,$conds );
		unset($conds['limit']);
		$objs= arrayit($objs);
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		$out->recordsTotal = user::count($conds);
		$out->recordsFiltered =$out->recordsTotal;
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				if($col == "company"){
					$arr[]= company::load($objs[$i]->$col)->name;
				}else
					$arr[]= $objs[$i]->$col;
			}
				
			$out->data[] = $arr;
		}
		echo json_encode($out);
		
		
	}
	/*
	 * Deletes a user.
	 */
	public static function delete($Request){
		userManager::checkRole(array("admin","manager"));
		if($Request['id']=="10") die("you cannot delete admin");
		$user = user::load($Request['id']);
		if(userManager::getUser()->id !="10" &&  $user->company !=userManager::getUser()->company )
			die("illegal action 2");
		if($user->id ==userManager::getUser()->id ){
			die("are you removing yourself?!");
		}
		user::delete($Request['id']);
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/security/user.page");
	}

	/*
	 * Reset User Password Page
	 */
	public static function reset($Request){
        $parser = Parser::get();
        $parser->parse("reset");
    }

    /*
	 * Reset User Password Page
	 */
    public static function resetpassword($Request){
        $parser = Parser::get();
        if(!$Request['oldpassword']) {
            $parser->setVar("error" , "old password is empty");
            $parser->parse("reset");
            die();
        }else if ( md5($Request['oldpassword']) == userManager::getUser()->password){
            if(!$Request['newpassword1']) {
                $parser->setVar("error" , "new password is empty");
                $parser->parse("reset");
                die();
            } else if ($Request['newpassword1'] != $Request['newpassword2']) {
                $parser->setVar("error" , "new password should match its repeat");
                $parser->parse("reset");
                die();
            } else if ($Request['newpassword1'] == $Request['oldpassword']) {
                $parser->setVar("error" , "old and new passwords should not be the same");
                $parser->parse("reset");
                die();
            } else {
                $u = user::load(userManager::getUser()->id);
                $u->password = md5($Request['newpassword1']);
                $u->expireat = 0;
                $u->save();
                $parser->redirect("{baseurl}/do/security/user.signin");
            }
        } else {
            $parser->setVar("error" , "old password is wrong");
            $parser->parse("reset");
            die();
        }
    }
}
