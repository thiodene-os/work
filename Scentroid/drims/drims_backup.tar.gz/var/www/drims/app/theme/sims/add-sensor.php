
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span><?php echo $obj ? "Edit": "Add New";?> Sensor  for <?php echo $equipement->name?> - <?php echo userManager::getUser()->getCompany()->name?></span></div>
				<div class="box-content">
					<form action="{baseurl}do/panel/sensor.save" method="POST" class="form-horizontal">
						<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
						<input type="hidden" name="equipement" value="<?php echo $obj->equipement ? $obj->equipement: $equipement->id?>">
						
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Sensor Packet ID:</label>
							<div class="col-sm-6">
								<input name="packet_id" id="" type="text" class="form-control" value="<?php echo $obj->packet_id?$obj->packet_id:"S" ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Name:</label>
							<div class="col-sm-6">
								<input name="name" id="" type="text" class="form-control" value="<?php echo $obj->name ?>">
							</div>
						</div>
						<div class="hide form-group">
							<label for="" class="control-label col-sm-3">Type:</label>
							<div class="col-sm-6">
								<!-- <input name="type" id="" type="text" class="form-control"  value="<?php echo $obj->type ?>"> -->
								<select name="type" class="form-control" >
									<option <?php echo $obj->type == "pid" ? "selected": ""?> value="pid">PID</option>
									<option <?php echo $obj->type == "temp" ? "selected": ""?> value="temp">Temperature</option>
									<option <?php echo $obj->type == "humidity" ? "selected": ""?> value="humidity">Humidity</option>
									<?php for($i=0; $i<count(sensor::$special_sensors);$i++){?>
									<option <?php echo $obj->type == sensor::$special_sensors[$i] ? "selected": ""?> value="<?php echo sensor::$special_sensors[$i] ?>"><?php echo sensor::$special_sensors[$i] ?></option>
									<?php }?>
								</select>
								
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Data Unit:</label>
							<div class="col-sm-6">
								<input name="dataunit" id="" type="text" class="form-control"  value="<?php echo $obj->dataunit ?>">
							</div>
						</div>
						<div class="form-group hide">
							<label for="" class="control-label col-sm-3">Calibration factors:</label>
							<div class="col-sm-6">
								<input name="calibrationfactors[]" id="" type="text" class="form-control"  value="<?php echo $obj->calibrationfactors[0] ?>">
								<input name="calibrationfactors[]" id="" type="text" class="form-control"  value="<?php echo $obj->calibrationfactors[1] ?>">
								
							</div>
						</div>
						<div class="form-group ">
							<label for="" class="control-label col-sm-1">Alarm:</label>
							<div class="col-sm-offset-1 col-sm-10">
									<label for="inputValue" class="col-md-3 control-label">Send alarm at when sensor exceeds</label>
									<div class="col-md-1">
										 <input name="alarm_max_value" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_max_value ?>">
					                </div>
					                <label for="inputValue" class="col-md-1 control-label">, </label>
					                <div class="col-md-1">
										 <input name="alarm_value_num" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_value_num ?>"> 
					                					                										
					                </div>
					                <label for="inputValue" class="col-md-2 control-label"> times out of </label>
					                <div class="col-md-1">
										 <input name="alarm_value_total" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_value_total ?>">
										
					                </div>
					                 <label for="inputValue" class="col-md-3 control-label"> consecutive readings.  </label>
					        </div>​
						</div>
						<?php
						foreach($sensorSettings as $groupName => $setting){?>
						<div class="panel panel-default">
							<div class="panel-heading"><?php echo $groupName?></div>
					  		<div class="panel-body">
					  			<?php for($i=0; $i<count($setting); $i++){?>
								<div class="form-group">
										<label for="" class="control-label col-sm-5"><?php echo const2word($setting[$i][1])?>:</label>
										<div class="col-sm-4">
											<input name="extra[<?php echo $setting[$i][1]?>]" id="" type="text" class="form-control"  value="<?php echo get_object_vars($obj->extra)[$setting[$i][1]] ?>">
										</div>
										<div class="col-sm-3">
											<?php 
											if($setting[$i][1] =="RELAY_TRIGGER_LIMIT_KEY_NAME"){
												echo $obj->dataunit;
											}else{
												echo $setting[$i][3];
											}?>
										
										</div>
								</div>
								<?php }?>
							</div>
						</div>
						<?php }?>
							
						
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button class="btn btn-success" type="submit">Save</button>
								<a class="btn btn-info" href="{baseurl}do/panel/sensor.page?equipement=<?php echo $obj->equipement ? $obj->equipement: $equipement->id?>">Back to List of Sensors</a>
								
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
