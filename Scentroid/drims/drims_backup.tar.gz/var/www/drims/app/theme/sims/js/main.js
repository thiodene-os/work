
$(document).ready(function() {
//
	/*if (typeof jQuery != 'undefined') {  
	    // jQuery is loaded => print the version
	    alert($.fn.jquery);
	}*/
	$('.nav-toggle').click(function() {
		$(this).addClass('active');
		$('#sidebar').addClass('active');
		$('#sidebar').before("<div class='body-overlay'></div>");
		return false;
	});
	$(document).on('click', '.body-overlay',function() {
		$(this).remove();
		$('#sidebar, .nav-toggle').removeClass('active');
		return false;
	});
//
	$('#navigation>ul>li.active').find('ul').slideDown(0);
	$('#navigation>ul>li>a').click(function() {
		if($(this).parent('li').hasClass('active')) {
			$(this).parent('li').find('ul').slideUp(200);
			$(this).parent('li').removeClass('active');
		}else {
			$('#navigation>ul>li>ul').slideUp(200);
			$('#navigation>ul>li').removeClass('active');
			$(this).parent('li').addClass('active');
			$(this).parent('li').find('ul').slideDown(200);
		}
	    return false;
	});
//
	$('[data-toggle="tooltip"]').tooltip(); 
//
	/*var table = $('.data-table').DataTable();
	var tt = new $.fn.dataTable.TableTools( table );
	$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');*/
	
	function zeroFill(number, width) {
	    width -= number.toString().length;
	    if(width > 0) {
	        return new Array(width + (/\./.test(number) ? 2 : 1)).join('0') + number;
	    }
	    return number + ""; // always return a string
	}
	
	if($('#company-list').length)
	table= $('#company-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/security/company.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();

	            }
	          },
	          dom: 'T<"clear">lfrtip',
              "oTableTools": {
	              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      }
                  ]
              },
	        "columnDefs": [	
	                       {
	                           "render": function ( data, type, row ) {
	                        	   
	                        	   str = '<a class="btn btn-xs btn-danger" onclick="return confirm(\'Are You Sure?\')" href="/do/security/company.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
	                        	   str += '<a class="btn btn-xs btn-info" href="/do/security/company.edit?id='+data+'"><i class="fa fa-edit"></i><span>Edit</span></a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 4
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 3
	                       }
	                      ]
	    } );
	    if($('#equipement-list').length)
		table= $('#equipement-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/equipement.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	                d.company = $('select#company').val();

	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3 ,4]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3,4 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3,4]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3,4 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3,4 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-xs btn-danger"  onclick="return confirm(\'Are You Sure?\')" href="/do/panel/equipement.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
	                        	   str += '<a class="btn btn-xs btn-info" href="/do/panel/equipement.edit?id='+data+'"><i class="fa fa-edit"></i><span>Edit</span></a>'
	                        	   str += '<a class="btn btn-xs btn-info" href="/do/panel/sensor.page?equipement='+data+'"><i class="fa fa-circle"></i><span>Sensors</span></a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 5
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 4
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 3
	                       }
	                      ]
	    } );
	
		
	    if($('#sensor-list').length)
			table= $('#sensor-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "ajax": {
		            "url": "/do/panel/sensor.ajaxlist?equipement="+$('#equipement').val(),
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		        "columnDefs": [
		                       {
		                           "render": function ( data, type, row ) {
		                        	   str = '<a class="btn btn-xs btn-danger" onclick="return confirm(\'Are You Sure?\')" href="/do/panel/sensor.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
		                        	   str += '<a class="btn btn-xs btn-info" href="/do/panel/sensor.edit?id='+data+'"><i class="fa fa-edit"></i><span>Edit</span></a>'
		                        	   return str;
		                           },
		                           "orderable": false ,
		                           "targets": 5
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 4
		                       }
		                      
		                      ]
		    } );
	    if($('#msample-list').length)
			table= $('#msample-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "ajax": {
		            "url": "/do/panel/sample.ajaxlistmanual?id="+$('#equipement').val(),
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		          "oTableTools": {
		              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
		              "aButtons": [
	                      {
	                          "sExtends": "csv",
	                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "pdf",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "xls",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "copy",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "print",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      }
	                  ]
	              },
		        "columnDefs": [
		                       {
		                           "render": function ( data, type, row ) {
		                        	   str = '<a class="btn btn-xs btn-danger" onclick="return confirm(\'Are You Sure?\')" href="/do/panel/sample.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
		                        	   return str;
		                           },
		                           "orderable": false ,
		                           "targets": 4
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 3
		                       }
		                      
		                      ]
		    } );
		
		if($('#log-list').length)
			table= $('#log-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "order": [[ 0, "desc" ]],
		        "ajax": {
		            "url": "/do/panel/log.ajaxlist",
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		                d.type = $('select#logtype ').val();
		                d.equipement = $('select#equipement ').val();
		                d.company = $('select#company ').val();
		               
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		          "oTableTools": {
		              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
		              "aButtons": [
	                      {
	                          "sExtends": "csv",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
		                      },
		                      {
		                          "sExtends": "pdf",
		                          "mColumns": [ 0, 1, 2,3,4,5]
		                      },
		                      {
		                          "sExtends": "xls",
		                          "mColumns": [ 0, 1, 2,3,4,5 ]
		                      },
		                      {
		                          "sExtends": "copy",
		                          "mColumns": [ 0, 1, 2,3,4,5 ]
		                      },
		                      {
		                          "sExtends": "print",
		                          "mColumns": [ 0, 1, 2,3,4,5]
		                      }
	                  ]
	              },
		        "columnDefs": [ 
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 5
		                       }
		                      ]
		    } );
		if($('#sample-list').length)
			table= $('#sample-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "ajax": {
		            "url": "/do/panel/sample.ajaxlist",
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		                d.mindate2 = $('#mindate2 input').val();
		                d.maxdate2 = $('#maxdate2 input').val();
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		          "oTableTools": {
		              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
		              "aButtons": [
	                      {
	                          "sExtends": "csv",
	                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "pdf",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "xls",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "copy",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "print",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      }
	                  ]
	              },
		        "columnDefs": [
		                       {
		                           "render": function ( data, type, row ) {
		                        	   str = '<a class="btn btn-xs btn-danger" onclick="return confirm(\'Are You Sure?\')" href="/do/panel/sample.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
		                        	   str += '<a class="btn btn-xs btn-default" href="/do/panel/sample.edit?id='+data+'"><i class="fa fa-edit"></i><span>Edit</span></a>'

		                        	   return str;
		                           },
		                           "orderable": false ,
		                           "targets": 10
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 9
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 8
		                       }
		                      ]
		    } );
		if($('#user-list').length)
		table= $('#user-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/security/user.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	                d.company = $('select#company  option:selected').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/sims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3,4,5]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3,4,5]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-xs btn-danger"  onclick="return confirm(\'Are You Sure?\')" href="/do/security/user.delete?id='+data+'"><i class="fa fa-remove"></i><span>Delete</span></a>'
	                        	   str += '<a class="btn btn-xs btn-info" href="/do/security/user.edit?id='+data+'"><i class="fa fa-edit"></i><span>Edit</span></a>'

	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 6
	                       }
	                      ]
	    } );
//
	
				   
		  
			   if( $('#datetimepicker').length){
				   t= $('#datetimepicker input').val();
				   t*=1000;
				   $('#datetimepicker').datetimepicker();
				   $('#datetimepicker').data("DateTimePicker").date(new Date(t));
			   }
			 
			
			  
		   
		   if($("#mindate").length  && $("#maxdate").length ){
			 /*  $('#mindate input').keyup( function() { console.log(table); table.draw(); } );
			   $('#maxdate input').keyup( function() { console.log(table);  table.draw(); } );
			 */  $('#mindate').datetimepicker();
		        $('#maxdate').datetimepicker({
		            useCurrent: false //Important! See issue #1075
		        });
		        $("#mindate").on("dp.change", function (e) {
		            $('#maxdate').data("DateTimePicker").minDate(e.date);
		            mindate = moment(e.date).unix();
		            table.draw();
		            
		        });
		        $("#maxdate").on("dp.change", function (e) {
		            $('#mindate').data("DateTimePicker").maxDate(e.date);
		            maxdate = moment(e.date).unix();
		            table.draw();
		        });
		   }
		   if($('#datetimepicker, #mindate, #maxdate').length  ){
		        $('#datetimepicker, #mindate, #maxdate').data("DateTimePicker").icons({
			 		time: 'fa fa-clock-o',
			 		date: 'fa fa-calendar-o',
			 		up: 'fa fa-chevron-up',
					down: 'fa fa-chevron-down',
		 			previous: 'fa fa-chevron-left',
		 			next: 'fa fa-chevron-right',
		 			today: 'fa fa-crosshairs',
			 		clear: 'fa fa-trash',
			 		close: 'fa fa-remove'
		        });
		   }
	$('.dropdown-menu').click(function(e) {
        e.stopPropagation();
    });
	
   $('select#logtype ').change(function() {
 
	   table.draw();
   });
   $('select#dateOfSample').change(function() {
	   var val = $(this).val();
	   var equipement = $("#equipement").val();
	   $.get( "/do/panel/sensor.get_sample_times", { date: val , eq: equipement} ).done(function( data ) {
		   $("#timeOfSample").html("");
		   var string="";
		   $.each(data, function (d1,d2){
			   string+= '<option value="'+d2[0]+'">'+d2[1]+'</option>';
			
		   })
		   $("#timeOfSample").html(string);
		 
		   
	  });
   });
   
  
   
	 $('select#equipement').change(function() {
	 
		 table.draw();			   
	 });
	 $('select#company').change(function() {
		 table.draw();
	 });
	
	
	$("button#deletedata").click(function(){
		if(confirm("Are you sure?")){
			startDate = $("#mindate input").val();
			endDate = $("#maxdate input").val();
			equipementId = $("#equipementId").val();
			if(startDate.length ==0 & endDate.length ==0){
				if(confirm("Are you sure to remove whole data for this equipement?")){
					$.get( "/do/panel/sensor.deletedata", { id: equipementId} ).done(function( data ) {
					    alert( "Data Removed. Refreshing..." +data);
					    window.location.replace("/do/panel/panel.showequipement?id="+equipementId);
					  });
				}
			}else{
				$.get( "/do/panel/sensor.deletedata", { id: equipementId, startDate: startDate, endDate:endDate } ).done(function( data ) {
				    alert( "Data Removed. Refreshing..."+data);
				    window.location.replace("/do/panel/panel.showequipement?id="+equipementId);
				    
				  });
			}
		}
		
	});
	$("button#purgelog").click(function(){
		if(confirm("Are you sure?")){
			startDate = $("#mindate input").val();
			endDate = $("#maxdate input").val();
			type = $("#logtype").val();
			company = $("#company").val();
			equipement = $("#equipement").val();
					$.get( "/do/panel/log.deletedata", { equipement: equipement , startDate: startDate, endDate:endDate, type:type, company:company, equipement:equipement} ).done(function( data ) {
					    alert( "Data Removed. Refreshing..." +data);
					    window.location.replace("/do/panel/log.page");
					  });
				
			
		}
		
	});
	
	
		

});