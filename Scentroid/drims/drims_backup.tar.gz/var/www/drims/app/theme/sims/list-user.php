
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<a href="{baseurl}do/security/user.add"
				class="btn btn-large pull-right btn-success">Add New User</a>
			<div class="box-header">
				<span>User List</span>
			</div>
			<div class="box-content">
				<div class="flip-scroll">
					<div class="form-group">
					<div class="row">
						<div class="col-sm-12">
							<?php if($company && userManager::hasRole(array("admin"))){?>
								<div class="col-xs-4">
										<select  class="form-control" id="company">
											<option value="">-Any Company-</option>
											<?php for($i=0; $i<count($company);$i++){ ?>
											<option value="<?php echo $company[$i]->id ?>"><?php echo $company[$i]->name ?></option>
											<?php } ?>
										</select>
								</div>
								<?php }?>
								<div class="col-xs-4">
									<div class='input-group date' id='mindate'>
									<input type='text' class="form-control" name="date"   placeholder="from"  />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
									</div>
								</div>
								<div class="col-xs-4">
									<div class='input-group date' id='maxdate'>
									<input type='text' class="form-control" name="date"   placeholder="to"  />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
									</div>
								</div>
								
						</div>
					</div>
					</div>
					<table id="user-list"
						class="data-table table table-striped table-bordered">
						<thead>
							<tr>
								<th>Name</th>
								<th>Family</th>
								<th>Company</th>
								<th>Gender</th>
								<th>Phone</th>
								<th>Email</th>
								<th>Actions</th>
							</tr>
						</thead>

						<tfoot>
							<tr>
								<th>Name</th>
								<th>Family</th>
								<th>Company</th>
								<th>Gender</th>
								<th>Phone</th>
								<th>Email</th>
								<th>Actions</th>
							</tr>
						</tfoot>

						<tbody>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
