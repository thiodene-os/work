
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span><?php echo $obj ? "Edit": "Add ";?> Alarm for <?php echo $obj->name ?> - <?php echo $equipement->name?> - <?php echo userManager::getUser()->getCompany()->name?></span></div>
				<div class="box-content">
					<form action="{baseurl}do/panel/sensor.savealarm" method="POST" class="form-horizontal">
						<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
					
						<div class="form-group ">
							<label for="" class="control-label col-sm-3">Alarm:</label>
							<div class="col-sm-offset-1 col-sm-11">
									<label for="inputValue" class="col-md-4 control-label">Send alarm at when sensor exceeds</label>
									<div class="col-md-1">
										 <input name="alarm_max_value" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_max_value ?>">
					                </div>
					                <label for="inputValue" class="col-md-1 control-label">, </label>
					                <div class="col-md-1">
										 <input name="alarm_value_num" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_value_num ?>"> 
					                					                										
					                </div>
					                <label for="inputValue" class="col-md-2 control-label"> times out of </label>
					                <div class="col-md-1">
										 <input name="alarm_value_total" id="" type="text" class="form-control "  value="<?php echo $obj->alarm_value_total ?>">
										
					                </div>
					                 <label for="inputValue" class="col-md-2 control-label"> consecutive readings.  </label>
					                
								  
					                
							</div>​
								 
						</div>
						
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button class="btn btn-success" type="submit">Save</button>
								<a class="btn btn-info" href="{baseurl}do/sensor.page?equipement=<?php echo $equipement->id?>">Back to List of Sensors</a>
								
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
