<?php //var_dump($weather) ?>
<div class="weather-now row">
    <div class="col-xs-5">
        <i class="wi wi-<?php echo weatherManager::getIcon($weather->item->condition->code)?>"></i>
    </div>
    <div class="col-xs-7">
        <span><?php echo $weather->item->condition->temp ?></span>
        <div><?php echo $weather->item->condition->text?></div>
    </div>
</div>
<div class="row">
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Sunrise">
            <i class="wi wi-sunrise"></i>
            <span><?php echo $weather->astronomy->sunrise ?></span>
        </div>
    </div>
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Sunset">
            <i class="wi wi-sunset"></i>
            <span><?php echo $weather->astronomy->sunset ?></span>
        </div>
    </div>
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Wind Direction">
            <i class="wi wi-wind-direction"></i>
            <span> <?php echo $weather->wind->direction ?> degree(s)</span>
        </div>

    </div>
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Pressure">
            <i class="wi wi-barometer"></i>
            <span><?php echo $weather->atmosphere->pressurekpa ?> kPa</span>
        </div>
    </div>
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Humidity">
            <i class="wi wi-humidity"></i>
            <span><?php echo $weather->atmosphere->humidity ?> %</span>
        </div>
    </div>
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Wind Speed">
            <i class="wi wi-strong-wind"></i>
            <span><?php echo $weather->wind->speed ?>km/h </span>
        </div>
    </div>
    <?php /*
    <div class="col-xs-6">
        <div class="weather-feature" data-toggle="tooltip" title="Wind Chill">
            <i class="wi wi-windy"></i>
            <span> <?php echo $weather->wind->chill ?></span>
        </div>
    </div>
        */ ?>

</div>
