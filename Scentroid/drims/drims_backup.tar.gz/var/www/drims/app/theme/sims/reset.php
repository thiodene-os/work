<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>IDES Canada sims Panel</title>
	<link href="{baseurl}app/theme/sims/css/bootstrap.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/font-awesome.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/jquery.dataTables.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/main.css" rel="stylesheet">
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<div class="mbox">
				<div class="mbox-header"><span>Password Reset- beta</span></div>
				<div class="mbox-content">
					<?php if ($error){?>
						<div class="alert alert-danger" role="alert">
						  <span class="fa fa-info-circle" aria-hidden="true"></span>
						  <span class="sr-only">Error:</span>
							<?php echo $error?>;
						  </div>
					<?php }?>
					<form action="{baseurl}do/security/user.resetpassword" method="POST">

						<div class="form-group">
							<div class="input-group">
								<label for="" class="input-group-addon"><i class="fa fa-lock"></i></label>
								<input name="oldpassword" id="" type="password" class="form-control" placeholder="Old Password">
							</div>
						</div>
                        <div class="form-group">
                            <div class="input-group">
                                <label for="" class="input-group-addon"><i class="fa fa-lock"></i></label>
                                <input name="newpassword1" id="" type="password" class="form-control" placeholder="New Password">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <label for="" class="input-group-addon"><i class="fa fa-lock"></i></label>
                                <input name="newpassword2" id="" type="password" class="form-control" placeholder="Repeat New Password">
                            </div>
                        </div>
						<div class="form-group">
							<div class="row">
								<div class="col-xs-6 col-xs-offset-3">
									<button class="btn btn-success btn-block" type="submit">Change Password</button>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
	<script src="{baseurl}app/theme/simsjs/jquery-1.11.3.min.js"></script>
	<script src="{baseurl}app/theme/simsjs/bootstrap.min.js"></script>
	<script src="{baseurl}app/theme/simsjs/jquery.dataTables.min.js"></script>
	<script src="{baseurl}app/theme/simsjs/dataTables.tableTools.min.js"></script>
	<script src="{baseurl}app/theme/simsjs/dataTables.bootstrap.min.js"></script>
	<script src="{baseurl}app/theme/simsjs/main.js"></script>
</body>
</html>