
<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<span><?php echo $obj ? "Edit": "Add New";?> user</span>
			</div>
			<div class="box-content">
				<form action="{baseurl}do/security/user.save" method="POST"
					class="form-horizontal">
				    	<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
						<div class="form-group">
						<label for="" class="control-label col-sm-3">Name:</label>
						<div class="col-sm-6">
							<input name="name" id="" type="text" class="form-control"  value="<?php echo $obj->name?>">
						</div>
					</div>
					<div class="form-group">
						<label for="" class="control-label col-sm-3">Family:</label>
						<div class="col-sm-6">
							<input name="family" id="" type="text" class="form-control"  value="<?php echo $obj->family?>">
						</div>
					</div>
					<div class="form-group">
						<label for="" class="control-label col-sm-3">Email:</label>
						<div class="col-sm-6">
							<input name="email" id="" type="email" class="form-control"  value="<?php echo $obj->email?>">
						</div>
					</div>
					<div class="form-group">
						<label for="" class="control-label col-sm-3">Password:</label>
						<div class="col-sm-6">
							<input name="password" id="" type="text" class="form-control"  value="<?php echo ""?>">
						</div>
						<?php if($obj){ echo "Type to change password, otherwise leave it blank" ; } ?>
					</div>
                    <div class="form-group">
                        <label for="" class="control-label col-sm-3">Password Expiry:</label>
                        <div class="col-sm-6">
                            <select name="expireat">
                                <option>never</option>
                                <option>now</option>
                                <option>+1 hour</option>
                                <option>+1 day</option>
                                <option>+7 days</option>
                                <option>+14 days</option>
                                <option>+30 days</option>
                                <option>+365 days</option>
                            </select>
                        </div>
                    </div>
                    <?php if($obj) {?>
                    <div class="form-group">
                        <label for="" class="control-label col-sm-3">Accessible Equipment Categories:</label>
                        <div class="col-sm-6">
                            <select multiple name="extra[equipment_category][]" class="form-control">
                                <option <?php if(!$obj->extra->equipment_category) echo "selected" ?> value="">All</option>
                                <?php foreach($equipmentCategories as $category) {?>
                                    <option <?php if(in_array($category, $obj->extra->equipment_category)) echo "selected" ?>><?php echo $category?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <?php } ?>
					<div class="form-group">
							<label for="" class="control-label col-sm-3">Gender:</label>
							<div class="col-sm-6">
								<div class="radio">
									<label><input <?php echo $obj->gender =="m" ? ' checked="checked" ':'' ?> name="gender" id="" type="radio" value="m">Male</label>
									<label><input <?php echo $obj->gender =="f" ? ' checked="checked" ':'' ?> name="gender" id="" type="radio" value="f">Female</label>
									<label><input <?php echo $obj->gender =="o" ? ' checked="checked" ':'' ?> name="gender" id="" type="radio" value="o">Other</label>								
								</div>
							</div>
						</div>
					
					<div class="form-group">
						<label for="" class="control-label col-sm-3">Phone:</label>
						<div class="col-sm-6">
							<input name="tel" id="" type="text" class="form-control"  value="<?php echo $obj->id?>">
						</div>
					</div>
						<?php if(userManager::hasRole(array("admin"))){?>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Company:</label>
							<div class="col-sm-6">
								<select name="company">
										<?php for($i=0; $i<count($companies); $i++){ ?>
											<option
										<?php echo $obj->company==$companies[$i]->id ? ' selected="selected" ':''?>
										value="<?php echo $companies[$i]->id?>"><?php echo $companies[$i]->name?></option>	
										<?php }?>
									</select> <a href="{baseurl}do/panel/company.add"
									class="btn btn-small push-right btn-info">Add new company</a>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Role:</label>
							<div class="col-sm-6">
								<select name="role" >
										<?php for($i=0; $i<count($roles); $i++){ ?>
											<option
										<?php echo $obj->role==$roles[$i] ? ' selected="selected" ':''?>
										value="<?php echo $roles[$i]?>"><?php echo $roles[$i]?></option>	
										<?php }?>
									</select> 
							</div>
						</div>
						<?php }?>
						<div class="form-group">
						<div class="col-sm-offset-3 col-sm-6">
							<button class="btn btn-success" type="submit">Add</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
