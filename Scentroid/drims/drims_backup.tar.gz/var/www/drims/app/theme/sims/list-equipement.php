
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<a href="{baseurl}do/panel/equipement.add" class="btn btn-large pull-right btn-success">Add New Equipement</a>
				<div class="box-header"><span>Equipement List</span></div>
				<div class="box-content">
					<div class="flip-scroll">
						<div class="form-group">
								<div class="row">
								
									<?php if($company){?>
									<div class="col-xs-4">
											<select  class="form-control" id="company">
												<option value="">-Any Company-</option>
												<?php for($i=0; $i<count($company);$i++){ ?>
												<option value="<?php echo $company[$i]->id ?>"><?php echo $company[$i]->name ?></option>
												<?php } ?>
											</select>
									</div>
									<?php }?>
									
									<div class="col-xs-4">
										<div class='input-group date' id='mindate'>
										<input type='text' class="form-control" name="date"   placeholder="from"  />
										<span class="input-group-addon">
											<span class="fa fa-calendar"></span>
										</span>
										</div>
									</div>
									<div class="col-xs-4">
										<div class='input-group date' id='maxdate'>
										<input type='text' class="form-control" name="date"   placeholder="to"  />
										<span class="input-group-addon">
											<span class="fa fa-calendar"></span>
										</span>
										</div>
									</div>
									
								</div>
						</div>
						<table id="equipement-list" class="data-table table table-striped table-bordered">
						    <thead>
						        <tr>
						    	    <th>Company</th>
						            <th>Name</th>
						            <th>SN</th>
   						            <th>Created at</th>
   						            <th>Calibrated at</th>
						            <th>Actions</th>
						        </tr>
						    </thead>
						 
						    <tfoot>
						         <tr>
						         	<th>Company</th>
						            <th>Name</th>
						            <th>SN</th>
						            <th>Created at</th>
						           	<th>Calibrated at</th>
						            <th>Actions</th>
						        </tr>
						    </tfoot>
						 
						    <tbody>
					
						    </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
