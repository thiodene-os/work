<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header"><span>Latest Samples for <?php echo $equipement->name?></span>
			<a href="{baseurl}do/panel/panel.showequipement?id=<?php echo $equipement->id?>" class="btn btn-success">Back to Equipment</a>
                &nbsp;<a id="purge_now" href="" class="btn btn-success">Fill Bag</a>
            </div>
				<?php for($i=0; $i<count($pidSensors);$i++){ ?>
                    <?php if(strtolower($pidSensors[$i]->name)=="altitude"){
                        $lon = $lastSample[$pidSensors[$i]->id]->lon;
                        $lat = $lastSample[$pidSensors[$i]->id]->lat;
                        $latlonago = ago( $lastSample[$pidSensors[$i]->id]->sampledat);
                    }
                    ?>
					<div class="col-md-3">
					<h3><?php echo $pidSensors[$i]->name;?></h3>
					<span class="badge"><?php echo $lastSample[$pidSensors[$i]->id]->value;?></span> 
					<?php echo $pidSensors[$i]->dataunit;?>
					<br>
					<?php echo ago( $lastSample[$pidSensors[$i]->id]->sampledat);?>
					</div>
				<?php }?>
            <div class="col-md-3">
                <h3>Latitude</h3>
                <span class="badge"><?php echo $lat?></span>

                <br>
                <?php echo $latlonago; ?>
            </div>
            <div class="col-md-3">
                <h3>Longtitude</h3>
                <span class="badge"><?php echo $lon?></span>

                <br>
                <?php echo $latlonago; ?>
            </div>
        </div>
    </div>
</div>
