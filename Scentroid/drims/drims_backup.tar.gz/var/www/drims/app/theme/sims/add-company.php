
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span><?php echo $obj ? "Edit": "Add New";?> Company</span></div>
				<div class="box-content">
					<form action="{baseurl}do/security/company.save" method="POST" class="form-horizontal">
						<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Name: (Required)</label>
							<div class="col-sm-6">
								<input required name="name" id="" type="text" class="form-control" value="<?php echo $obj->name ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">City: (Required)</label>
							<div class="col-sm-6">
								<input required name="city" id="" type="text" class="form-control"  value="<?php echo $obj->city ? $obj->city:"Toronto, ON"?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Timezone: (Required)</label>
							<div class="col-sm-6">
								<input required  name="timezone" id="" type="text" class="form-control"  value="<?php echo $obj->timezone ? $obj->timezone:"0" ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Alarm Email: </label>
							<div class="col-sm-6">
								<input  name="alarm_email" id="" type="text" class="form-control"  value="<?php echo $obj->alarm_email  ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Address:</label>
							<div class="col-sm-6">
								<input name="address" id="" type="text" class="form-control"  value="<?php echo $obj->address ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Tel:</label>
							<div class="col-sm-6">
								<input name="tel" id="" type="text" class="form-control"  value="<?php echo $obj->tel ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Logo:</label>
							<div class="col-sm-6">
								<input name="logo" id="" type="text" class="form-control"  value="<?php echo $obj->logo ?>">
							</div>
						</div>
                        <div class="form-group">
                            <label for="" class="control-label col-sm-3">Equipment Categories (separated by new lines):</label>
                            <div class="col-sm-6">
                                <textarea name="extra[equipment_category]"  class="form-control"><?php echo $obj->extra->equipment_category ?></textarea>
                            </div>
                        </div>
						
						<div class="form-group">
							<div class="col-sm-6 col-sm-offset-3">
								<button class="btn btn-success" type="submit">Save</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
