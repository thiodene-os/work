<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>IDES CANADA DRIMS: Dashboard</title>
	
	<link href="{baseurl}app/theme/sims/css/bootstrap.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/font-awesome.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/weather-icons.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/jquery.dataTables.min.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/daterangepicker.css" rel="stylesheet">
	<link href="{baseurl}app/theme/sims/css/bootstrap-datetimepicker.min.css" rel="stylesheet">
	
	<link href="{baseurl}app/theme/sims/js/amcharts/plugins/export/export.css" rel="stylesheet">
	
	<link href="{baseurl}app/theme/sims/css/main.css" rel="stylesheet">
	
</head>
<body>
<header id="header">
	<h1 id="logo"><a href="{baseurl}"></a></h1>
	<?php if(userManager::getUser()->getCompany()->logo){?>
	<img class="img-responsive col-sm-1"  src="<?php echo  userManager::getUser()->getCompany()->logo ?>">
	<?php }?>
	<button class="nav-toggle" type="button"><i class="fa fa-bars"></i></button>
	<div class="user-nav">
		<img src="{baseurl}app/theme/sims/img/avatar.png" alt="" class="user-avatar">
		<span class="user-name"><?php echo userManager::getUser()->name." ".userManager::getUser()->family."(".userManager::getUser()->getCompany()->name.")"?></span>
		<a href="{baseurl}do/security/user.logout" class="btn-logout btn btn-danger"><i class="fa fa-sign-out"></i><span>Sign Out</span></a>
	</div>
</header>
<aside id="sidebar">
	<div id="sidebar-back"></div>
	<div id="sidebar-contnet">
		<nav id="navigation">
			<ul>
				<?php if(userManager::hasRole("admin")){?>
				<li class="<?php echo $menu_1 ? "active" : ""  ?>"><a href=""><i class="fa fa-diamond"></i><span>DRIMS Management</span></a>
					<ul>
						<li class="<?php echo $menu_1_0 ? "active" : ""  ?>"><a href="{baseurl}do/panel/panel.overview"><span>Overview</span></a></li>
						<li class="<?php echo $menu_1_1 ? "active" : ""  ?>"><a href="{baseurl}do/security/company.page"><span>Companies</span></a></li>
						<li class="<?php echo $menu_1_2 ? "active" : ""  ?>"><a href="{baseurl}do/security/user.page"><span>Users</span></a></li>
						<li class="<?php echo $menu_1_3 ? "active" : ""  ?>"><a href="{baseurl}do/panel/equipement.page"><span>Equipements</span></a></li>
						<li class="<?php echo $menu_1_4 ? "active" : ""  ?>"><a href="{baseurl}do/panel/log.page"><span>Logs</span></a></li>
                        <li class="<?php echo $menu_1_5 ? "active" : ""  ?>"><a href="{baseurl}do/panel/setting.edit"><span>Settings</span></a></li>

                    </ul>
				</li>
				<?php } ?>
				<?php if(userManager::hasRole(array("manager", "user"))){?>
				<li class="<?php echo $menu_2 ? "active" : ""  ?>"><a href=""><i class="fa fa-building"></i><span>Company Management</span></a>
					<ul>
						<li class="<?php echo $menu_2_1 ? "active" : ""  ?>"><a href="{baseurl}do/panel/panel.showequipement"><span>Panel</span></a></li>						
						<li class="<?php echo $menu_2_2 ? "active" : ""  ?>"><a href="{baseurl}do/panel/log.page"><span>Logs</span></a></li>
						<?php if(userManager::hasRole(array("manager"))){?>
						<li class="<?php echo $menu_2_3 ? "active" : ""  ?>"><a href="{baseurl}do/security/user.page"><span>Users</span></a></li>
						<?php }?>
					</ul>
				</li>
				<?php } ?>
				
			</ul>
		</nav>
	</div>
</aside>
<section id="wrapper">
	{sh:contentblock}
</section>
	
	<script src="{baseurl}app/theme/sims/js/jquery-1.11.3.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/bootstrap.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/jquery.dataTables.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/dataTables.tableTools.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/dataTables.bootstrap.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/amcharts.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/serial.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/themes/light.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/plugins/export/export.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/plugins/export/export.config.default.js"></script>
	<script src="{baseurl}app/theme/sims/js/amcharts/plugins/dataloader/dataloader.min.js" type="text/javascript"></script>
	
	<script src="{baseurl}app/theme/sims/js/moment.min.js"></script>
	<script src="{baseurl}app/theme/sims/js/daterangepicker.js"></script>
		<script src="{baseurl}app/theme/sims/js/bootstrap-datetimepicker.min.js"></script>
	
	<script src="{baseurl}app/theme/sims/js/main.js"></script>
	
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&"></script>
	
	<script>
<?php echo $script ?>
$("#weather-box").load(
    "/do/weather/weather.get_weather?equipment=<?php echo $equipement->id?>"
);

if($("#sensor-map").length){
		
		function initialize() {
			<?php if($locSample and is_array($locSample)){
                $firstLoc =  array_values($locSample)[0];
			    ?>
			var myLatlng = new google.maps.LatLng(<?php echo $firstLoc->lat ?>, <?php echo $firstLoc->lon ?>);
			<?php } ?>
			var mapOptions = {
				<?php if(userManager::hasRole("admin")){?>
				zoom: 1,
				<?php }else{?>
				zoom: 14,
				<?php } ?>
				scrollwheel: false,
				<?php if($firstLoc &&$firstLoc->lat != ""){?>
				center: myLatlng,
				<?php }else{?>
				center:  new google.maps.LatLng(0,0),
				<?php } ?>
				mapTypeId: google.maps.MapTypeId.ROADMAP,
				styles: [{"featureType":"landscape","stylers":[{"hue":"#FFBB00"},{"saturation":43.400000000000006},{"lightness":37.599999999999994},{"gamma":1}]},{"featureType":"road.highway","stylers":[{"hue":"#FFC200"},{"saturation":-61.8},{"lightness":45.599999999999994},{"gamma":1}]},{"featureType":"road.arterial","stylers":[{"hue":"#FF0300"},{"saturation":-100},{"lightness":51.19999999999999},{"gamma":1}]},{"featureType":"road.local","stylers":[{"hue":"#FF0300"},{"saturation":-100},{"lightness":52},{"gamma":1}]},{"featureType":"water","stylers":[{"hue":"#0078FF"},{"saturation":-13.200000000000003},{"lightness":2.4000000000000057},{"gamma":1}]},{"featureType":"poi","stylers":[{"hue":"#00FF6A"},{"saturation":-1.0989010989011234},{"lightness":11.200000000000017},{"gamma":1}]}]
			}
			var map = new google.maps.Map(document.getElementById('sensor-map'), mapOptions);

			<?php foreach($locSample as $eqId => $locS) {
				if($locS->lat == "" ) continue; ?>
			var myLatlng<?php echo $i?> = new google.maps.LatLng(<?php echo $locS->lat ?>,<?php echo $locS->lon ?>);
			var marker = new google.maps.Marker({
				position: myLatlng<?php echo $i?>,
				map: map,
				title: '<?php echo $locS->equipement?>'
			});
			<?php } ?>
		
		}
		google.maps.event.addDomListener(window, 'load', initialize);
}		

	<?php if($panel){?>
	
	var chart = AmCharts.makeChart("chart-0", {
		"type": "serial",
		"theme": "light",
		"legend": {
			"equalWidths": true,
			"valueAlign": "left",
			"valueWidth": 10
		},
		//"dataProvider": ,
		"mouseWheelZoomEnabled": true,
		"dataLoader": {
		    "url": "/do/panel/sensor.scentinelChart?id=<?php echo $equipement->id?>&startDate=<?php echo $startDate?>&endDate=<?php echo $endDate?>",
		    "format": "json",
		    "showErrors": true,
		    "async": true,
		    "reload": 60,
		    "showCurtain":false
		   
		  },
		"valueAxes": [{
			"id": "leftAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"position": "left",
			"title": "Temperature (C)"
		}, {
			"id": "rightAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"title": "Humidity (%)",
			"position": "right"
			
		}],
		"graphs": [
		<?php for($i=0; $i<count($chartNames); $i++){?>
		{
	        "id": "g<?php echo $i+1?>",
			"balloonText": "[[<?php echo $chartNames[$i]->name?>]] <?php echo $chartNames[$i]->unit?>",
			"legendValueText": "[[<?php echo  $chartNames[$i]->name?>]]",
			"title": "<?php echo $chartNames[$i]->name ?>",
			"fillAlphas": 0,
			"valueField": "<?php echo  $chartNames[$i]->name?>",
			<?php if($chartNames[$i]->type == "humidity") { ?>
			"valueAxis": "rightAxis"
			<?php }else{?>
			"valueAxis": "leftAxis"
			<?php }?>
		}<?php	if($i != count($chartNames)-1)	echo ","; }?>
		],
		"chartCursor": {
			"categoryBalloonDateFormat": "DD-MM-YYYY JJ:NN",
			"cursorAlpha": 0.1,
			"cursorColor":"#000000",
			 "fullWidth":true,
			"valueBalloonsEnabled": true,
			"zoomable": true,
			"pan": true,
		},
		"dataDateFormat": "DD-MM-YYYY JJ:NN",
		"categoryField": "date",
		"categoryAxis": {
			"parseDates": true,
			"minPeriod" : "mm",
			"dateFormats" : [{
			    period: 'ss',
			    format: 'JJ:NN:SS'
			}, {
			    period: 'mm',
			    format: 'JJ:NN'
			}, {
			    period: 'hh',
			    format: 'JJ:NN'
			}, {
			    period: 'DD',
			    format: 'MMM DD'
			}, {
			    period: 'MM',
			    format: 'MMM YYYY'
			}, {
			    period: 'YYYY',
			    format: 'MMM YYYY'
			}],
	        "minorGridEnabled": true
		},
		"chartScrollbar": {
	        "oppositeAxis":false,
	        "offset":30,
	        "scrollbarHeight": 30,
	        "backgroundAlpha": 0,
	        "selectedBackgroundAlpha": 0.1,
	        "selectedBackgroundColor": "#888888",
	        "graphFillAlpha": 0,
	        "graphLineAlpha": 0.5,
	        "selectedGraphFillAlpha": 0,
	        "selectedGraphLineAlpha": 1,
	        "autoGridCount":true,
	        "color":"#AAAAAA"
	    },
		"export": {
			"enabled": true
		 }
	});

	//chard odour concentration
	var chart = AmCharts.makeChart("chart-oc", {
		"type": "serial",
		"theme": "light",
		"legend": {
			"equalWidths": true,
			"valueAlign": "left",
			"valueWidth": 10
		},
		"mouseWheelZoomEnabled": true,
		"dataLoader": {
		    "url": "/do/panel/sensor.scentinelOdourConcentrationChart?id=<?php echo $equipement->id?>&startDate=<?php echo $startDate?>&endDate=<?php echo $endDate?>",
		    "format": "json",
		    "showErrors": true,
		    "async": true,
		    "reload": 60,
		    "showCurtain":false
		  },
		"valueAxes": [{
			"id": "rightAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"title": "Measured Odour Concentration (ou/m3)",
			"position": "right"
			
		}, {
			"id": "leftAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"title": "Predicted Odour COncentration (ou/m3)",
			"position": "left"
			
		}],
		"graphs": [
		{
	        "id": "g1",
			"balloonText": "[[predicted]]",
			"legendValueText": "[[predicted]]",
			"title": "Predicted Odour COncentration (ou/m3)",
			"fillAlphas": 0,
			"valueField": "predicted",
			"valueAxis": "leftAxis"
			
		},
		{
	        "id": "g2",
			"balloonText": "[[manual]] ",
			"legendValueText": "[[manual]]",
			"title":  "Measured Odour Concentration (ou/m3)",
			"fillAlphas": 0,
			"valueField": "manual",
			"valueAxis": "rightAxis"
		}
		],
		"chartCursor": {
			"categoryBalloonDateFormat": "DD-MM-YYYY JJ:NN",
			"cursorAlpha": 0.1,
			"cursorColor":"#000000",
			 "fullWidth":true,
			"valueBalloonsEnabled": true,
			"zoomable": true,
			"pan": true,
		   // "valueLineEnabled": true
		},
		"dataDateFormat": "DD-MM-YYYY JJ:NN",
		"categoryField": "date",
		"categoryAxis": {
			"parseDates": true,
			"minPeriod" : "mm",
			"dateFormats" : [{
			    period: 'ss',
			    format: 'JJ:NN:SS'
			}, {
			    period: 'mm',
			    format: 'JJ:NN'
			}, {
			    period: 'hh',
			    format: 'JJ:NN'
			}, {
			    period: 'DD',
			    format: 'MMM DD'
			}, {
			    period: 'MM',
			    format: 'MMM YYYY'
			}, {
			    period: 'YYYY',
			    format: 'MMM YYYY'
			}],
			//"equalSpacing":true,
	        "minorGridEnabled": true
		},
		"chartScrollbar": {
	       // "graph": "g1",
	        "oppositeAxis":false,
	        "offset":30,
	        "scrollbarHeight": 30,
	        "backgroundAlpha": 0,
	        "selectedBackgroundAlpha": 0.1,
	        "selectedBackgroundColor": "#888888",
	        "graphFillAlpha": 0,
	        "graphLineAlpha": 0.5,
	        "selectedGraphFillAlpha": 0,
	        "selectedGraphLineAlpha": 1,
	        "autoGridCount":true,
	        "color":"#AAAAAA"
	    },
		"export": {
			"enabled": true
		 }
	});


	//pid
	<?php for($j=0; $j<count($pidSensors); $j++){ ?>
	var chart2 = AmCharts.makeChart("chart-<?php echo $j+1?>", {
		"type": "serial",
		"theme": "light",
		"legend": {
			"equalWidths": true,
			"valueAlign": "left",
			"valueWidth": 10
		},
	    "mouseWheelZoomEnabled": true,
		"dataLoader": {
		    "url": "/do/panel/sensor.pidChart?pid=<?php echo $pidSensors[$j]->id?>&gas=<?php echo urlencode($gas)?>&startDate=<?php echo $startDate?>&endDate=<?php echo $endDate?>",
		    "format": "json",
		    "showErrors": true,
		    "async": true,
		    "reload": 60,
		    "showCurtain":true
		    
		  },
		"valueAxes": [ {
			"id": "rightAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"labelsEnabled": true,
			"title": "<?php echo $pidSensors[$j]->name ?> (<?php echo $pidSensors[$j]->dataunit ?>)",
			"position": "right",
			"guides": [
				<?php if( $pidChartGuides[$j]['avg']){
				?>{
	            "dashLength": 6,
	            "inside": true,
	            "label": "min",
	            "lineAlpha": 1,
	            "value":<?php echo $pidChartGuides[$j]['min']?>
	        	},{
	            "dashLength": 6,
	            "inside": true,
	            "label": "max",
	            "lineAlpha": 1,
	            "value": <?php echo $pidChartGuides[$j]['max']?>
	       	 	},{
	            "dashLength": 6,
	            "inside": true,
	            "label": "average",
	            "lineAlpha": 1,
	            "value": <?php echo $pidChartGuides[$j]['avg']?>
	       		}
		        <?php }?>],
			
		}],
		"graphs": [
		 {
			"dashLengthField": "dashLength",
             <?php if(strtolower($pidSensors[$j]->name)=="altitude"){ ?>
             "balloonText": "Altitude: [[Altitude]] <br> Longitude: [[Longitude]] <br> Latitude: [[Latitude]]",
             <?php } ?>
             "legendValueText": "[[<?php echo  $pidSensors[$j]->name?>]]",
			"title": "<?php echo  $pidSensors[$j]->name?>",
			"fillAlphas": 0,
			"valueField": "<?php echo  $pidSensors[$j]->name?>",
			"valueAxis": "rightAxis"
		
		}
		],
		"chartCursor": {
			"categoryBalloonDateFormat": "DD-MM-YYYY JJ:NN",
			"cursorAlpha": 0.1,
			"cursorColor":"#000000",
			 "fullWidth":true,
			"valueBalloonsEnabled": true,
			"zoomable": true,
			"pan": true,
		   // "valueLineEnabled": true
		},
		"dataDateFormat": "DD-MM-YYYY JJ:NN",
		"categoryField": "date",
		"categoryAxis": {
			"parseDates": true,
			"minPeriod" : "mm",
			"dateFormats" : [{
			    period: 'ss',
			    format: 'JJ:NN:SS'
			}, {
			    period: 'mm',
			    format: 'JJ:NN'
			}, {
			    period: 'hh',
			    format: 'JJ:NN'
			}, {
			    period: 'DD',
			    format: 'MMM DD'
			}, {
			    period: 'MM',
			    format: 'MMM YYYY'
			}, {
			    period: 'YYYY',
			    format: 'MMM YYYY'
			}],
			//"equalSpacing":true,
	        "minorGridEnabled": true
		},
		"chartScrollbar": {
	       // "graph": "g1",
	        "oppositeAxis":false,
	        "offset":30,
	        "scrollbarHeight": 30,
	        "backgroundAlpha": 0,
	        "selectedBackgroundAlpha": 0.1,
	        "selectedBackgroundColor": "#888888",
	        "graphFillAlpha": 0,
	        "graphLineAlpha": 0.5,
	        "selectedGraphFillAlpha": 0,
	        "selectedGraphLineAlpha": 1,
	        "autoGridCount":true,
	        "color":"#AAAAAA"
	    },
		"export": {
			"enabled": true
		 }
	});


	<?php } ?>

	var chart3 = AmCharts.makeChart("chart-wind", {
		"type": "serial",
		"theme": "light",
		"legend": {
			"equalWidths": true,
			"valueAlign": "left",
			"valueWidth": 10
		},
	    "mouseWheelZoomEnabled": true,
		//"dataProvider": ,
		"dataLoader": {
		    "url": "/do/panel/sensor.windChart?id=<?php echo $equipement->id?>&startDate=<?php echo $startDate?>&endDate=<?php echo $endDate?>",
		    "format": "json",
		    "showErrors": true,
		    "async": true,
		    "reload": 60,
		    "showCurtain":true
		    
		  },
		"valueAxes": [ {
			"id": "rightAxis",
			"axisAlpha": 0,
			"gridAlpha": 0,
			"labelsEnabled": true,
			"title": "Speed (Km/h)",
			"position": "right",
			
			
		}],
		"graphs": [
		 {
			"balloonText": "Speed: [[windspeed]] <br> Direction: [[winddirection]] <br> Chill: [[windchill]]",
		
			//"bulletSizeField": "windspeed",
			"dashLengthField": "dashLength",
		//	"descriptionField": "windspeed",
		//	"labelPosition": "right",
			"legendValueText": "[[windspeed]]",
			"title": "Wind",
			"fillAlphas": 0,
		//	"connect": false,
			"valueField": "windspeed",
			"valueAxis": "rightAxis"
		
		}
		],
		"chartCursor": {
			"categoryBalloonDateFormat": "DD-MM-YYYY JJ:NN",
			"cursorAlpha": 0.1,
			"cursorColor":"#000000",
			 "fullWidth":true,
			"valueBalloonsEnabled": true,
			"zoomable": true,
			"pan": true,
		   // "valueLineEnabled": true
		},
		"dataDateFormat": "DD-MM-YYYY JJ:NN",
		"categoryField": "date",
		"categoryAxis": {
			"parseDates": true,
			"minPeriod" : "mm",
			"dateFormats" : [{
			    period: 'ss',
			    format: 'JJ:NN:SS'
			}, {
			    period: 'mm',
			    format: 'JJ:NN'
			}, {
			    period: 'hh',
			    format: 'JJ:NN'
			}, {
			    period: 'DD',
			    format: 'MMM DD'
			}, {
			    period: 'MM',
			    format: 'MMM YYYY'
			}, {
			    period: 'YYYY',
			    format: 'MMM YYYY'
			}],
			//"equalSpacing":true,
	        "minorGridEnabled": true
		},
		"chartScrollbar": {
	       // "graph": "g1",
	        "oppositeAxis":false,
	        "offset":30,
	        "scrollbarHeight": 30,
	        "backgroundAlpha": 0,
	        "selectedBackgroundAlpha": 0.1,
	        "selectedBackgroundColor": "#888888",
	        "graphFillAlpha": 0,
	        "graphLineAlpha": 0.5,
	        "selectedGraphFillAlpha": 0,
	        "selectedGraphLineAlpha": 1,
	        "autoGridCount":true,
	        "color":"#AAAAAA"
	    },
		"export": {
			"enabled": true
		 }
	});	

	/// SIMS
	$('#sensor-datepicker').daterangepicker({
		"timePicker": true,
		"timePicker24Hour": true,
		"ranges": {
			"Today": [
				//"2015-11-01T14:33:56.832Z",
				///"2015-11-01T14:33:56.832Z"
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()- (time()%(24*60*60)));?>",
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()+24*60*60-(time()%(24*60*60)));?>"
			],
			"Yesterday": [
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()-24*60*60- (time()%(24*60*60)));?>",
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()-(time()%(24*60*60)));?>"
			],
			"Last 7 Days": [
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()-7*24*60*60- (time()%(24*60*60)));?>",
				"<?php echo gmdate("d/m/Y\TH:i:s.832\Z", time()-(time()%(24*60*60)));?>"
			]
		},
// 		"startDate": "10/26/2015",
// 		"endDate": "11/01/2015",
		"startDate":"<?php echo gmdate("d/m/Y", time()- (time()%(24*60*60)));?>",
		"endDate": "<?php echo gmdate("d/m/Y", time()- (time()%(24*60*60)));?>",
		"opens": "left"
	}, function(start, end, label) {
	  ///console.log("New date range selected: " + start.format('YYYY-MM-DD ') + " to " + end.format('YYYY-MM-DD') + " (predefined range: " + label + ")");
		window.location.replace("/do/panel/panel.showequipement?id=<?php echo $equipement->id?>&startDate="+start/1000+"&endDate="+end/1000);
	});


	
	
	<?php } ?>
	$( "a#purge_now" ).click(function(e) {
		e.preventDefault();
		$(this).addClass("disabled");
		$(this).html('<i class="fa fa-circle-o-notch fa-spin fa-fw"></i> Filling...');
		obj= $(this)
		$.get( "{baseurl}do/panel/equipement.purge?id=<?php echo $obj->id?>" );
		(function worker() {$.ajax({
		    url: '{baseurl}do/panel/equipement.purge_check?id=<?php echo $obj->id?>', 
		    success: function(data) {
		      if(data == "0"){
		    	  $(obj).html("Fill Bag");
		    	  $(obj).removeClass("disabled");
		      }else if(data =="1"){
		    	  setTimeout(worker, 1000);
		      }
		    },
		    fail: function() {
		    	setTimeout(worker, 1000);
		    }
		  });
		})();
		  
	})
	</script>
</body>
</html>