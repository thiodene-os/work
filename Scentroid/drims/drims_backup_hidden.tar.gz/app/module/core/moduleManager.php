<?php
require_once(realpath(dirname(__FILE__))."/abstract/entity.php");
require_once(realpath(dirname(__FILE__))."/abstract/module.php");

class moduleManager extends module{
	public static function scanModules($Request){
		//directory scanning
		$path = realpath(dirname(__FILE__)."/..");
		$results = scandir($path);
		
		$modules = array();
		foreach ($results as $result) {
			if ($result === '.' or $result === '..') continue;
		
			if (is_dir($path . '/' . $result)) {
				//code to use if directory
				$modules[]= $path . '/' . $result;
			}
		}
		
		$infos = array();
		for($k=0; $k<count($modules); $k++){
			if(!file_exists($modules[$k]."/info")) 	continue;
			
			$info = file_get_contents($modules[$k]."/info");
			
			if($info == null) continue;
			
			$info = explode("\n", $info);
			
			for($i=0; $i<count($info);$i++){
				$info[$i]= explode (":",$info[$i],2);
				
				for($j=0; $j<count($info[$i]); $j++){
					$info[$i][$j]=trim ($info[$i][$j]);
				}
				if($info[$i]['0'] == "menu")
					$infos[$k][$info[$i]['0']][] = $info[$i]['1'];
				else
					$infos[$k][$info[$i]['0']] = $info[$i]['1'];
				
			}
			
		}
		return $infos;
	}
	
}