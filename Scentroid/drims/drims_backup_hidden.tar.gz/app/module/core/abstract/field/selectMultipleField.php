<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
class selectMultipleField extends field{
	
	public $options;
	public $multiple;
	
	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
		$this->options= $values;
			
	}
	public function render(){
		if($this->required)
			$required= ' required="required" ' ;
		
		if($this->disabled){
			$disabled= ' disabled="disabled" ' ;
		}
		
		$str .= "\n";
		$str .= '<div class="form-group filed_'.$this->id.'_control">';
		//label
		$str .= '<div class="row"><label for="field_'.$this->id.'" class="col-xs-2 control-label">'.l($this->label).'</label>';
		//the field
		$str .= '<div class="col-xs-4">';
		$str .= ' <select multiple name="'.$this->name.'[]" class="'.$this->cssClass.'" id="filed_'.$this->id.'" '.$disabled.' > ';
		if(count($this->options) >0)
		foreach($this->options as $key => $value){
			if( $this->value==$key || (is_array($this->value) &&  in_array($key, $this->value)) ){
				$str.='<option value="'.$key.'" selected="selected">'.l($value).'</option>';
			}else{
				$str.='<option value="'.$key.'" >'.l($value).'</option>';
			}
		}
		else{
			$str.='<option disabled >خالی</option>';
		}
		$str .= "</select>";
		$str .= "</div></div>";
		$str .= "<div class='row'><div class='col-xs-4 col-xs-offset-2 '>";
		//end of field
		if($this->helperText != "")
			$str .= "<small>".$this->helperText."</small>";
			$str .="<small>		<br> برای انتخاب چند مورد، دکمه Ctrl را نگه دارید.</small>";
			$str .= '<br> <span class="counter"></span> مورد انتخاب شده : <span class="names"></span>';
		$str .= '</div></div>';
		$str .= "</div>\n";
		return $str;
		
	}
}