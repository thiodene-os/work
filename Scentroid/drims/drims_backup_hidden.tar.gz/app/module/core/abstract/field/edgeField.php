<?php
require_once(realpath(dirname(__FILE__))."/../field.php");
class edgeField extends field{
	
	public $options;
	public $multiple;
	
	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		parent::set($id,$label,$name,$values,$cssClass,$extras,$value);
			
		$this->options= $values;	
	}
	public function render(){
		if($this->extra->required)
			$required= ' required="required" ' ;
		$str .= "\n";
		$str .= '<div class="form-group">';
		//label
		$str .= '<label for="field_'.$this->id.'" id="" class="col-xs-2 control-label">'.l($this->label).'</label>';
		//the field
		$str .= '<div class="col-xs-4">';
		$str .= ' <select name="'.$this->name.'" class="'.$this->cssClass.'" id="filed_'.$this->id.'" > ';
		foreach($this->options as $key => $value){
			if($this->value == $key){
				$str.='\t<option value="'.$key.'" selected="selected">'.$value.'</option>';
			}else{
				$str.='\t<option value="'.$key.'" >'.$value.'</option>';
			}
		}
		$str .= "</select>";
		$str .= "</div>";
		$str .= "<div class='row'><div class='col-xs-12'>";
		//end of field
		if($this->helperText != "")
			$str .= "<small>".$this->helperText."</small>";
		$str .= '</div></div>';
		$str .= "\n";
		return $str;
		
	}
}