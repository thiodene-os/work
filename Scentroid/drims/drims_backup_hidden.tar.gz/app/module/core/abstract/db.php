<?php

class db  {
	public  $con=NULL;
	private static $instance=null;
	private static $prefix = "";
	
	private function  db(){
        $this->con = mysqli_connect("167.114.10.49","root","GAhftYwxCvw93L5e", "drims") or die(mysqli_error($this->con));
		//$this->con = mysqli_connect("localhost","artaveh_user","salam6060");
		if (!$this->con)
		{
			die('Could not connect: ' . mysqli_error());
		}
		mysqli_query ($this->con,'SET NAMES utf8') or die(mysqli_error($this->con));
	}

	public static function get(){
		if (!self::$instance){
			self::$instance = new db();
		}

		return self::$instance;

	}
	public  function close(){
		mysqli_close($this->con);
	}
	public  function exQuery($Query){
		if(self::$instance ==null){
			self::get();
		}
		/*
			//->adding prefix and remove the {}
		if(strstr ($Query,"{") == False || strstr ($Query,"}") == False  )
			die("yadet raft { ya } bezari :D ");

		$Query = explode("{", $Query);
		$Query[1] = explode("}", $Query[1]);
		$Query[1][0] = self::$prefix.($Query[1][0]) ;
		$Query[1] = implode("",$Query[1]);
		$Query = implode("",$Query);
		*/
		
		$result=@mysqli_query($this->con,$Query);
		if(!$result && mysqli_error($this->con)){
			echo "MYSQLi ERROR:". mysqli_error($this->con)." <br> <i>".$Query."</i><br>";
			echo print_r(debug_backtrace());
		}
		if($result ==null){
			return null;
		}
		$w=array();
		if($result=="") return null;
		while($row =@mysqli_fetch_object($result)){
			$w[]=$row;
		}
		return $w;


	}
	public function lastId(){
		return mysqli_insert_id($this->con);
	}



}

