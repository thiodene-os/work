<?php
class menu{
	public static function scan(){
		$path = realpath(dirname(__FILE__)).'/../../' ;
		$results = scandir($path);
		$str= "";
		foreach ($results as $result) {
			if ($result === '.' or $result === '..') continue;
		
			if (is_dir($path . '/' . $result)) {
				//code to use if directory
				if(file_exists($path. '/'. $result.'/menu'))
					$str .= file_get_contents($path. '/'. $result.'/menu')."\n";
			}
		}
		file_put_contents( realpath(dirname(__FILE__)).'/../local/menu', $str);
		
	}
	public static function generateMenu(){
		
	}
}
menu::scan();