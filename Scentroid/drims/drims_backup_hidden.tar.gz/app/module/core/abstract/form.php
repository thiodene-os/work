<?php
require_once(realpath(dirname(__FILE__))."/entity.php");
require_once(realpath(dirname(__FILE__))."/field.php");

class form extends entity{
	public $HTMLString;
	public $action;
	public $method="POST";
	public $multiplepart= false;
	
	
	public function render(){
		$out= "";
		if($this->multiplepart)
			$out.= '<form class="form-horizontal" role="form" method="'.$this->method.'" action="{baseurl}'.$this->action.'" enctype="multipart/form-data" >';
		else 
			$out.= '<form class="form-horizontal" role="form" method="'.$this->method.'" action="{baseurl}'.$this->action.'" >'; 
		$out.= $this->HTMLString;
		$out.= "<input type='submit' value='ارسال'  class='btn btn-success'>";
		$out.= "</form>";
		return $out;
	}
	
	
	
	public function append($type, $label, $name, $values,$cssClass,$extras,$value=""){

		if($type == "file" || $type == "image" ){
			$this->multiplepart= true;
		}
		require_once realpath(dirname(__FILE__))."/field/".$type."Field.php";
		$classname= $type."Field";
		
		if($value != "" && is_array($value) && count($value) == 1){
			$value = $value[0];
		}
		if($extras->multiple == -1){
			if(is_array($value))
				$extras->multiple= count($value)+3;
			else 
				$extras->multiple = 3;
		}
		//var_dump($extras);
		if(class_exists($classname)){
			$myobject = new $classname();
			if($extras->multiple && $extras->multiple >1){
				for($i=0; $i<$extras->multiple; $i++){
					$value = arrayit($value);
					call_user_func_array(array($myobject, "set"), array(  $name, $label." [".($i+1)."]", $name."[]", $values, $cssClass,$extras,$value[$i]));
					$temp .=call_user_func_array(array($myobject, "render"), array( ));
				}
			}else{
				call_user_func_array(array($myobject, "set"), array(  $name, $label, $name, $values, $cssClass,$extras,$value));
				$temp .=call_user_func_array(array($myobject, "render"), array( ));
			}
		}else{		
			echo "Class NOT found:".$type."Field";
		}
		$this->HTMLString .=$temp;
	}
	
}