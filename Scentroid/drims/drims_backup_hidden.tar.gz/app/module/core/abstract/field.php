<?php
class field{
	
	public $id;
	public $cssClass;
	public $name;
	public $values;
	public $required;
	public $placeholder;
	public $helperText;
	public $value;
	
	
	public function set($id,$label,$name,$values,$cssClass,$extras,$value=""){
		$this->id= $id;
		$this->label= $label;
		$this->cssClass= $cssClass;
		$this->name= $name;
		$this->values= $values;
		$this->required= $extras->required;
		$this->disabled= $extras->disabled;
		$this->multiple= $extras->multiple;
		$this->placeholder= $extras->placeholder;
		$this->helperText= $extras->helperText;
		$this->prepend= $extras->prepend;
		$this->append= $extras->append;
		$this->custom_view= $extras->custom_view;
		$this->extras= $extras;
		$this->value = $value;
		
	}	
}