<?php
	require_once realpath(dirname(__FILE__)).'/../../lang/en.php';
	require_once realpath(dirname(__FILE__)).'/../../lang/fa.php';
function l($str){
	global $lang;
	if(!isset($lang[$str])){
		return  $str;
	}else{
		return $lang[$str];
	}

}
/*
function ewchar_to_utf8($matches) {
	$ewchar = $matches[1];
	$binwchar = hexdec($ewchar);
	$wchar = chr(($binwchar >> 8) & 0xFF) . chr(($binwchar) & 0xFF);
	return iconv("unicodebig", "utf-8", $wchar);
}

function unicode_to_utf8($str) {
	return preg_replace_callback("/\\\u([[:xdigit:]]{4})/i", "ewchar_to_utf8", $str);
}*/

?>