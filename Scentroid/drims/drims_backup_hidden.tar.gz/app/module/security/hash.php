<?php

/* Hash function. not used. but maybe used later*/
class hash {
	public static function num2hash($num){
		$h = md5($num);
		return $num[0].substr($h,0,5).substr($num, 1,strlen($num)-1);
	}
	public static function hash2num($hash){
		return $hash[0].substr($hash, 6,strlen($hash)-1);
	}
	public static function validateHash($num,$hash){
		
	}
}

?>