<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
/*
 * This controller managers companies.
 */
class companyManager extends module{
	/* Shows a page to add a company *
	 * 
	 */
	public static function add($Request){
		userManager::checkRole(array("admin"));
		
		$parser = Parser::get();
		if($Request['edit']){
			$obj= company::load($Request['edit']);
			$parser->setVar("obj", $obj);
		}
		
		$users= user::bulkLoad(0,10000);
		$parser->setVar("users", $users);
		
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_1", "1");
		
		$parser->insert("contentblock", "add-company");
		$parser->parse("single");
	}
	/* save a company on add page form submission */
	public static function save($Request){
		userManager::checkRole(array("admin"));
		
		$obj = new company();
		$obj->id = $Request['id'];
		$obj->createdat= time();
		$obj->creator= userManager::getUser()->id;
		$obj->manager= '-1'; //$Request['manager'];
		$obj->city= $Request['city'];
		$obj->timezone= $Request['timezone'];
		$obj->alarm_email= $Request['alarm_email'];
		$obj->name= $Request['name'];
		$obj->tel= $Request['tel'];
		$obj->address= $Request['address'];
		$obj->logo= $Request['logo'];
        if($Request['extra']){
            $a = $Request['extra'];
            foreach($a as $k=>$v){
                $obj->extra->$k= $v;
            }
            $obj->extra->updatedat= time();
        }

		$obj->save();	
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/security/company.page");
	}
	/* shows a form to edit a company */
	public static function edit($Request){
		userManager::checkRole(array("admin"));
		
		$Request['edit']= $Request['id'];
		self::add($Request);
	}
	public static function delete($Request){
		userManager::checkRole(array("admin"));
		
		company::delete($Request['id']);
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/security/company.page");
	}
	/* shows company list page */
	public static function page($Request){
		userManager::checkRole(array("admin"));
		
		
		$parser = Parser::get();
		
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_1", "1");
		
		$parser->insert("contentblock", "list-company");
		$parser->parse("single");
	}
	/* ajax list of companies */
	public static function ajaxlist($Request){
		userManager::checkRole(array("admin"));
		
		$cols = array("name","tel","address","createdat","id");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}
		if(!$Request['length'])
			$Request['length']= 10;
		
		$company= userManager::getUser()->getCompany();
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `name` LIKE '%".$Request['search']['value']."%' "
						." OR `address` LIKE '%".$Request['search']['value']."%' "
						." OR `city` LIKE '%".$Request['search']['value']."%' "
						." OR `tel` LIKE '%".$Request['search']['value']."%' ";
		}
		$objs= company::load(null,$conds );
		$objs= arrayit($objs);
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		$out->recordsTotal = company::count(array("order"=> "ORDER by id"));
		$out->recordsFiltered =$out->recordsTotal;
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				$arr[]= $objs[$i]->$col;
			}
			
			$out->data[] = $arr;
		}
		echo json_encode($out);
	}
}
