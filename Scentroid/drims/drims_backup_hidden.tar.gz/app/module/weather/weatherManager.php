<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/../panel/equipement.php';

require_once realpath(dirname(__FILE__)).'/wind.php';

require_once realpath(dirname(__FILE__)).'/lib/Yahoo.inc';
 define("API_KEY","dj0yJmk9VExON0VJWWIwcFd1JmQ9WVdrOWNYRkxNM28yTjJzbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1jNA--");
define("SHARED_SECRET","0af795dbdc79e11a2e188259693e0a55f1fbdba9");
 
YahooLogger::setDebug(true);

/*
 *Handles weather information
 */
class weatherManager extends module{
	public static $conditions = array(
			0 => "tornado",
			1 => "thunderstorm", //tropical storm
			2 => "hurricane",
			3 => "thunderstorm",//	severe thunderstorms
			4 => "thunderstorm",//"	thunderstorms
			5 => "rain-mix",//	mixed rain and snow
			6 => "sleet",//	mixed rain and sleet
			7 => "sleet",//	mixed snow and sleet
			8 => "snowflake-cold",// "	freezing drizzle
			9 =>  "snowflake-cold",//"	drizzle
			10=> "rain",// 	freezing rain
			11 => "showers",//	showers
			12 =>"showers",// ,	showers
			13=> "snow", //	snow flurries
			14=> "snow",// 	light snow showers
			15=> "snow-wind", //	blowing snow
			16 => "snow",
			17 => "hail",
			18 => "sleet",
			19=> "dust",
			20=> "fog",
			21 => "day-haze",
			22=> "smoke",
			23=> "windy",
			24=> "windy",
			25=> "thermometer-exterior",// 	cold
			26 => "cloudy",
			27 => "cloudy",///	mostly cloudy (night)
			28=>"day-cloudy",
			29=> "cloudy",//	partly cloudy (night)
			30=> "day-cloudy",//" 	partly cloudy (day)
			31=> "night-clear",// 	clear (night)
			32 => "day-sunny",// "	sunny
			33 => "night-clear",//"	fair (night)
			34=> "day-sunny",//" 	fair (day)
			35 => "rain-mix",//	mixed rain and hail
			36=> "thermometer",//"	hot
			37 => "thunderstorm",//	isolated thunderstorms
			38 => "thunderstorm",//	scattered thunderstorms
			39 => "thunderstorm",//	scattered thunderstorms
			40=> "thunderstorm",// 	scattered showers
			41=> "snow", 	//heavy snow
			42=> "rain-mix",// 	scattered snow showers
			43=> "snow",// 	heavy snow
			44=> "cloudy",//"	partly cloudy
			45 => "storm-showers",//	thundershowers
			46 => "rain-mix",//"	snow showers
			47 => "storm-showers",//	isolated thundershowers
			3200 => "na",//"	not available
	);
	/*
	 * Saves weather for a specific city
	 */
	public static function get_old($cityName){
		$BASE_URL = "https://query.yahooapis.com/v1/public/yql";
		$yql_query = 'SELECT * FROM weather.bylocation WHERE location="'.$cityName.'" AND unit="c" ';
		$yql_query_url = $BASE_URL . "?q=" . urlencode($yql_query) . "&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
	// Make call with cURL
		$session = curl_init($yql_query_url);
		curl_setopt($session, CURLOPT_RETURNTRANSFER,true);
		$json = curl_exec($session);
		// Convert JSON to PHP object
		$phpObj =  json_decode($json);
		//var_dump($phpObj);
		$phpObj= $phpObj->query->results->weather->rss->channel;
		return $phpObj;
		
	}

    public static function get_weather($Request){
        $parser = Parser::get();
        $weather= null;
        if($Request['id']){
            $equipement = equipement::load($Request['id']);
            if(!userManager::hasRole("admin") and $equipement->company != userManager::getUser()->company){
                die("access denied");
            }
            $company = company::load($equipement->company);
            $weather = self::get($company->city);
        }else{
            if(userManager::hasRole("admin")){
                $equipements = equipement::load(null, array("order"=>"ORDER BY id DESC"));
            }else{
                $company = company::load(userManager::getUser()->company);
                $equipmentCategories = userManager::getUser()->extra->equipment_category;
                if ($equipmentCategories && $equipmentCategories != "" && $equipmentCategories[0] != "") {
                    for($i=0; $i<count($equipmentCategories); $i++){
                        $equipmentCategories[$i] = "'".$equipmentCategories[$i]."'";
                    }
                    $equipmentCategories = implode(",",$equipmentCategories);
                    $equipements = equipement::load(null, array(" `company`='".$company->id."' ",
                        "category IN ($equipmentCategories)",
                        "order"=>"ORDER BY id DESC"));

                } else {
                    $equipements = equipement::load(null, array(" `company`='".$company->id."' ","order"=>"ORDER BY id DESC"));
                }
            }

            if(!$equipements) {
                die("there is no equipment assigned to your company or your account equipment group. Please contact support");
            }
            $equipements = arrayit($equipements);
            $weather = self::get(company::load($equipements[0]->company)->city);
        }

        if (!$weather){
            die("Weather data not available at the moment.");
        }
        $value = $weather->astronomy->sunrise;
        $value = str_replace(" am","",$value);
        $value = explode(":", $value);
        if (strlen($value[1]) == 1){
            $value[1] = "0".$value[1];
        }
        $weather->astronomy->sunrise = implode(":", $value)." am";

        $value = $weather->astronomy->sunset;
        $value = str_replace(" pm","",$value);
        $value = explode(":", $value);
        if (strlen($value[1]) == 1){
            $value[1] = "0".$value[1];
        }
        $weather->astronomy->sunset = implode(":", $value)." pm";
        $weather->atmosphere->pressurekpa = number_format($weather->atmosphere->pressure/10/33.7685,3);
        $parser->setVar("weather", $weather);
        $parser->parse("weather");
    }


	public static function get($cityName){
		$app = new YahooApplication (API_KEY, SHARED_SECRET);
		$query =  'select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="'.$cityName.'") and u="c"';
		$results = $app->query($query);
		return $results->query->results->channel; 
	}
	public static function getWindByCity($cityName){
		$app = new YahooApplication (API_KEY, SHARED_SECRET);
		$query =  'select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="'.$cityName.'") and u="c"';
		$results = $app->query($query);
		return $results->query->results->channel->wind;
	}
	/*
	 * Saves wind data for a city
	 */
	public static function getWindByCity_old($cityName){
	 //	$cityName = "asdasdasdas";
	$BASE_URL = "https://query.yahooapis.com/v1/public/yql";
	$yql_query = 'SELECT * FROM weather.bylocation WHERE location="'.$cityName.'" AND unit="c" ';
	$yql_query_url = $BASE_URL . "?q=" . urlencode($yql_query) . "&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
	// Make call with cURL
	//$yql_query_url = "https://query.yahooapis.com/v1/public/yql?q=SELECT%20*%20FROM%20weather.bylocation%20WHERE%20location%3D'Toronto%2C%20On'%20AND%20unit%3D%22c%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";;
	$session = curl_init($yql_query_url);
	curl_setopt($session, CURLOPT_RETURNTRANSFER,true);
	$json = curl_exec($session);
	// Convert JSON to PHP object
	$phpObj =  json_decode($json);
	$phpObj = $phpObj->query->results->weather->rss->channel->wind;
	return $phpObj;
	} 
	/* public static function getWindByCity_old($cityName){
	//	$cityName = "asdasdasdas";
		$BASE_URL = "https://query.yahooapis.com/v1/public/yql";
		$yql_query = 'SELECT * FROM weather.bylocation WHERE location="'.$cityName.'" AND unit="c" ';
		$yql_query_url = $BASE_URL . "?q=" . urlencode($yql_query) . "&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
		// Make call with cURL
		//$yql_query_url = "https://query.yahooapis.com/v1/public/yql?q=SELECT%20*%20FROM%20weather.bylocation%20WHERE%20location%3D'Toronto%2C%20On'%20AND%20unit%3D%22c%22&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";;
		$session = curl_init($yql_query_url);
		curl_setopt($session, CURLOPT_RETURNTRANSFER,true);
		$json = curl_exec($session);
		// Convert JSON to PHP object
		$phpObj =  json_decode($json);
		$phpObj = $phpObj->query->results->weather->rss->channel->wind;
		//var_dump($phpObj->query->results->weather->rss->channel->wind);
		return $phpObj;
	} */
	/*
	 * Shows the icon for each code name of weather in the panel
	 */
	public static function getIcon($code){
		return self::$conditions[$code];
	}
	/*
	 * Saves wind.
	 */
	public static function saveWind($Request){
		$companies= company::load(null, array("`city` IS NOT NULL AND `city` <> '' " , "order"=> "ORDER BY id DESC"));
		$companies = arrayit($companies);
		for($i=0; $i<count($companies); $i++){
			$w = self::getWindByCity($companies[$i]->city);
			if($w){
				$wind = new wind();
				$wind->chill= $w->chill; 
				$wind->direction= $w->direction;
				$wind->location= $companies[$i]->city;
				$wind->speed= $w->speed;
				$wind->createdat= time();
				$wind->save();
			}
		}
		
	}
	
}
