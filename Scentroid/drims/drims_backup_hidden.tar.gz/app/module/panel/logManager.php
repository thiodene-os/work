<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/log.php';
require_once realpath(dirname(__FILE__)).'/equipement.php';
require_once realpath(dirname(__FILE__)).'/../security/company.php';

/*
 * Log management controller
 */
class logManager extends module{
	/* pushes a log entry into database */
	public static function push($company,$equipement,$message,$type="INFO"){
		$log = new log();
		$log->company= $company;
		$log->createdat= time();
		$log->equipement= $equipement;
		$log->message= $message;
		$log->type= $type;
		$log->save();
	}
	/* cleans the log for a company/equipement */
	public static function clean($Request){
		userManager::checkRole(array("admin","manager","user"));
		$conds = array(" `id` > 0");
		if(userManager::hasRole(array("admin")) && $Request['company']){
			$conds[] = "`company` = '".$Request['company']."' ";		
		}else{
			$conds[] =  "`company` = '".userManager::getUser()->getCompany()->name."' ";
		}
		if($Request['equipement']){
			if(!userManager::hasRole(array("admin"))){
				$eq= equipement::load(null,array( " `name`='".$Request['equipement']."' "));
				if($eq->company == userManager::getUser()->getCompany()->id){
					$conds[] = "`equipement` = '".$Request['equipement']."' ";
				}else{
					die("no access");
				}
			}else{
				$conds[] = "`equipement` = '".$Request['equipement']."' ";
			}
		}
		var_dump($conds);die();				
		log::delete(null,$conds);
	
		
	}
	/* delete a specific log entry */
	public static function delete($Request){
		userManager::checkRole(array("admin","manager","user"));
		
		log::delete($Request['id']);
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/panel/log.page");
	}
	/*shows log page */
	public static function page($Request){
		userManager::checkRole(array("admin","manager","user"));
		
		$parser = Parser::get();
		
	
	if(userManager::hasRole("admin")){
			$parser->setVar("menu_1", "1");
			$parser->setVar("menu_1_4", "1");
			$parser->setVar("company", arrayit(company::load(null,array("order" =>" ORDER BY id DESC"))));
			$parser->setVar("equipement", arrayit(equipement::load(null,array("order" =>" ORDER BY id DESC"))));
		}else{
 			$parser->setVar("menu_2", "1");
 			$parser->setVar("menu_2_2", "1");
 			$parser->setVar("company", null);
 			$parser->setVar("equipement", arrayit(equipement::load(null,array(" `company`= '".userManager::getUser()->company."' "))));
		}
		$parser->insert("contentblock", "list-log");
		$parser->parse("single");
	}
	/* ajax list of logs */
	public static function ajaxlist($Request){
		userManager::checkRole(array("admin","manager","user"));
		
		$cols = array("id","company","equipement","type","message","createdat");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}else{
			$order = " ORDER BY id DESC";
				
		}
		if(!$Request['length'])
			$Request['length']= 10;
		$company= userManager::getUser()->getCompany();
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `message` LIKE '%".$Request['search']['value']."%'  ";
		}
		if(!userManager::hasRole("admin")){
			$conds[] = " `company` = '".userManager::getUser()->getCompany()->name."' ";
		}else{
			if($Request['company']){
				$conds[] = " `company` = '".$Request['company']."' ";
			}
		}
		if($Request['equipement']){
			$conds[] = " `equipement` = '".$Request['equipement']."' ";
		}
		if($Request['type']){
			$conds[] = " `type` = '".$Request['type']."' ";
		}

		$objs= log::load(null,$conds );
		unset($conds['limit']);
		$objs= arrayit($objs);
		
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		$number = log::count($conds);
		$out->recordsTotal =$number;
		$out->recordsFiltered =$number;
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				
					$arr[]= $objs[$i]->$col;
			}
		
			$out->data[] = $arr;
		}
		echo json_encode($out);
		
		
		
	}
	/* deletes log data of a company/equipement */
	public static function deletedata($Request){
		userManager::checkRole(array("user","manager"));
		
		if(userManager::hasRole("admin")){
			if($Request['company'])
				$conds[] = " `company`='".$Request['company']."' ";
		}else{
			$company= userManager::getUser()->getCompany()->name;
			$conds[] = " `company`='".$company."' ";
		}
		$company = userManager::getUser()->getCompany();
		if($Request['equipement'])
			$eq= equipement::load(null,array( " `name`='".$Request['equipement']."' "));
			if($eq->company == userManager::getUser()->getCompany()->id){
				$conds[] = "`equipement` = '".$Request['equipement']."' ";
			}else{
				die("no access");
			}
			$conds[] = " `equipement`='".$Request['equipement']."' ";
		if($Request['type'])
			$conds[] = " `type`='".$Request['type']."' ";
		
		if($Request['startDate']!="")
			$conds[]=" `createdat` >= ". (strtotime($Request['startDate'])-($company->timezone)*3600) ;
		if($Request['endDate']!="")
			$conds[]= " `createdat` <= ". (strtotime($Request['endDate'])-($company->timezone)*3600);
		if($conds ==null){
			$conds["order"]= "ORDER BY id ASC";
		}
		//var_dump($conds);
		log::delete(null,$conds);
	}

	public static function countLogs($company, $equipment, $type, $since){
	    $conditions = array("`company`='$company'", "`equipement`= '$equipment'",
            "`type`='$type'", "`createdat` >= $since");
	    return log::count($conditions);
    }
	
}
