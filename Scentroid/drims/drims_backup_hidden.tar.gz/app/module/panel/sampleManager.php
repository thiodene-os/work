<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/equipement.php';
require_once realpath(dirname(__FILE__)).'/sample.php';
require_once realpath(dirname(__FILE__)).'/sensor.php';

/* handles equipements  */
class sampleManager extends module{

	/* add an sample */
	public static function add($Request){
		userManager::checkRole(array("admin","manager","lab"));
		$parser = Parser::get();
		if($Request['edit']){
			$obj= sample::load($Request['edit']);
			$parser->setVar("obj", $obj);
		}
		if($Request['sensor'] && is_numeric($Request['sensor']))
			$parser->setVar("sensor",$Request['sensor']);
		
		$equipement= equipement::load($Request['eq']);
		$company= company::load($equipement->company);
		
		$parser->setVar("equipement",$equipement);
		
		$sensors = sensor::load(null, array( "`equipement` = '".$equipement->id."'"  ));
		$sensors = arrayit($sensors);
		for($i=0; $i<count($sensors); $i++){
			$sensors[$i]= $sensors[$i]->id;
		}
		$pidSamples = sample::load(null,array_merge(array(
				" `sensor` in ('".implode(",",$sensors)."') ",
				" `type` <> 'm' ",
				"order"=> "ORDER BY sampledat ASC",
		)));
		$pidSamples =arrayit($pidSamples);
		
		$pidSamplesDates = array();
		for($i=0; $i<count($pidSamples);$i++){
			$d =  gmdate("d-M-Y",$pidSamples[$i]->sampledat+(($company->timezone)*3600));
			if(!in_array($d, $pidSamplesDates)){
				$pidSamplesDates[$pidSamples[$i]->sampledat - $pidSamples[$i]->sampledat%(24*3600) ] = $d;
			}
		}
		$parser->setVar("pidSamplesDates",$pidSamplesDates);
		
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_2", "1");
		$parser->insert("contentblock", "add-sample");
		$parser->parse("single");
	}
	/* save added equipement */
	public static function save($Request){
		userManager::checkRole(array("admin","manager","lab"));
				
		$sample = new sample();
		$sample->createdat= time();
		$sample->equipement = $Request['equipement'];
		$sample->sampledat = $Request['date'];
		$sample->value = $Request['value'];
		$sample->type= "m";
		$sample->save();
		$parser= Parser::get();
		
		$parser->redirect("{baseurl}/do/panel/sample.pagemanual?id=".$Request['equipement']);
		
	}
	/*edit an equipement */
	public static function edit($Request){
		userManager::checkRole(array("admin","manager"));
		
		$Request['edit']= $Request['id'];
		self::add($Request);
	}
	/* delete and equipement. sensors and their data won't be deleted, because of their important data. maybe you want to change it later.*/ 
	public static function delete($Request){
		$s = sample::load($Request['id']);
		sample::delete($s->id);
		$parser= Parser::get();
		$parser->redirect("{baseurl}do/panel/sample.pagemanual?id=".$s->sensor);
	}
	/* list of sample page */
	public static function pagemanual($Request){
		userManager::checkRole(array("admin","manager"));
		
		$parser = Parser::get();
	
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_3", "1");
		$parser->setVar("obj", sensor::load($Request['id']));
		$parser->setVar("equipement",  equipement::load($Request['id']));
		
		$parser->insert("contentblock", "list-sample");
		$parser->parse("single");
	}
	/* ajaxlist of sample */
	public static function ajaxlistmanual($Request){
		userManager::checkRole(array("admin","manager"));
		
		$cols = array("id","equipement","value","sampledat","id");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}
		if(!$Request['length'])
			$Request['length']= 10;
		
		$company= userManager::getUser()->getCompany();
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `value` LIKE '%".$Request['search']['value']."%' ";
		}
		
		$conds[] = " `type` = 'm' ";
		$conds[] = " `equipement` = '".$Request['id']."' ";
		
		$objs= sample::load(null,$conds );
		$objs= arrayit($objs);
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		$out->recordsTotal = sample::count($conds);
		$out->recordsFiltered =count($objs);
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				if($col == "equipement"){
					$arr[]= equipement::load($objs[$i]->$col)->name;
				}elseif($col == "sensor"){
					$arr[]= sensor::load($objs[$i]->$col)->name;
				}else
					$arr[]= $objs[$i]->$col;
			}
		
			$out->data[] = $arr;
		}
		echo json_encode($out);
		
	}
	public static function exportmanualsample($Request){
		header('Content-type: text/csv');
		header('Content-Disposition: attachment; filename="export.csv"');
		userManager::checkRole(array("admin","manager","user"));
		
		$user= userManager::getUser();
		$equipement = equipement::load($Request['id']);
		$company= company::load($equipement->company);
		
		//header('Content-Type: application/json');
		$conds = array(
				"`location` = '".$company->city."' ",
				"order"=> "ORDER BY createdat ASC",
		);
		if($Request['startDate']!=""){
			$conds[]=" `createdat` >= ". ($Request['startDate']-($company->timezone*3600)) ;
			$mindate = ($Request['startDate']-($company->timezone*3600));
		}else
			$mindate= 0;
		
		if($Request['endDate']!=""){
			$conds[]= " `createdat` <= ". ($Request['endDate']-($company->timezone*3600));
			$maxdate=($Request['endDate']-($company->timezone*3600));
		}else
			$maxdate= time();
		
		if($Request['endDate']=="" && $Request['startDate']==""  ){
			$conds["limit"] = " LIMIT 1000";
			$conds['order'] = "ORDER BY id DESC";
		}
		
		$samplesPerSensor = array();
		
		$samples= sample::load(null,array(
				"sampledat >= $mindate" , "sampledat<= $maxdate",
				"`equipement` = '".$equipement->id."'",
				"order"=> "ORDER BY sampledat ASC",
		));
		
		$samples =arrayit($samples);
		
		$times=array();
		for($i=0; $i<count($samples);$i++){
			$t = $samples[$i]->sampledat - $samples[$i]->sampledat%60;//+($company->timezone*3600);
			if(!in_array($t, $times))
				$times[]= $t;
			$sensor= $samples[$i]->sensor > 0 ? sensor::load($samples[$i]->sensor)->name: "Manual";
			$samplesPerSensor[$sensor][$t]= $samples[$i]->value;
		}
		sort(array_unique($times),SORT_NUMERIC);
		
		$out = array();
		echo "Date,";
		foreach ($samplesPerSensor as $sensorname => $values){
			echo $sensorname.",";
		}
		echo "\n";
		foreach ($times as $t){
			$o = "";
			$o .= gmdate("d-m-Y H:i", $t);
			$o .=",";
			foreach ($samplesPerSensor as $sensorname => $values){
					$o .= $values[$t].",";
			}
			$out[]= $o;
		}
		
		echo (implode("\n",$out));
	}
	
	public static function exportcalibrationvalues($Request){
		header('Content-type: text/csv');
		header('Content-Disposition: attachment; filename="export-calivalues.csv"');
		userManager::checkRole(array("admin","manager","user"));

		$user= userManager::getUser();
		$equipement = equipement::load($Request['id']);
		$company= company::load($equipement->company);
	
		$conds = array(
				"`location` = '".$company->city."' ",
				"order"=> "ORDER BY createdat ASC",
		);
		if($Request['startDate']!=""){
			$conds[]=" `createdat` >= ". ($Request['startDate']-($company->timezone*3600)) ;
			$mindate = ($Request['startDate']-($company->timezone*3600));
		}else
			$mindate= 0;
	
		if($Request['endDate']!=""){
			$conds[]= " `createdat` <= ". ($Request['endDate']-($company->timezone*3600));
			$maxdate=($Request['endDate']-($company->timezone*3600));
		}else
			$maxdate= time();
	
		if($Request['endDate']=="" && $Request['startDate']==""  ){
			$conds["limit"] = " LIMIT 1000";
			$conds['order'] = "ORDER BY id DESC";
		}
	
		$samplesPerSensor = array();
	
		$samples= sample::load(null,array(
				"sampledat >= $mindate" , "sampledat<= $maxdate",
				"`equipement` = '".$equipement->id."'",
				"`sensor`>0",
				"order"=> "ORDER BY sampledat ASC",
		));
	
		$samples =arrayit($samples);

		$times=array();
		for($i=0; $i<count($samples);$i++){
			$t = $samples[$i]->sampledat - $samples[$i]->sampledat%60;//+($company->timezone*3600);
			if(!in_array($t, $times))
				$times[]= $t;
			$sensor=  sensor::load($samples[$i]->sensor);
			if($sensor->calibrationfactors[0] && $sensor->calibrationfactors[1]){
				$samplesPerSensor[$sensor->name][$t]= $sensor->calibrationfactors[0] *$samples[$i]->value+$sensor->calibrationfactors[1] ;
				
			}else{
				$samplesPerSensor[$sensor->name][$t]= $samples[$i]->value;
				
			}
		}
		sort(array_unique($times),SORT_NUMERIC);
			
		$out = array();
		echo "Date,";
		foreach ($samplesPerSensor as $sensorname => $values){
			echo $sensorname.",";
		}
		echo "\n";
		foreach ($times as $t){
			$o = "";
			$o .= gmdate("d-m-Y H:i", $t);
			$o .=",";
			foreach ($samplesPerSensor as $sensorname => $values){
				$o .= $values[$t].",";
			}
	
				
			$out[]= $o;
		}
	
		echo (implode("\n",$out));
	}
	
}
