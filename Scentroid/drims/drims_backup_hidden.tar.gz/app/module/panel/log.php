<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/* log ORM container */
class log  extends entity{
		public $company;
		public $equipement;
		public $type; 
		public $message;
		public $createdat;
		
}