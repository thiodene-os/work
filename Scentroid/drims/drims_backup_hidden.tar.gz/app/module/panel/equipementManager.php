<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/equipement.php';
require_once realpath(dirname(__FILE__)).'/sensor.php';


/* handles equipements  */
class equipementManager extends module{
	/* settings page */
	public static function settings($Request){
		userManager::checkRole(array("admin","manager"));
        $eq = equipement::load($Request['id']);
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");
        $parser = Parser::get();
		/* 
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_2", "1"); */
		//var_dump(parseSettings("equipement")); die();
        $companyExtra = company::load($eq->company)->extra;
        $equipmentCategories = array();
        if($companyExtra->equipment_category)
            $equipmentCategories = explode("\r\n",$companyExtra->equipment_category);
        $parser->setVar("equipmentCategories", $equipmentCategories );
        $parser->setVar("equipementSettings", parseSettings("equipement"));
		$parser->setVar("obj", $eq);
		//var_dump(equipement::load($Request['id'])); die();
		$parser->insert("contentblock", "equipement-settings");
		$parser->parse("single");
	}
	/* add an equipement */
	public static function add($Request){
		userManager::checkRole(array("admin"));
		
		$parser = Parser::get();
		if($Request['edit']){
			$obj= equipement::load($Request['edit']);
			$parser->setVar("obj", $obj);
		}
		
		$parser->setVar("companies", arrayit(company::load(null,array("order"=>" ORDER BY id DESC"))));
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_2", "1");
		$parser->insert("contentblock", "add-equipement");
		$parser->parse("single");
	}
	/* save added equipement */
	public static function save($Request){
		userManager::checkRole(array("admin","manager"));

        if(!$Request['id'] && !userManager::hasRole(array("admin"))){
            die("only admins can add devices.");
        }
        $eq =  equipement::load(null, array(" `sn` = '".$Request['sn']."'"));
		if(!$Request['id'] && $eq)
				die("A device with this sn exists:".$eq->name);


		if(!$Request['id']){
			$obj = new equipement();
			$obj->createdat= time();
			$obj->secret = md5(rand())."-".time();
			$obj->creator= userManager::getUser()->id;
			
		}else{
			$obj = equipement::load($Request['id']);
            if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $obj->company)
                die("restricted access");
			$obj->id = $Request['id'];
		}

			
		if($Request['status'])
			$obj->status= $Request['status'];
		
		if($Request['name'])
			$obj->name= $Request['name'];

        if(userManager::hasRole(array("admin")) ){
            if($Request['sn'])
                $obj->sn= $Request['sn'];

            if($Request['secret']) {
                $eq =  equipement::load(null, array(" `secret` = '".$Request['secret']."'"));
                if($Request['id'] != $eq->id && $eq)
                    die("A device with this secret exists, please change it and retry:".$eq->name);
                $obj->secret= $Request['secret'];
            }
            if($Request['company'])
                $obj->company = $Request['company'];

            if($Request['calibratedate'])
                $obj->calibratedate = strtotime($Request['calibratedate']);

            if($Request['category'])
                $obj->category = $Request['category'];
        }

		#equipement settings
 		if($Request['extra']){
 			$a = $Request['extra'];
 			foreach($a as $k=>$v){
 					$obj->extra->$k= $v;
 			}
 			$obj->extra->updatedat= time();
 		}
		$obj->save();
		$parser= Parser::get();
		if(userManager::hasRole("admin")){
			$parser->redirect("{baseurl}/do/panel/equipement.page");
		}else{
			$parser->redirect("{baseurl}/do/panel/panel.welcome");
		}
	}
	/*edit an equipement */
	public static function edit($Request){
		userManager::checkRole(array("admin","manager"));
		
		$Request['edit']= $Request['id'];
		self::add($Request);
	}
	/* delete and equipement. sensors and their data won't be deleted, because of their important data. maybe you want to change it later.*/ 
	public static function delete($Request){
        $eq = equipement::load($Request['id']);
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");
		equipement::delete($Request['id']);
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/panel/equipement.page");
	}
	/* list of equipements page */
	public static function page($Request){
		userManager::checkRole(array("admin"));
		
		$parser = Parser::get();
	
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_3", "1");
		$parser->setVar("company", arrayit(company::load(null,array("order"=>"ORDER BY id DESC"))));
		$parser->insert("contentblock", "list-equipement");
		$parser->parse("single");
	}
	/* ajaxlist of equipements */
	public static function ajaxlist($Request){
		userManager::checkRole(array("admin"));
		
		$cols = array("company","name","sn","createdat","calibratedate","id");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}
		if(!$Request['length'])
			$Request['length']= 10;
		
		$company= userManager::getUser()->getCompany();
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `name` LIKE '%".$Request['search']['value']."%' OR `sn` LIKE  '%".$Request['search']['value']."%' ";
		}
		if(!userManager::hasRole("admin")){
			$conds[] = " `company` = '".userManager::getUser()->company."' ";
		}
		if($Request['company']){
			$conds[] = " `company` = '".$Request['company']."' ";
		}
		
		$objs= equipement::load(null,$conds );
		$objs= arrayit($objs);
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		$out->recordsTotal = equipement::count(array("order"=> "ORDER by id"));
		$out->recordsFiltered =$out->recordsTotal;
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				if($col == "company"){
					$arr[]= company::load($objs[$i]->$col)->name;
				}else
					$arr[]= $objs[$i]->$col;
			}
		
			$out->data[] = $arr;
		}
		echo json_encode($out);
		
	}
	/*activate an equipement */
	public static function active($Request){
		userManager::checkRole(array("admin","manager"));
        $eq = equipement::load($Request['id']);
        if(!$eq){
            die("No such equipement");
        }
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");

        $eq->status= "active";
        $eq->save();
		Parser::get()->redirect("{baseurl}do/panel/panel.welcome");
	}
	/* make an equipement deactive from the dropdown menu*/
	public static function deactive($Request){
		userManager::checkRole(array("admin","manager"));
        $eq = equipement::load($Request['id']);
        if(!$eq){
            die("No such equipement");
        }
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");
        $eq->status= "deactive";
        $eq->save();
		Parser::get()->redirect("{baseurl}do/panel/panel.welcome");
	}
	/*set a command in equipement settings */
	public static function command($Request){
		userManager::checkRole(array("admin","manager"));
        $eq = equipement::load($Request['id']);
        if(!$eq){
            die("No such equipement");
        }
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");
		//$obj->extra= json_decode($obj->extra);
		if($eq->extra==null)
            $eq->extra = new stdClass();
        $eq->extra->command = $Request['command'];
        $eq->save();
		Parser::get()->redirect("{baseurl}do/panel/equipement.settings?id=".$Request['id']);
	}
	public static function getUpdatedTime($equipementId){
		$eq = equipement::load($equipementId);
		$max_updated = -1;
		$max_created = -1;
		$max_updated=$eq->extra->updatedat;
		$max_created = $eq->createdat;
	
		$sensors = sensor::load(null, array("`equipement`='".$equipementId."'"));
		$sensors = arrayit($sensors);
		for($i=0; $i<count($sensors);$i++){
			if($sensors[$i]->extra->updatedat > $max_updated && $sensors[$i]->extra->updatedat != 0){
				$max_updated= $sensors[$i]->extra->updatedat;
				$max_created = $sensors[$i]->createdat;
			}
		}
		if($max_updated <=0){
			$max_updated = $max_created;	
		}
		return $max_updated;
	}
	public static function purge($Request){
		$eq = equipement::load($Request['id']);
		if(!$eq){
			die("no such equipement");
		}
		$eq->extra->command=1; //purge
		$eq->extra->updatedat=time();
		
		$eq->save();
	}
	public static function purge_check($Request){
        $eq = equipement::load($Request['id']);
        if(!$eq){
            die("No such equipement");
        }
        if (!userManager::hasRole(array("admin")) && userManager::getUser()->company != $eq->company)
            die("restricted access");
		if($eq->extra->command==1)
			echo "1";
		else 
			echo "0";
	}
}
