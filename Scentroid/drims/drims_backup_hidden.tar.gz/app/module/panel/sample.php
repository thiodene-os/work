<?php
require_once realpath(dirname(__FILE__)).'/../core/abstract/entity.php';
/* Sample ORM handler */
class sample  extends entity{
	public $equipement;
	public $sensor;
	public $type="a";
	public $value;
	public $lat;
	public $lon;
	public $state;
	public $sampledat;
	public $createdat;
	
	public static function getLastBySensorNameAndEquipementId($name,$equipementId){
		$sensor = sensor::getByName($name,$equipementId);
		return sample::load(null, array("`sensor`='".$sensor->id."'","order"=>"ORDER BY id DESC","limit"=>"LIMIT 1"));
			
	}

}