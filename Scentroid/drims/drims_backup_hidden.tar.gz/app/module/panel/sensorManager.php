<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/sensor.php';
require_once realpath(dirname(__FILE__)).'/equipement.php';
require_once realpath(dirname(__FILE__)).'/sample.php';
require_once realpath(dirname(__FILE__)).'/log.php';

require_once realpath(dirname(__FILE__)).'/../weather/wind.php';

/* Sensor management controller */
class sensorManager extends module{
	/* a form to add sensors */
	public static function add($Request){
		userManager::checkRole(array("admin","manager","lab"));
		if(!$Request['edit'] && !$Request['equipement'])
			die("no equipement specified");
		$parser = Parser::get();
		if($Request['edit']){
			$obj= sensor::load($Request['edit']);
			$parser->setVar("obj", $obj);
		}
		
		$parser->setVar("sensorSettings", parseSettings("sensor"));
		$parser->setVar("equipement", equipement::load($Request['equipement']));
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_2", "1");
		$parser->insert("contentblock", "add-sensor");
		$parser->parse("single");
	}
	public static function alarm($Request){
		userManager::checkRole(array("admin","manager"));
		$parser = Parser::get();
		$obj= sensor::load($Request['sensor']);
		$parser->setVar("obj", $obj);
		$equipement= equipement::load($obj->equipement);
		if($equipement->company != userManager::getUser()->company && !userManager::hasRole("admin"))
			die("restricted access");
		$parser->setVar("equipement",$equipement );
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_2", "1");
		$parser->insert("contentblock", "add-alarm");
		$parser->parse("single");
	}
	public static function savealarm($Request){
		userManager::checkRole(array("admin","manager"));
		$parser = Parser::get();
		$obj= sensor::load($Request['id']);
		
		if(!$obj){
			die("wrong sensor");
		}
		$equipement= equipement::load($obj->equipement);
		if($equipement->company != userManager::getUser()->company && !userManager::hasRole("admin"))
			die("restricted access");
		
		if($Request['alarm_value_num'])
			$obj->alarm_value_num = $Request['alarm_value_num'];
		if($Request['alarm_value_total'])
			$obj->alarm_value_total = $Request['alarm_value_total'];
		if($Request['alarm_max_value'])
			$obj->alarm_max_value = $Request['alarm_max_value'];
		$obj->save();
		$parser->redirect("{baseurl}/do/panel/panel.showequipement");
	}
	/* save a sensors on addition/edition */
	public static function save($Request){
		userManager::checkRole(array("admin","manager","lab"));
		
		if(is_numeric($Request['equipement'])){
            $equipement= equipement::load($Request['equipement']);
		    if (!$equipement)
                die("No such equipement");
            if($equipement->company != userManager::getUser()->company && !userManager::hasRole("admin"))
                die("restricted access");
        }
		
		if(!$Request['id']){
			$obj = new sensor();
			$obj->createdat= time();
			$obj->creator= userManager::getUser()->id;
			$obj->equipement= $Request['equipement'];
		}else{
			$obj =  sensor::load($Request['id']);
			$obj->id = $Request['id'];
		}
		
		if($Request['name'])
			$obj->name= $Request['name'];
		
		if(sensor::getTypeFromName($Request["name"])=="unknown"){
			die("sensor name either should contain words like pid, humidity or temperature.");
		}
		
		if($Request['packet_id']){
            if (!preg_match("/^S[0-9]{2}[A-Z]{0,1}$/", $Request['packet_id'])) {
                die("wrong sensor packet id. Accepted samples are S01, S03C");
            }
			$obj->packet_id= $Request['packet_id'];
			$otherSensors= sensor::load(null, array("`equipement`='".$Request['equipement']."'", "`packet_id`='".$Request['packet_id']." '"));
			if($otherSensors && $otherSensors->id != $obj->id){
				die("There are other sensors with this name.");
			}
		}
		if($Request['dataunit'])
			$obj->dataunit = $Request['dataunit'];
		
		if($Request['alarm_value_num'])
			$obj->alarm_value_num = $Request['alarm_value_num'];
		if($Request['alarm_value_total'])
			$obj->alarm_value_total = $Request['alarm_value_total'];
		if($Request['alarm_max_value'])
			$obj->alarm_max_value = $Request['alarm_max_value'];
		
		if($Request['calibrationfactors'])
			$obj->calibrationfactors = $Request['calibrationfactors'];
		
		
		if($Request['extra']){
			$a = $Request['extra'];
			foreach($a as $k=>$v){
				$obj->extra->$k= $v;
			}
			$obj->extra->updatedat= time();
		}
		
		$obj->save();
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/panel/sensor.page?equipement=".$Request['equipement']);
	}
	/* edits a sensor. shows the form for it */
	public static function edit($Request){
		userManager::checkRole(array("admin","manager","lab"));
		
		$Request['edit']= $Request['id'];
		self::add($Request);
	}
	/*deletes a sensor, but not its data (because we are in beta(*/
	public static function delete($Request){
		userManager::checkRole(array("admin","manager","lab"));
		
		$s = sensor::load($Request['id']);
		$e = $s->equipement;
		sensor::delete($Request['id']);
		$parser= Parser::get();
		$parser->redirect("{baseurl}/do/panel/sensor.page?equipement=".$e);
	}
	/*shows the page of sensor list */
	public static function page($Request){
		userManager::checkRole(array("admin","manager"));
		if(!$Request['equipement'])
			die("for which equipement?");
		$equipement = equipement::load($Request['equipement']);
		if(!$equipement)
			die("which equipement?");
		$parser = Parser::get();
		$parser->setVar("equipement", $equipement);
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_3", "1");
		$parser->insert("contentblock", "list-sensor");
		$parser->parse("single");
	}
	/* ajax endpoint to show the list of sensors */
	public static function ajaxlist($Request){
		userManager::checkRole(array("admin","manager","lab"));
				
		$cols = array("name","packet_id","type","dataunit","createdat","id");
		if($Request['order'][0]){
			$order = " ORDER BY ".$cols[$Request['order'][0]['column']]." ".$Request['order'][0]['dir'];
		}
		if(!$Request['length'])
			$Request['length']= 10;
		
		$limit = " LIMIT ".($Request['start']).",".$Request['length'];
		$company = userManager::getUser()->getCompany();
		$conds= array(  "limit"=>$limit, "order"=>$order);
		if($Request['mindate'] && strtotime($Request['mindate'])){
			$conds[] = " createdat > ".(strtotime($Request['mindate'])-(($company->timezone)*3600)) ;
		}
		if($Request['maxdate'] && strtotime($Request['maxdate'])){
			$conds[] = " createdat < ".(strtotime($Request['maxdate'])-(($company->timezone)*3600)) ;
		}
		
		if($Request['search']['value']){
			$conds[]= 	" `name` LIKE '%".$Request['search']['value']."%'  ";
		}
			$conds[] = " `equipement` = '".$Request['equipement']."' ";
		
		$objs= sensor::load(null,$conds );
		$objs= arrayit($objs);
		$out=  new stdClass();
		$out->draw= $Request['draw'];
		unset($conds["limit"]);
		unset($conds["order"]);
		$out->recordsTotal = sensor::count(array("order"=> "ORDER by id")+$conds);
		$out->recordsFiltered =$out->recordsTotal;
		$out->data= array();
		for($i=0; $i<count($objs);$i++){
			$arr =  array();
			foreach($cols as $col){
				if($col == ""){
					$arr[]= company::load($objs[$i]->$col)->name;
				}else
					$arr[]= $objs[$i]->$col;
			}
		
			$out->data[] = $arr;
		}
		echo json_encode($out);
	}
	
	public static function scentinelOdourConcentrationChart($Request){
		userManager::checkRole(array("admin","manager","user"));
		$user= userManager::getUser();
		$equipement = equipement::load($Request['id']);
		$company= company::load($equipement->company);
		header('Content-Type: application/json');
		$conds = array(		);

        $mindate= 0;
		if($Request['startDate'] !="")
			$mindate= $Request['startDate']-($company->timezone)*3600 ;

        $maxdate= time();
		if($Request['endDate']!="")
			$maxdate= $Request['endDate']-($company->timezone)*3600;

        if($user->extra->datafrom && strtotime($user->extra->datafrom)){
            $newMinDate = strtotime($user->extra->datafrom);
            if ($newMinDate > $mindate){
                $mindate = $newMinDate;
            }
        }

		if($Request['endDate']=="" && $Request['startDate']==""  ){
			$conds["limit"] = " LIMIT 1000";
		}
		$sensors = sensor::load(null, array( "`equipement` = '".$equipement->id."'"  ));
		$sensors = arrayit($sensors);
		for($i=0; $i<count($sensors); $i++){
			$sensors[$i]= $sensors[$i]->id;
		}
		$pidSamples = sample::load(null,array_merge(array(
				" `sensor` in ('".implode(",",$sensors)."') ",
				" `type` <> 'm' ",
				"order"=> "ORDER BY sampledat DESC"
		    ),$conds));

		$pidSamples =array_reverse(arrayit($pidSamples));
		
		$manualSamples= sample::load(null,array_merge(array(
				" `type`='m' ",
				" `equipement` = '".$equipement->id."' ",
				"order"=> "ORDER BY sampledat DESC"
		    ),$conds));
		$manualSamples =array_reverse(arrayit($manualSamples));
		
		$samples= array();
		foreach( array_merge($pidSamples,$manualSamples) as $s){
			$samples[$s->sampledat][$s->type=="m"? "manual" : "predicted"][] = $s->value;
		}
		
		$out = array();
		ksort($samples);
		foreach($samples as $time => $s){
			$o = new stdclass();
			if($s["manual"] ){
				$o->manual= $s["manual"][0];
			}
			
			if($s["predicted"]){
				$o->predicted= (string)(array_sum($s["predicted"])*12+rand(0,10));
			}

			$o->date=  gmdate("d-m-Y H:i", $time+$company->timezone*3600); //$t;//
			$out[]= $o;
		}
		echo json_encode($out);
	}

	public static function get_sample_times($Request){
		userManager::checkRole(array("admin","manager"));
		$parser = Parser::get();
		$equipement= equipement::load($Request['eq']);
		$parser->setVar("equipement",$equipement);
		header('Content-Type: application/json');
		$company= company::load($equipement->company);
		
		$sensors = sensor::load(null, array( "`equipement` = '".$equipement->id."'"  ));
		$sensors = arrayit($sensors);
		for($i=0; $i<count($sensors); $i++){
			$sensors[$i]= $sensors[$i]->id;
		}
		$endOfDate= $Request['date']+24*3600;
		$pidSamples = sample::load(null,array_merge(array(
				" `sensor` in ('".implode(",",$sensors)."') ",
				" `type` <> 'm' ",
			 	" `sampledat` > ".$Request['date'],
				" `sampledat` < ".$endOfDate,
				"order"=> "ORDER BY sampledat ASC",
		)));
		$pidSamples =arrayit($pidSamples);
		
		$pidSamplesDates = array();
		for($i=0; $i<count($pidSamples);$i++){
			$t =  gmdate("H:i",$pidSamples[$i]->sampledat+$company->timezone*3600);
			if(!in_array( array($pidSamples[$i]->sampledat,$t), $pidSamplesDates) ){
				$pidSamplesDates[] = array($pidSamples[$i]->sampledat,$t);
			}
		}
		echo json_encode($pidSamplesDates);
	}
	/* Ajax endpoint to show the chart related to scentinel internal data */
	public static function scentinelChart($Request){
		userManager::checkRole(array("admin","manager","user"));
		$user= userManager::getUser();

		$equipement = equipement::load($Request['id']);
		$company= company::load($equipement->company);
		header('Content-Type: application/json');
		$conds = array(
			"order"=> "ORDER BY sampledat DESC",
		);

        $mindate= 0;
        if($Request['startDate'] !="")
			$mindate= $Request['startDate']-($company->timezone)*3600 ;

        $maxdate= time();
		if($Request['endDate']!="")
			$maxdate= $Request['endDate']-($company->timezone)*3600;

		if($user->extra->datafrom && strtotime($user->extra->datafrom)){
		    $newMinDate = strtotime($user->extra->datafrom);
		    if ($newMinDate > $mindate){
                $mindate = $newMinDate;
            }
        }

        if($Request['endDate']=="" && $Request['startDate']==""  ){
            $conds[]= " `sampledat` >= ".$mindate ;
            $conds["limit"] = " LIMIT 100";
        }else{
            $conds[]= " `sampledat` >= ". $mindate ;
            $conds[]= " `sampledat` <= ". $maxdate;
        }

		$samplesPerSensor = array();
	
		//find the sensors
		$sensors= sensor::load(null, array(
			" `equipement`= '".$equipement->id."' ",
			" `type` IN ('humidity','temperature')" 
		));
		
		$sensors = arrayit($sensors);
		for($j=0; $j<count($sensors);$j++){ //get samples per sensor
			$samples= sample::load(null,array_merge( $conds, array(
					"`sensor` = '".$sensors[$j]->id."'",
			)));
			
			$samples =arrayit($samples);
			for($i=0; $i<count($samples);$i++){
				$t = $samples[$i]->sampledat - ($samples[$i]->sampledat)%60;//+$company->timezone*3600;
				$samplesPerSensor[$t][$sensors[$j]->name]= $samples[$i]->value;
			}
		}

		$out = array();
		foreach($samplesPerSensor as $t => $sensor){
			$o = new stdclass();
			foreach ($sensor as $name => $value){
					$label =$name;
					$o->$label = $value;
				
			}
			$o->date=  gmdate("d-m-Y H:i", $t+$company->timezone*3600); //$t;//
			$out[]= $o;
		}
		echo json_encode(array_reverse($out));
	
	}
	/* ajax endpoint for the chart shows the pid data */
	public static function pidChart($Request){
		userManager::checkRole(array("admin","manager","user"));
		$user= userManager::getUser();
		$sensor= sensor::load($Request['pid']);
		$equipement = equipement::load($sensor->equipement);
		$company= company::load($equipement->company);
		
		$conds = array("`sensor` = '".$sensor->id."'");

        $mindate= 0;
		if($Request['startDate']!=""){
			$mindate = ($Request['startDate']-($company->timezone*3600));
		}

        $maxdate= time();
		if($Request['endDate']!=""){
			$maxdate=($Request['endDate']-($company->timezone*3600));
		}

        if($user->extra->datafrom && strtotime($user->extra->datafrom)){
            $newMinDate = strtotime($user->extra->datafrom);
            if ($newMinDate > $mindate){
                $mindate = $newMinDate;
            }
        }

        if($Request['endDate']=="" && $Request['startDate']==""  ){
            $conds[]= " `sampledat` >= ".$mindate ;
            $conds["limit"] = " LIMIT 1000";
		 }else{
            $conds[]= " `sampledat` >= ". $mindate ;
            $conds[]= " `sampledat` <= ". $maxdate;
        }

		
        $conds['order'] = "ORDER BY sampledat DESC";
		$times = array();
		$samplesPerSensor = array();
		$samples= sample::load(null,$conds);
		$samples =arrayit($samples);

		for($i=0; $i<count($samples);$i++){
			$t = $samples[$i]->sampledat - $samples[$i]->sampledat%60;//+($company->timezone*3600);
			$times[]= $t;
			if($Request['gas']) {
				$samplesPerSensor[$sensor->name][$t]= number_format(($samples[$i]->value)*(100/sensor::$pids[$Request['gas']]),4, '.', '');
            }else {
				$samplesPerSensor[$sensor->name][$t]= $samples[$i]->value;
            }
		}

		sort($times,SORT_NUMERIC);
	
		$out = array();
		foreach ($times as $t){
			//rounding wind time
			$o = new stdclass();
			foreach ($samplesPerSensor as $sensorname => $values){
				if($values[$t])
					$o->$sensorname = $values[$t];
			}
			$o->date=  gmdate("d-m-Y H:i", $t+$company->timezone*3600);
			$out[]= $o;
		}
		
		echo json_encode($out);
	}
	
	public static function windChart($Request){
		userManager::checkRole(array("admin","manager","user"));
		$user= userManager::getUser();
		$equipement = equipement::load($Request['id']);
		$company= company::load($equipement->company);
	
		$conds = array(
				"`location` = '".$company->city."' ",
		);

        $mindate= 0;
		if($Request['startDate']!=""){
			$mindate = ($Request['startDate']-($company->timezone*3600));
		}

        $maxdate= time();
		if($Request['endDate']!=""){
			$maxdate=($Request['endDate']-($company->timezone*3600));
		}

        if($user->extra->datafrom && strtotime($user->extra->datafrom)){
            $newMinDate = strtotime($user->extra->datafrom);
            if ($newMinDate > $mindate){
                $mindate = $newMinDate;
            }
        }

        if($Request['endDate']=="" && $Request['startDate']==""  ){
			$conds[]= " `createdat` >= ".$mindate ;
			$conds["limit"] = " LIMIT 100";
		} else{
            $conds[]= " `createdat` >= ".$mindate;
            $conds[]= " `createdat` <= ".$maxdate;
        }
		
		$conds['order'] = "ORDER BY id DESC";

		$times = array();
		$wind = wind::load(null,$conds);
        $wind = arrayit($wind);
		for($i=0; $i<count($wind);$i++){
			$t = $wind[$i]->createdat - $wind[$i]->createdat%60;
			$times[]= $t;
			$windSamples[$t]= $wind[$i];
		} 
	
		sort($times,SORT_NUMERIC);
	
		$out = array();
		foreach ($times as $t){
			//rounding wind time
			$o = new stdclass();
			$w= $windSamples[$t];
				if($w){
			$o->windspeed= $w->speed;
			$o->winddirection= $w->direction;
			$o->windchill = $w->chill;
			} 
			
			$o->date=  gmdate("d-m-Y H:i", $t+$company->timezone*3600); //$t;//
			$out[]= $o;
		}
	
		echo json_encode($out);
	
	}
	
	/* deletes data related to and equipement.  (the upper form in the page of equipement)*/
	public static function deletedata($Request){
        $equipement = equipement::load($Request['id']);
        $conds = self::prepareConds($Request);
        $conds2 = array_merge($conds, array(" `equipement`='".$equipement->id."' "));
        sample::delete(null,$conds2);
        //logs
        $conds3 = array_merge ($conds, array(" `equipement`='".$equipement->name."' "));
        log::delete(null,$conds3);

	}

    /* downloads data as csv*/
    public static function downloaddata($Request){
        $conds = self::prepareConds($Request);
        $conds[] = "equipement = '".$Request['id']."'";
        $count = sample::count($conds);
        header('Content-type: text/csv');
        header('Content-Disposition: attachment; filename="export.csv"');
        $output = [];
        $conds = array_merge(self::prepareConds($Request),
            array(
                "equipement = '".$Request['id']."'",
                "order"=> "ORDER BY sampledat DESC",
            ));
        $samples= sample::load(null, $conds);
        $locations = [];
        $equipment = equipement::load($Request['id']);
        $company = company::load($equipment->company);
        foreach($samples as $sample){
            $sample->sampledat+= $company->timezone*3600;
            $output [$sample->sampledat][$sample->sensor] = $sample->value;
            $locations[$sample->sampledat] = $sample->lon.",".$sample->lat;
        }

        $sensors = sensor::load(null, array("order"=> "ORDER BY name","equipement = '".$Request['id']."'"));
        $sensorIdsWithNames= array();
        for($i=0; $i< count($sensors); $i++){
            $sensorIdsWithNames[$sensors[$i]->id]= $sensors[$i]->name;
        }
        echo "DATE TIME (timezone:".$company->timezone."),".implode(",",array_values($sensorIdsWithNames)).",longitude,latitude\r\n";
        ksort($output);
        foreach($output as $time => $cells){
            $dt= new DateTime("@".$time);
            $line = array($dt->format('Y-m-d H:i:s'));
            foreach($sensorIdsWithNames as $sensorId => $sensorName){
                if (isset($cells[$sensorId])){
                    $line[] = $cells[$sensorId];
                }else{
                    $line[] = "-";
                }
            }
            echo implode(",", $line).",".$locations[$time]."\r\n";
        }

    }
	private static function prepareConds($Request)
    {
        userManager::checkRole(array("manager", "admin"));
        $user = userManager::getUser();
        if (!$Request['id']) {
            die("no equipement Id");
        }
        $conds = array();
        $equipement = equipement::load($Request['id']);
        $company = company::load($equipement->company);
        if (!userManager::hasRole(array("admin"))) {
            if (userManager::getUser()->getCompany()->id != $company->id) {
                die("no access");
            }
        }
        $mindate = 0;
        if ($Request['startDate'] != "") {
            $mindate = (strtotime($Request['startDate']) - ($company->timezone) * 3600);
        }

        if($user->extra->datafrom && strtotime($user->extra->datafrom)){
            $newMinDate = strtotime($user->extra->datafrom);
            if ($newMinDate > $mindate){
                $mindate = $newMinDate;
            }
        }
        $maxdate= time();
        if($Request['endDate']!=""){
            $maxdate = (strtotime($Request['endDate'])-($company->timezone)*3600);
        }

        $conds[]=" `sampledat` >= ". $mindate ." AND " ."`sampledat` <= ".$maxdate;
        return $conds;
    }
}

