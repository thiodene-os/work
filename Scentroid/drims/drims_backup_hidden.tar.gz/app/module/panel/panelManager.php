<?php

require_once realpath(dirname(__FILE__)).'/../core/abstract/module.php';
require_once realpath(dirname(__FILE__)).'/../security/userManager.php';
require_once realpath(dirname(__FILE__)).'/../security/company.php';

require_once realpath(dirname(__FILE__)).'/../core/moduleManager.php';
require_once realpath(dirname(__FILE__)).'/../panel/equipement.php';
require_once realpath(dirname(__FILE__)).'/../panel/sample.php';
require_once realpath(dirname(__FILE__)).'/../panel/sensor.php';

require_once realpath(dirname(__FILE__)).'/../weather/weatherManager.php';

/* panel controller */
class panelManager extends module{
	/* shows the welcome page for admin, limited pages for manager and user */
	public static function welcome($Request){
		userManager::checkRole(array("admin","manager","user"));
		$parser = Parser::get();
		
		$company= userManager::getUser()->getCompany();

		if(userManager::hasRole("admin")){
			$equipements = equipement::load(null, array("order"=>"ORDER BY id DESC"));
		}else{
		    $equipmentCategories = userManager::getUser()->extra->equipment_category;
		    if ($equipmentCategories && $equipmentCategories != "") {
		        for($i=0; $i<count($equipmentCategories); $i++){
                    $equipmentCategories[$i] = "'".$equipmentCategories[$i]."'";
                }
                $equipmentCategories = implode(",",$equipmentCategories);
                $equipements = equipement::load(null, array(" `company`='".$company->id."' ",
                    "category IN ($equipmentCategories)",
                    "order"=>"ORDER BY id DESC"));

            } else {
                $equipements = equipement::load(null, array(" `company`='".$company->id."' ","order"=>"ORDER BY id DESC"));
            }
		}

        if(!$equipements) {
		    die("there is no equipment assigned to your company or your account equipment group. Please contant support");
        }
		$equipements = arrayit($equipements);
        $equipementsIds = array();
		$locSample = array();
		for($i=0; $i<count($equipements); $i++){
            $equipementsIds[] = $equipements[$i]->id;
		}
        $equipementsIds = "(".implode(",", $equipementsIds).")";


        $queryResult = DB::get()->exQuery("SELECT max(id) as sample_id, equipement FROM sample where equipement in $equipementsIds GROUP BY equipement");
        for($i=0; $i<count($queryResult); $i++) {
            $locSample[$queryResult[$i]->equipement] = sample::load($queryResult[$i]->sample_id);
            foreach($equipements as $equipement){
                if($queryResult[$i]->equipement == $equipement->id){
                    $locSample[$queryResult[$i]->equipement]->equipement = $equipement->name;
                }
            }
        }
        #$locSample[$i] = sample::load(null, array("limit"=> " LIMIT 1" , "order"=>" ORDER BY id DESC", "`equipement`='".$equipements[$i]->id."' "));

        if($Request['equipement']){
			$equipement = equipement::load($Request['equipement']);
			$sp_sensors= sensor::$special_sensors;
			for($i=0; $i<count($sp_sensors);$i++){
				$sp_sensors[$i] = "'".addslashes($sp_sensors[$i])."'";
			}
			$sp_sensors = implode(",", $sp_sensors);


            if($Request['location'] and strlen($Request['location']) == 1){
                $parser->setVar("selectedLocation",$Request['location']);
                $pidSensors= sensor::load(null, array(" `packet_id` LIKE '%".$Request['location']."' ",
                    "( type='pid' or `type` IN (".$sp_sensors.") )",
                    " `equipement` ='".$equipement->id."' "));

            }else{
                $parser->setVar("selectedLocation","All Ports");
                $pidSensors= sensor::load(null, array("( type='pid' or `type` IN (".$sp_sensors.") )", " `equipement` ='".$equipement->id."' "));

            }

			$pidSensors = arrayit($pidSensors);
			#last sample per sensor
            $lastSample=array();
			for($i=0; $i<count($pidSensors); $i++){
                $pidSensorsIds[] =  $pidSensors[$i]->id;
			}
            $pidSensorsIds = "(".implode(",", $pidSensorsIds).")";
            $queryResult = DB::get()->exQuery("SELECT max(id) as sample_id, sensor FROM sample where sensor in $pidSensorsIds GROUP BY sensor");
            for($i=0; $i<count($queryResult); $i++){
                $lastSample[$queryResult[$i]->sensor] = sample::load($queryResult[$i]->sample_id);
            }


            #$lastSample[$pidSensors[$i]->id]= sample::load(null,array("order"=>"order by ID DESC","limit"=>"limit 1","sensor=".$pidSensors[$i]->id));
			$parser->setVar("lastSample", arrayit($lastSample));
			$parser->setVar("pidSensors", arrayit($pidSensors));//to activate the javascript for chart
			$parser->setVar("equipement", $equipement);

			$locations = sensor::getAllLocations($equipement->id);
            $locations[]= "All Ports";
			$parser->setVar("locations",$locations);



            $s = sample::getLastBySensorNameAndEquipementId("Internal Humidity", $equipement->id);
			$sampleInteriorHumidity= $s ? $s : new stdClass();
			$parser->setVar("sampleInteriorHumidity",$sampleInteriorHumidity);
			$s = sample::getLastBySensorNameAndEquipementId("Internal Temperature",  $equipement->id);
			$sampleInteriorTemperature= $s ? $s : new stdClass();
			$parser->setVar("sampleInteriorTemperature",$sampleInteriorTemperature);
			
			$s = sample::getLastBySensorNameAndEquipementId("External Humidity",  $equipement->id);
			$sampleExteriorHumidity= $s ? $s : new stdClass();
			$parser->setVar("sampleExteriorHumidity",$sampleExteriorHumidity);
			$s = sample::getLastBySensorNameAndEquipementId("External Temperature",  $equipement->id);
			$sampleExteriorTemperature= $s ? $s : new stdClass();
			$parser->setVar("sampleExteriorTemperature",$sampleExteriorTemperature);

            $pidChartGuides= array();
            $queryResult = DB::get()->exQuery("SELECT sensor, MIN(0 +value) as min, AVG(0 +value) as avg, MAX(0 +value) as max FROM sample where sensor in $pidSensorsIds $timeRange  group by sensor") ;
            for($i=0; $i<count($queryResult); $i++){
                $sensorIndex = -1;
                for($j=0; $j<count($pidSensors); $j++) {
                    if ($pidSensors[$j]->id == $queryResult[$i]->sensor) {
                        $sensorIndex= $j;
                    }
                }
                $pidChartGuides[$sensorIndex]['min']= $queryResult[$i]->min;
                $pidChartGuides[$sensorIndex]['avg']= $queryResult[$i]->avg;
                $pidChartGuides[$sensorIndex]['max']= $queryResult[$i]->max;
            }

            $parser->setVar("pidChartGuides", $pidChartGuides);
            $samplesPerEquipementSensor = array();
            $chartNames = array();
            //find the sensors
            $sensors= sensor::load(null, array(
                " `equipement`= '".$equipement->id."' ",
                " `type` IN ('humidity','temperature')"

            ));
          //  var_dump($sensors);die();
            $sensors = arrayit($sensors);

            for($i=0; $i<count($sensors);$i++){
                $o = new stdClass();
                $o->name  = $sensors[$i]->name;;
                $o->unit = $sensors[$i]->dataunit;
                $o->type = $sensors[$i]->type;
                $chartNames[]= $o;
            }
            $parser->setVar("chartNames", $chartNames);

            $company =company::load($equipement->company);

        }else{
            $company = company::load($equipements[0]->company);
        }
        $parser->setVar("city", $company->city);


        if($Request['startDateParsed']  ){
			$parser->setVar("startDateParsed",   $Request['startDateParsed']);
			$parser->setVar("startDate",  strtotime( $Request['startDateParsed']));
		}elseif($Request['startDate']  ){
			$parser->setVar("startDate", $Request['startDate']);
		}
		if($Request['endDateParsed']  ){
			$parser->setVar("endDateParsed",   $Request['endDateParsed']);
			$parser->setVar("endDate",  strtotime( $Request['endDateParsed']));
		}elseif($Request['endDate']  ){
			$parser->setVar("endDate", $Request['endDate']);
		}
		if($parser->getVar("endDate"))
			$timeRange = " AND sampledat < ".$parser->getVar("endDate");
		if($parser->getVar("startDate"))
			$timeRange .=" AND sampledat > ".$parser->getVar("startDate");
		

		$parser->setVar("equipements", $equipements);
		$parser->setVar("locSample", $locSample);
		$parser->setVar("panel", true);//to activate the javascript for chart
		
		if($Request['gas']){
			$parser->setVar("gas", $Request['gas']);		
		}
		

		
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_1", "1");
		
		$parser->insert("contentblock", "panel");
		$parser->parse("single");
	}
	/* shows stuff related to an equipement. */
	public static function showequipement($Request){
		$Request2 = array();
		$Request2['equipement'] = $Request['id'];
		$Request2['gas'] = $Request['gas'];
		$Request2['endDate'] = $Request['endDate'];
		$Request2['startDate'] = $Request['startDate'];
		$Request2['endDateParsed'] = $Request['endDateParsed'];
		$Request2['startDateParsed'] = $Request['startDateParsed'];
        $Request2['location'] = $Request['location'];
        self::welcome($Request2);
	}
	/*
	 * An admin view of all devices.
	 */
	public static function overview($Request){
		userManager::checkRole("admin","manager","user");
		$parser= Parser::get();
		
		
		$equipements = equipement::load(null, array("order"=>"ORDER BY id DESC"));
		$equipements = arrayit($equipements);
        $locSample = array();
        $equipementsIds = array();
        for($i=0; $i<count($equipements); $i++){
            $equipementsIds[] = $equipements[$i]->id;
        }
        $equipementsIds = "(".implode(",", $equipementsIds).")";


        $queryResult = DB::get()->exQuery("SELECT max(id) as sample_id, equipement FROM sample where equipement in $equipementsIds GROUP BY equipement");
        for($i=0; $i<count($queryResult); $i++) {
            $locSample[$queryResult[$i]->equipement] = sample::load($queryResult[$i]->sample_id);
            foreach($equipements as $equipement){
                if($queryResult[$i]->equipement == $equipement->id){
                    $locSample[$queryResult[$i]->equipement]->equipement = $equipement->name;
                }
            }

        }
		
		$parser->setVar("equipements", arrayit($equipements));
		$parser->setVar("locSample", $locSample);
		$parser->setVar("panel", true);
		
	
		$parser->insert("contentblock", "overview");
		$parser->setVar("menu_1", "1");
		$parser->setVar("menu_1_0", "1");
		$parser->parse("single");
	}
	
	public static function samples($Request){
		userManager::checkRole(array("admin","manager","user"));
		$parser = Parser::get();
		$company= userManager::getUser()->getCompany();
		
		if($Request['id']){
			$equipement = equipement::load($Request['id']);
			if(!userManager::hasRole(array("admin")) && userManager::getUser()->company != $equipement->company) die("no access");
			$sp_sensors= sensor::$special_sensors;
			for($i=0; $i<count($sp_sensors);$i++){
				$sp_sensors[$i] = "'".addslashes($sp_sensors[$i])."'";
			}
			$sp_sensors = implode(",", $sp_sensors);
			$pidSensors= sensor::load(null, array( " `equipement` ='".$equipement->id."' ")); 
			$pidSensors = arrayit($pidSensors);
			$lastSample=array();
			for($i=0; $i<count($pidSensors); $i++){
				$lastSample[$pidSensors[$i]->id]= sample::load(null,array("order"=>"order by ID DESC","limit"=>"limit 1","sensor=".$pidSensors[$i]->id));
			}
			$parser->setVar("lastSample", arrayit($lastSample));
			$parser->setVar("pidSensors", arrayit($pidSensors));//to activate the javascript for chart
			$parser->setVar("equipement", $equipement);
			$parser->setVar("obj", $equipement); //for purge button

		}
		$parser->setVar("menu_2", "1");
		$parser->setVar("menu_2_1", "1");	
		
		$parser->insert("contentblock", "samples-overview");
		
		$parser->parse("single");
		
	}

}
