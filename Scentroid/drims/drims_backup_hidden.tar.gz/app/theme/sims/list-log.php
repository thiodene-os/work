
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span>Logs List for <?php echo userManager::getUser()->getCompany()->name?></span></div>
				<div class="box-content">
					<div class="flip-scroll">
						<div class="form-group">
								<div class="row">								
									<div class="col-xs-2">
										<div class='input-group date' id='mindate'>
										<input type='text' class="form-control" name="date"   placeholder="from"  />
										<span class="input-group-addon">
											<span class="fa fa-calendar"></span>
										</span>
									</div>
									</div>
									<div class="col-xs-2">
										<div class='input-group date' id='maxdate'>
											<input type='text' class="form-control" name="date"   placeholder="to"  />
											<span class="input-group-addon">
												<span class="fa fa-calendar"></span>
											</span>
										</div>
									</div>
									<div class="col-xs-2">
											<select  class="form-control" id="logtype">
												<option value="">-Any Type-</option>
												<option>INFO</option>
												<option>WARN</option>
												<option>ERROR</option>
											</select>
									</div>
									<div class="col-xs-2">
											<select  class="form-control" id="equipement">
												<option value="">-Any Equipement-</option>
												<?php for($i=0; $i<count($equipement);$i++){ ?>
													<option><?php echo $equipement[$i]->name ?></option>
												<?php } ?>
											</select>
									</div>
									<?php if($company){?>
									<div class="col-xs-2">
											<select  class="form-control" id="company">
												<option value="">-Any Company-</option>
												<option value="System">-System-</option>
												<?php for($i=0; $i<count($company);$i++){ ?>
												<option><?php echo $company[$i]->name ?></option>
												<?php } ?>
											</select>
									</div>
									<?php }?>
									<button class="btn btn-danger" type="button" id="purgelog">Purge Specified Log Data</button>
								</div>
						</div>
						<table id="log-list" class="data-table table table-striped table-bordered">
						    <thead>
						        <tr>
						            <th>ID</th>
						            <th>Company</th>
						            <th>Device</th>
						            <th>Type</th>
   						            <th>Message</th>
   						            <th>Time</th>
						        </tr>
						    </thead>
						 
						    <tfoot>
						         <tr>
						            <th>ID</th>
						            <th>Company</th>
						            <th>Device</th>
						            <th>Type</th>
   						            <th>Message</th>
   						            <th>Time</th>
						        </tr>
						    </tfoot>
						 
						    <tbody>
					
						    </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
