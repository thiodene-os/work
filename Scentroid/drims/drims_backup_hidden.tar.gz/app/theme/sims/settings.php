
	<div class="row">
		<div class="col-md-12">

            <?php if($saved) {?>
            <div class="alert-success alert">
                Settings saved.
            </div>
            <?php } ?>

            <form action="{baseurl}do/panel/setting.save" method="POST" class="form-horizontal">

            <?php foreach($settingGroups as $settingGroup) {?>
			<div class="box">
                <div class="box-header"><span><?php echo $settingGroup ?></span></div>
                <div class="box-content">
                    <div class="panel panel-default">
                        <div class="panel-body">
                        <?php foreach($setting as $s) { ?>
                            <div class="form-group">
                                <div class="col-md-3">
                                    <label class="control-label"><?php echo $s->name ?></label>
                                </div>
                                <div class="col-md-9">
                                    <textarea name="setting[<?php echo $s->name ?>]" class="form-control"><?php echo $s->value ?></textarea>
                                    <span class="help-block">
                                        Last Update by <?php
                                        $u = user::load($s->updatedby);
                                        echo $u->name." ".$u->family ?> on <?php echo date("Y-m-d H:i:s", $s->updatedat)?> </span>
                                </div>

                            </div>
                        <?php } ?>
                        <div class="col-md-12">
                            <br>Variables: <br><br>
                            <ul>
                                <li>{ScentinelSN}: Scentinel Serial Number </li>
                                <li>{Company}: Company Name </li>
                                <li>{k}: get param[k] , k=0,1,2,...n</li>
                            </ul>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
			</div>
        <?php } ?>
        <button type="submit" class="btn btn-success">Save</button>
        </form>

        </div>
	</div>
