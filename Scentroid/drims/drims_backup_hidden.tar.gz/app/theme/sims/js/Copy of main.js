
$(document).ready(function() {
//
	$('#navigation>ul>li.active').find('ul').slideDown(0);
	$('#navigation>ul>li>a').click(function() {
		if($(this).parent('li').hasClass('active')) {
			$(this).parent('li').find('ul').slideUp(200);
			$(this).parent('li').removeClass('active');
		}else {
			$('#navigation>ul>li>ul').slideUp(200);
			$('#navigation>ul>li').removeClass('active');
			$(this).parent('li').addClass('active');
			$(this).parent('li').find('ul').slideDown(200);
		}
	    return false;
	});
//
	/*var table = $('.data-table').DataTable();
	var tt = new $.fn.dataTable.TableTools( table );
	$( tt.fnContainer() ).insertBefore('div.dataTables_wrapper');*/
	
	function zeroFill(number, width) {
	    width -= number.toString().length;
	    if(width > 0) {
	        return new Array(width + (/\./.test(number) ? 2 : 1)).join('0') + number;
	    }
	    return number + ""; // always return a string
	}
	
	if($('#company-list').length)
	table= $('#company-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/security/company.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
              "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      }
                  ]
              },
	        "columnDefs": [	
	                       {
	                           "render": function ( data, type, row ) {
	                        	   
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/security/company.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/security/company.edit?id='+data+'">Edit</a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 4
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 3
	                       }
	                      ]
	    } );
	    if($('#equipement-list').length)
		table= $('#equipement-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/equipement.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/equipement.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/panel/equipement.edit?id='+data+'">Edit</a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 4
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 3
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 2
	                       }
	                      ]
	    } );
	 	if($('#technician-list').length)
		table= $('#technician-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/technician.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/technician.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/panel/technician.edit?id='+data+'">Edit</a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 2
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a")
	                           },
	                           "targets": 1
	                       }
	                      ]
	    } );
		if($('#project-list').length)
		table= $('#project-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/project.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/project.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/panel/project.edit?id='+data+'">Edit</a>'
	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 3
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 2
	                       }
	                      ]
	    } );
		
		if($('#panelist-list').length)
		table= $('#panelist-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/panelist.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   return zeroFill(data,4);
	                           },
	                           "targets": 0
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/panelist.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/panel/panelist.edit?id='+data+'">Edit</a>'
	                        	   str += '<a class="btn btn-small btn-default" href="/do/panel/nsample.page?p='+data+'">Samples</a>'
	                        	   str += '<a class="btn btn-small btn-default" href="/do/panel/panelist.criteria?id='+data+'">Selection Criteria</a>'
	                        	   //str += '<a class="btn btn-small btn-default" href="/do/panel/nsample.report?p='+data+'">Report</a>'

	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 6
	                       }
	                      ]
	    } );
		if($('#nsample-list').length)
		table= $('#nsample-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/panel/nsample.ajaxlist?p="+$("#panelist").val(),
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3,4 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3,4]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3,4 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3,4]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3,4 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/panelist.delete?id='+data+'">Delete</a>'

	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 5
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 3
	                       },
	                       {
	                           "render": function ( data, type, row ) {
	                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
	                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
	                           },
	                           "targets": 4
	                       }
	                      ]
	    } );
		if($('#report-list').length)
			table= $('#report-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "ajax": {
		            "url": "/do/panel/report.ajaxlist",
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		                d.mindate2 = $('#mindate2 input').val();
		                d.maxdate2 = $('#maxdate2 input').val();
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		          "oTableTools": {
		              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
		              "aButtons": [
	                      {
	                          "sExtends": "csv",
	                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "pdf",
		                          "mColumns": [ 0, 1, 2,3]
		                      },
		                      {
		                          "sExtends": "xls",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "copy",
		                          "mColumns": [ 0, 1, 2,3 ]
		                      },
		                      {
		                          "sExtends": "print",
		                          "mColumns": [ 0, 1, 2,3]
		                      }
	                  ]
	              },
		        "columnDefs": [
		                       {
		                           "render": function ( data, type, row ) {
		                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/report.delete?id='+data+'">Delete</a>'
		                        	   str += '<a class="btn btn-small btn-default" href="/do/panel/report.download?p='+data+'">Download</a>'
		                        	   str += '<a class="btn btn-small btn-default" href="/do/panel/report.printpage?id='+data+'">Print</a>'

		                        	   return str;
		                           },
		                           "orderable": false ,
		                           "targets": 4
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 3
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");

		                           },
		                           "targets": 2
		                       }
		                      ]
		    } );
		if($('#sample-list').length)
			table= $('#sample-list').DataTable( {
		        "processing": true,
		        "serverSide": true,
		        "ajax": {
		            "url": "/do/panel/sample.ajaxlist",
		            "data": function ( d ) {
		                d.mindate = $('#mindate input').val();
		                d.maxdate = $('#maxdate input').val();
		                d.mindate2 = $('#mindate2 input').val();
		                d.maxdate2 = $('#maxdate2 input').val();
		            }
		          },
		          dom: 'T<"clear">lfrtip',
		          "oTableTools": {
		              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
		              "aButtons": [
	                      {
	                          "sExtends": "csv",
	                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "pdf",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "xls",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "copy",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      },
		                      {
		                          "sExtends": "print",
		                          "mColumns": [ 0, 1, 2,3,4,5,6,7,8,9 ]
		                      }
	                  ]
	              },
		        "columnDefs": [
		                       {
		                           "render": function ( data, type, row ) {
		                        	   str = '<a class="btn btn-small btn-danger" href="/do/panel/sample.delete?id='+data+'">Delete</a>'
		                        	   str += '<a class="btn btn-small btn-default" href="/do/panel/sample.edit?id='+data+'">Edit</a>'

		                        	   return str;
		                           },
		                           "orderable": false ,
		                           "targets": 10
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 9
		                       },
		                       {
		                           "render": function ( data, type, row ) {
		                        	   //return new Date(data*1000).toLocaleFormat('%d-%b-%Y')
		                        	   return moment(data*1000).format("dd DD/MM/YYYY, h:mm a");
		                           },
		                           "targets": 8
		                       }
		                      ]
		    } );
		if($('#user-list').length)
		table= $('#user-list').DataTable( {
	        "processing": true,
	        "serverSide": true,
	        "ajax": {
	            "url": "/do/security/user.ajaxlist",
	            "data": function ( d ) {
	                d.mindate = $('#mindate input').val();
	                d.maxdate = $('#maxdate input').val();
	            }
	          },
	          dom: 'T<"clear">lfrtip',
	          "oTableTools": {
	              "sSwfPath": "/app/theme/lims/swf/copy_csv_xls_pdf.swf",
	              "aButtons": [
                      {
                          "sExtends": "csv",
                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "pdf",
	                          "mColumns": [ 0, 1, 2,3,4,5]
	                      },
	                      {
	                          "sExtends": "xls",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      },
	                      {
	                          "sExtends": "copy",
	                          "mColumns": [ 0, 1, 2,3,4,5]
	                      },
	                      {
	                          "sExtends": "print",
	                          "mColumns": [ 0, 1, 2,3,4,5 ]
	                      }
                  ]
              },
	        "columnDefs": [
	                       {
	                           "render": function ( data, type, row ) {
	                        	   str = '<a class="btn btn-small btn-danger" href="/do/security/user.delete?id='+data+'">Delete</a>'
	                        	   str += '<a class="btn btn-small btn-info" href="/do/security/user.edit?id='+data+'">Edit</a>'

	                        	   return str;
	                           },
	                           "orderable": false ,
	                           "targets": 6
	                       }
	                      ]
	    } );
//
	
				   
		  
			   if( $('#datetimepicker').length){
				   t= $('#datetimepicker input').val();
				   t*=1000;
				   $('#datetimepicker').datetimepicker();
				   $('#datetimepicker').data("DateTimePicker").date(new Date(t));
			   }
			 
           
		   
		   if($("#mindate").length  && $("#maxdate").length ){
			 /*  $('#mindate input').keyup( function() { console.log(table); table.draw(); } );
			   $('#maxdate input').keyup( function() { console.log(table);  table.draw(); } );
			 */  $('#mindate').datetimepicker();
		        $('#maxdate').datetimepicker({
		            useCurrent: false //Important! See issue #1075
		        });
		        $("#mindate").on("dp.change", function (e) {
		            $('#maxdate').data("DateTimePicker").minDate(e.date);
		            mindate = moment(e.date).unix();
		            table.draw();
		        });
		        $("#maxdate").on("dp.change", function (e) {
		            $('#mindate').data("DateTimePicker").maxDate(e.date);
		            maxdate = moment(e.date).unix();
		            table.draw();
		        });
		   }
	$('.dropdown-menu').click(function(e) {
        e.stopPropagation();
    });
});