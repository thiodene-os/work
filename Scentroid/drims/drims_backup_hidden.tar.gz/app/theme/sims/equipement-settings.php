
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span> Equipement Settings  for <?php echo $obj->name?> - <?php echo userManager::getUser()->getCompany()->name?></span>
				<a id="purge_now" href="" class="btn btn-success">Fill Bag</a>
				</div>			
					<form action="{baseurl}do/panel/equipement.save" method="POST" class="form-horizontal">
						<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
						<?php 
						//$obj->extra = json_decode($obj->extra);
						?>
						<div class="panel panel-default hide">
						  <div class="panel-heading">Request Fault Tolerance</div>
						  <div class="panel-body">
							<div class="form-group">
								<label for="" class="control-label col-sm-3">Sequence Number:</label>
								<div class="col-sm-6">
									<input name="extra[seq_num]" id="" type="text" class="form-control"  value="<?php echo $obj->extra->seq_num ?>">
								</div>
								<div class="col-sm-3">
								
								</div>
							</div>
							<div class="form-group">
								<label for="" class="control-label col-sm-3">Last Received Packet Sequence Number(ACK):</label>
								<div class="col-sm-6">
									<input name="extra[ack]" id="" type="text" class="form-control"  value="<?php echo $obj->extra->ack ?>">
								</div>
							</div>
						 </div>
						</div>
						
						<?php 
						if($obj && equipementManager::getUpdatedTime($obj->id) > 0 ){?>
						<div class="box-content">
						<div class="panel panel-default">
						<div class="panel-body">
							<?php if($obj &&  equipementManager::getUpdatedTime($obj->id) > 0){?>
							<div class="col-md-6">
							Last configuration date (Your Timezone): 
							</div>
							<div class="col-md-6"><?php
							echo date('D, d M Y H:i:s',equipementManager::getUpdatedTime($obj->id)  )?>
							</div>
							<?php }?>
							<?php if(false && $obj->extra->purgedat){?>
							<div class="col-md-6">
							Last Bag Filled at (Your Timezone):
							</div>
							<div class="col-md-6">
							 <?php
							echo date('D, d M Y H:i:s',$obj->extra->purgedat  )?>
							</div>
							<?php }?>
						</div>
						</div>
						</div>
						<?php }?>

                        <div class="box-content">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <div class="form-group">

                                    <?php if($obj &&  equipementManager::getUpdatedTime($obj->id) > 0){?>
                                        <div class="col-md-6">
                                            Secret for API Access:
                                        </div>
                                        <div class="col-md-6">
                                            <?php if (userManager::hasRole("admin")){ ?>
                                                <input name="secret" id="" type="text" class="form-control"  value="<?php echo $obj->secret?>">
                                                <?php
                                            }else{
                                                echo $obj->secret;
                                            }
                                            ?>
                                        </div>
                                    <?php }?>
                                    </div>
                                    <div class="form-group">
                                    <?php if($obj){?>
                                        <div class="col-md-6">
                                            Equipment Category:
                                        </div>
                                        <div class="col-md-6">
                                            <?php if (userManager::hasRole("admin")){ ?>
                                                <select name="category" class="form-control">
                                                    <option <?php if(!$obj->category) echo "selected" ?>  value="">None</option>
                                                    <?php foreach($equipmentCategories as $category) {?>
                                                    <option <?php if($category == $obj->category) echo "selected" ?>><?php echo $category?></option>
                                                    <?php } ?>
                                                </select>
                                                <?php
                                            }else{
                                                echo $obj->group;
                                            }
                                            ?>
                                        </div>
                                    <?php }?>
                                    </div>
                                </div>
                            </div>
                        </div>

						<div class="box-content">
						<?php foreach($equipementSettings as $groupName => $setting){
							if($groupName != "Network"){
							?>
						<div class="panel panel-default">
							<div class="panel-heading"><?php echo $groupName?></div>
					  		<div class="panel-body">
					  			<?php for($i=0; $i<count($setting); $i++){?>
								<div class="form-group">
										<label for="" class="control-label col-sm-5"><?php echo const2word($setting[$i][1])?>:</label>
										<div class="col-sm-4">
											<input name="extra[<?php echo $setting[$i][1]?>]" id="" type="text" class="form-control"  value="<?php echo get_object_vars($obj->extra)[$setting[$i][1]] ?>">
										</div>
										<div class="col-sm-3">
											<?php
											if($setting[$i][1] =="RELAY_TRIGGER_LIMIT_KEY_NAME"){

											}else{
												echo $setting[$i][3];
											}?>
										</div>
								</div>
								<?php }?>
							</div>
						</div>
						<?php }?>
						<?php }?> 
						<?php /*
						<div class="panel panel-default">
						  <div class="panel-heading">Equipement Command</div>
						 
						  <div class="panel-body">
						 	Previous command:  <?php 
						 	$command= array(
								"1"=>"STATE_STOP",
								"16"=>"STATE_PURGING"
							);
						 	echo $command[$obj->extra->command] ?>
						 	<br>
						 	<center>
						  	<a href="{baseurl}do/panel/equipement.command?id=<?php echo $obj->id?>&command=1" class="btn btn-danger" >Stop</a>
						  	<a href="{baseurl}do/panel/equipement.command?id=<?php echo $obj->id?>&command=16" class="btn btn-info" >Purge</a>
						  	</center>
							<!-- <div class="form-group">
								<label for="" class="control-label col-sm-3">Command (System Operation State) from Server:</label>
								<div class="col-sm-6">
										<select name="extra[command]" class="form-control" >
											<option <?php echo $obj->extra->command ==1? "selected":"" ?> value="1">STATE_STOP</option>
											<option <?php echo $obj->extra->command ==2? "selected":"" ?> value="2">STATE_RUNNING_SAMPLING</option>
											<option <?php echo $obj->extra->command ==4? "selected":"" ?> value="4">STATE_RUNNING_RECORDING</option>
											<option <?php echo $obj->extra->command ==8? "selected":"" ?> value="8">STATE_RUNNING_TRANSMITTING</option>
											<option <?php echo $obj->extra->command ==16? "selected":"" ?> value="16">STATE_PURGING</option>
										</select>
								</div>
							</div> -->
						</div>
						
						</div>
						*/?>
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button class="btn btn-success" type="submit">Save</button>
								<a href="{baseurl}do/panel/sensor.page?equipement=<?php echo $obj->id?>" class="btn btn-info">List of Sensors</a>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
