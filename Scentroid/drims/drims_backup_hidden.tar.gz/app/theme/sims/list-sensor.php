
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<a href="{baseurl}do/panel/sensor.add?equipement=<?php echo $equipement->id?>" class="btn btn-large pull-right btn-success">Add New Sensor</a>
				<div class="box-header"><span>Sensor List for <?php echo $equipement->name ?> - <?php echo userManager::getUser()->getCompany()->name?></span></div>
				<input type="hidden" id="equipement" value="<?php echo $equipement->id?>">
				<div class="box-content">
					<div class="flip-scroll">
						<div class="form-group">
							<label for="" class="control-label col-sm-2">Date Created:</label>
							<div class="col-sm-6">
								<div class="row">
									<div class="col-xs-6">
										<div class='input-group date' id='mindate'>
										<input type='text' class="form-control" name="date"   placeholder="from"  />
										<span class="input-group-addon">
											<span class="fa fa-calendar"></span>
										</span>
									</div>
									</div>
									<div class="col-xs-6">
										<div class='input-group date' id='maxdate'>
										<input type='text' class="form-control" name="date"   placeholder="to"  />
										<span class="input-group-addon">
											<span class="fa fa-calendar"></span>
										</span>
									</div>
									</div>
									
								</div>
							</div>
						</div>
						<table id="sensor-list" class="data-table table table-striped table-bordered">
						    <thead>
						        <tr>
						            <th>Name</th>
						            <th>Packet ID</th>
						            <th>Type</th>
   						            <th>Data Unit</th>
   						            <th>Created at</th>
						            <th>Actions</th>
						        </tr>
						    </thead>
						 
						    <tfoot>
						         <tr>
						            <th>Name</th>
						            <th>Packet ID</th>
						            <th>Type</th>
   						            <th>Data Unit</th>
   						            <th>Created at</th>
						            <th>Actions</th>
						        </tr>
						    </tfoot>
						 
						    <tbody>
					
						    </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
