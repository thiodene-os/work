
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span><?php echo $obj ? "Edit": "Add New Odour Concentration";?> Sample  for <?php echo $equipement->name?></span>
				<a class="btn-success btn" href="{baseurl}do/panel/sample.pagemanual?id=<?php echo $equipement->id?>">List</a>
				</div>
				<div class="box-content">
					<form action="{baseurl}do/panel/sample.save" method="POST" class="form-horizontal">
						
						<input type="hidden" name="equipement"  id="equipement" value="<?php echo $equipement->id?>">
						
					
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Value:</label>
							<div class="col-sm-6">
								<input name="value" id="" type="text" class="form-control"  value="<?php echo $obj->value ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Date:</label>
							<div class="col-sm-3">
								<select class="form-control"  name="dateOfSample" id="dateOfSample">
									<option disabled>Choose a date</option>
									<?php foreach($pidSamplesDates as $time => $date){?>
										<option value="<?php echo $time?>"><?php echo $date?></option>
									<?php } ?>
								</select>
							</div>
							<div class="col-sm-3">
								<select class="form-control"  name="date" id="timeOfSample">
										<option disabled>First choose the date</option>
								</select>
							</div>
						</div>
						
						<?php /*
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Date:</label>
							<div class="col-sm-6">
								<div class='input-group date' id='datetimepicker'>
									<input type='text' class="form-control" name="date" value="<?php echo $obj->sampledat ?$obj->sampledat:time() ?>" />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
								</div>
							</div>
						</div>
						*/?>
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button class="btn btn-success" type="submit">Save</button>
								<?php if($sensor){?>
								<a class="btn btn-info" href="{baseurl}do/panel/sample.pagemanual?id=<?php echo $equipement->id ?>">List of Odour Concentration Samples for This Device</a>
								<?php }?>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
