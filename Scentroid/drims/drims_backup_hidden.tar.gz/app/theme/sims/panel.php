<?php if($equipement){?>
    <form class="form-inline" action="/do/panel/panel.showequipement?" >
        <input id="equipementId" type="hidden" name="id" value="<?php echo $equipement->id?>"/>
        <div class='form-group input-group date' id='mindate'>
            <input type='text' class="form-control" name="startDateParsed" value="<?php echo $startDateParsed?>"  placeholder="from"  />
            <span class="input-group-addon">
                        <span class="fa fa-calendar"></span>
                    </span>
        </div>

        <div class='form-group input-group' id='maxdate'>
            <input type='text' class="form-control" name="endDateParsed" value="<?php echo $endDateParsed?>"  placeholder="to"  />
            <span class="input-group-addon">
                        <span class="fa fa-calendar"></span>
                    </span>
        </div>
        <div class="form-group">
            <select name="location" class="form-control col-sm-8" >
                <?php  foreach($locations as $location) { ?>
                    <option <?php if($selectedLocation == $location) echo "selected"?>><?php echo $location ?></option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group" data-example-id="glyphicons-general">
            <div class="btn-toolbar" role="toolbar">
                <div class="btn-group">

                    <button type="submit" class="btn btn-primary" aria-label="Show">
                        <span class="glyphicon glyphicon-search" aria-hidden="true"></span>
                    </button>
                    <?php if($startDateParsed || $endDateParsed){?>
                        <a  class="btn btn-success" aria-label="Show Realtime Data" href="{baseurl}do/panel/panel.showequipement?id=<?php echo $equipement->id?>">
                            <span class="fa fa-play" aria-hidden="true"></span>
                        </a>
                    <?php }else{?>
                        <a  class="btn btn-success disabled" aria-label="Showing Realtime Data">
                            <span class="fa fa-circle-o-notch fa-spin" aria-hidden="true"></span>
                        </a>
                    <?php }?>

                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Device Data
                                <span class="caret"></span>
                            </button>
                            <ul class="dropdown-menu">
                                <li id="downloaddata">
                                    <a  href="#" aria-label="Download">
                                        <i class="glyphicon glyphicon-download" aria-hidden="true"></i> Download
                                    </a>
                                </li>
                                <?php if(userManager::hasRole(array("admin","manager"))){?>
                                <li id="deletedata"  >
                                    <a href="#"  aria-label="Delete">
                                        <i class="glyphicon glyphicon-trash" aria-hidden="true"></i> Delete
                                    </a>
                                </li>
                                <?php }?>
                            </ul>
                        </div>
                </div>
            </div>
        </div>
    </form>

<?php }?>

<?php if( false && $equipement ){?>
    <div class="row">
        <div class="col-sm-2">
            <div class="btn-group">
                <a href="{baseurl}do/panel/panel.showequipement?id=<?php echo $equipement->id?>" class="btn btn-success"><i class="fa fa-play"></i><span>Show Real-time Data</span></a>
                <?php //<a href="" class="btn btn-danger"><i class="fa fa-pause"></i><span>Pause</span></a> ?>
            </div>
        </div>
        <div class="col-sm-2 text-right">
            <p>Historical Data:</p>
        </div>
        <div class="col-sm-8">
            <div class="form-group">
                <div class="input-group">
					<span class="input-group-addon">
						<i class="fa fa-calendar"></i>
					</span>
                    <input id="sensor-datepicker" type="text" class="form-control">
                </div>
            </div>
        </div>
    </div>
<?php }?>
<div class="row">
    <div class="col-md-4">
        <div class="box">
            <div class="box-header"><span>Scentinal
                    <?php if(userManager::getUser()->extra->equipment_category && userManager::getUser()->extra->equipment_category[0]){
                        echo "(".implode(", ",userManager::getUser()->extra->equipment_category).")";
                    }
                    ?>
                    </span></div>
            <div id="equipements-box" class="box-content">
                <table class="table table-striped table-hover">
                    <tbody>
                    <?php for($i=0; $i<count($equipements);$i++){?>
                        <tr>
                            <td>
                                <i class="text-<?php echo $equipements[$i]->getStatus($locSample[$equipements[$i]->id]) ?> fa fa-circle fa-lg"  ></i>
                            </td>
                            <td>
                                <span><a href="{baseurl}do/panel/panel.showequipement?id=<?php echo $equipements[$i]->id?>"><?php echo $equipements[$i]->name?></a></span>
                            </td>
                            <td class="hidden">
                                <span><?php echo company::load($equipements[$i]->company)->name ?></span>
                            </td>
                            <td >
                                <span class="small">Last Sample: <?php echo ago($locSample[$equipements[$i]->id]->sampledat)  ?></span>
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-info dropdown-toggle" type="button" data-toggle="dropdown">
                                        <i class="fa fa-gears"></i>
                                        <i class="fa fa-sort-desc"></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a href="{baseurl}do/panel/log.page?equipement=<?php echo $equipements[$i]->id ?>"><i class="fa fa-list-alt"></i><span>Log</span></a></li>
                                        <li><a href="{baseurl}do/panel/panel.samples?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-eyedropper"></i><span>Samples</span></a></li>
                                        <?php if(userManager::hasRole(array("admin","manager"))){?>
                                            <li><a href="{baseurl}do/panel/equipement.settings?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-gear"></i><span>Settings</span></a></li>
                                        <?php }?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="box">
            <div class="box-header"><span>Map</span></div>
            <div class="box-content">
                <div id="sensor-map"></div>
            </div>
        </div>
    </div>
    <?php if($equipement) {?>
    <div class="col-md-4">
        <div class="box">
            <div class="box-header"><span>Weather - <?php echo $city?></span></div>
            <div id="weather-box" class="box-content">
                Loading...
            </div>
        </div>
    </div>
    <?php }?>
</div>
<?php if($equipement){?>
    <div class="row">
        <div class="col-md-12 box">
            <div class="box-header"><span>Temperature and Humidity</span></div>
            <div id="" class="box-content">
                <div class="row">
                    <div class="col-xs-4">
                        <b>Interior</b>
                    </div>
                    <?php if($sampleInteriorHumidity){?>
                        <div class="col-xs-4">
                            <div class="weather-feature" data-toggle="tooltip" title="Humidity">
                                <i class="wi wi-humidity"></i>
                                <span><?php echo $sampleInteriorHumidity->value ?></span>
                            </div>
                        </div>
                    <?php }?>
                    <?php if($sampleInteriorTemperature){?>
                        <div class="col-xs-4">
                            <div class="weather-feature" data-toggle="tooltip" title="Temperature">
                                <i class="wi wi-thermometer"></i>
                                <span><?php echo $sampleInteriorTemperature->value ?></span>
                            </div>
                        </div>
                    <?php }?>
                    <div class="col-xs-4">
                        <b>Exterior</b>
                    </div>
                    <?php if($sampleExteriorHumidity){?>
                        <div class="col-xs-4">
                            <div class="weather-feature" data-toggle="tooltip" title="Humidity">
                                <i class="wi wi-humidity"></i>
                                <span><?php echo $sampleExteriorHumidity->value ?></span>
                            </div>
                        </div>
                    <?php }?>
                    <?php if($sampleExteriorTemperature){ ?>
                        <div class="col-xs-4">
                            <div class="weather-feature" data-toggle="tooltip" title="Temperature">
                                <i class="wi wi-thermometer"></i>
                                <span><?php echo $sampleExteriorTemperature->value ?></span>
                            </div>
                        </div>
                    <?php }?>
                    <?php if(false && $sampleInteriorHumidity){?>
                        <div class="col-xs-6">
                            <div class="weather-feature" data-toggle="tooltip" title="Last Updated">
                                <span><?php echo $sampleInteriorHumidity ? d($sampleInteriorHumidity->createdat) : "-" ?></span>
                            </div>
                        </div>
                    <?php }?>
                </div>
            </div>
        </div>
    </div>
    <div class="row">

        <div class="col-md-12">
            <div class="box">
                <div class="box-header"><span>Scentinel: <?php echo $equipement->name?></span></div>
                <div class="box-content">
                    <div class="chart" id="chart-0"></div>
                </div>
            </div>
        </div>
        <div class="hide col-md-12">
            <div class="box">
                <div class="box-header"><span>Odour Concentration for <?php echo $equipement->name?></span> <span class="label label-danger">beta</span>

                    &nbsp;<a href="{baseurl}do/panel/sample.add?eq=<?php echo $equipement->id ?>" class="btn btn-success">+ Odour Concentration Sample</a>
                    &nbsp;<a href="{baseurl}do/panel/sample.exportmanualsample?id=<?php echo $equipement->id ?>" class="btn btn-success">Export All Samples</a>
                    <?php /*&nbsp;<a href="{baseurl}do/panel/sample.exportcalibrationvalues?id=<?php echo $equipement->id ?>" class="btn btn-success">Export Calibration Values</a> */?>

                </div>
                <div class="box-content">
                    <div class="chart" id="chart-oc"></div>
                </div>

            </div>
        </div>
        <?php if(! $hasWindSensor) { ?>
        <div class="col-md-12">
            <div class="box">
                <div class="box-header"><span>Wind</span>
                </div>
                <div class="box-content">
                    <div class="chart" id="chart-wind"></div>
                </div>

            </div>
        </div>
        <?php } ?>

        <?php for($i=0; $i<count($pidSensors);$i++){?>
            <div class="col-md-12 ">
                <div class="box">
                    <div class="box-header "><span ><?php echo $pidSensors[$i]->name?>
                            &nbsp;<a href="{baseurl}do/panel/sensor.alarm?sensor=<?php echo $pidSensors[$i]->id?>" class="btn btn-success">Alarm</a>

                            <?php if($pidSensors[$i]->type == "pid"){?>
                                <form class="form-inline" action="/do/panel/panel.showequipement?" >
					  <input type="hidden" name="id" value="<?php echo $equipement->id?>"/>
					  <input type="hidden" name="startDate" value="<?php echo $startDate?>"/>
					  <input type="hidden" name="endDate" value="<?php echo $endDate?>"/>
					  
					  <div class="form-group">
					  	<label>Gas Type <?php echo "- Selected: ".$gas?></label>
					  	<select class="form-control" name="gas">
					  	<?php foreach(sensor::$pids as $name => $value){?>
                            <option value="<?php echo $name?>" <?php echo $name==$gas ? "selected":""?>><?php echo $name?></option>
                        <?php }?>
					  	</select>  
					  
					  </div>
					  <button type="submit" class="btn btn-default">Show</button>
					</form>
                            <?php }?>
				</span>

                    </div>
                    <div class="box-content">
                        <div class="chart" id="chart-<?php echo $i+1?>"></div>
                        <?php if($lastSample[$pidSensors[$i]->id]){?>
                            <small>
                                <b>Last Sample:</b> <?php echo $lastSample[$pidSensors[$i]->id]->value ?> - <?php echo ago($lastSample[$pidSensors[$i]->id]->sampledat)  ?>
                            </small>
                        <?php }?>
                    </div>
                </div>
            </div>
        <?php }?>


    </div>
<?php }?>