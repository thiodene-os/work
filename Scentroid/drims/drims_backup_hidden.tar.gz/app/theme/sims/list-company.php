
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<a href="{baseurl}do/security/company.add" class="btn btn-large pull-right btn-success">Add New Company</a>
				<div class="box-header"><span>Company List</span></div>
				<div class="box-content">
					<div class="flip-scroll">
					
						<div class="form-group">
						<div class="row">
						<div class="col-sm-12">
								
								<div class="col-xs-4">
									<div class='input-group date' id='mindate'>
									<input type='text' class="form-control" name="date"   placeholder="from"  />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
								</div>
								</div>
								<div class="col-xs-4">
									<div class='input-group date' id='maxdate'>
									<input type='text' class="form-control" name="date"   placeholder="to"  />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
								</div>
								</div>
								
						</div>
						</div>
					</div>
					
						<table id="company-list" class="data-table table table-striped table-bordered">
						    <thead>
						        <tr>
						            <th>Name</th>
						            <th>Tel</th>
						            <th>Address</th>
						            <th>Created At</th>
						            <th>Actions</th>
						        </tr>
						    </thead>
						 
						    <tfoot>
						         <tr>
						            <th>Name</th>
						            <th>Tel</th>
						            <th>Address</th>
						            <th>Created At</th>
						            <th>Actions</th>
						        </tr>
						    </tfoot>
						 
						    <tbody>
						    <?php /*for($i=0; $i<count($companies); $i++){?>
						        <tr>
						            <td><?php echo $companies[$i]->name ?></td>
						            <td><?php echo $companies[$i]->tel ?></td>
						            <td><?php echo $companies[$i]->address ?></td>
						            <td><?php echo $companies[$i]->createdat ?></td>
						            <td>
						            	<a href="" class="btn btn-small">Delete</a>
            			            	<a href="" class="btn btn-small">Edit</a>
						            
						            </td>
						        </tr>
						      <?php }*/?>
						    </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
