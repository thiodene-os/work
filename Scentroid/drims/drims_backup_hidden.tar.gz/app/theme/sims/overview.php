
	
	<div class="row">
		<div class="col-md-6">
			<div class="box">
				<div class="box-header"><span>DRIMS</span></div>
				<div id="equipements-box" class="box-content">
					<table class="table table-striped table-hover">
						<tbody>
						<?php for($i=0; $i<count($equipements);$i++){?>
						<tr>
								<td>
									<i class="text-<?php echo $equipements[$i]->getStatus()?> fa fa-circle fa-lg"  ></i>
										
								</td>
								<td>
									<span><a href="{baseurl}do/panel/panel.showequipement?id=<?php echo $equipements[$i]->id?>"><?php echo $equipements[$i]->name?></a></span>									
								</td>
								<td>
									<span><?php echo company::load($equipements[$i]->company)->name ?></span>									
								</td>
								<td>
									<span>Last Sample: <?php echo ago($locSample[$equipements[$i]->id]->sampledat)  ?></span>
								</td>
								<td>
									<div class="dropdown">
										<button class="btn btn-info dropdown-toggle" type="button" data-toggle="dropdown">
											<i class="fa fa-gears"></i>
											<i class="fa fa-sort-desc"></i>
										</button>
										<ul class="dropdown-menu">
											<li><a href="{baseurl}do/panel/log.page?equipement=<?php echo $equipements[$i]->id ?>"><i class="fa fa-list-alt"></i><span>Log</span></a></li>
											<li><a href="{baseurl}do/panel/panel.samples?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-eyedropper"></i><span>Samples</span></a></li>
											<?php if(userManager::hasRole(array("admin","manager"))){?>
											<li><a href="{baseurl}do/panel/equipement.settings?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-gear"></i><span>Settings</span></a></li>
											<?php }?>
											<?php /*if($equipements[$i]->status == "active"){?>
											<li><a href="{baseurl}do/panel/equipement.deactive?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-toggle-off"></i><span>Deactive</span></a></li>
											<?php } else{?>
											<li><a href="{baseurl}do/panel/equipement.active?id=<?php echo $equipements[$i]->id ?>"><i class="fa fa-toggle-on"></i><span>Active</span></a></li>
											<?php } */?>
										</ul>
									</div>
								</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		
		<div class="col-md-6">
			<div class="box">
				<div class="box-header"><span>Map</span></div>
				<div class="box-content">
					<div id="sensor-map"></div>
				</div>
			</div>
		</div>
		
	</div>
	