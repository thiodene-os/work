
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header"><span><?php echo $obj ? "Edit": "Add New";?> Equipement  for <?php echo userManager::getUser()->getCompany()->name?></span></div>
				<div class="box-content">
					<form action="{baseurl}do/panel/equipement.save" method="POST" class="form-horizontal">
						<?php if($obj){?>
						<input type="hidden" name="id" value="<?php echo $obj->id?>">
						<?php } ?>
						
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Name:</label>
							<div class="col-sm-6">
								<input name="name" id="" type="text" class="form-control" value="<?php echo $obj->name ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">SN:</label>
							<div class="col-sm-6">
								<input name="sn" id="" type="text" class="form-control"  value="<?php echo $obj->sn ?>">
							</div>
						</div>
						<div class="form-group">
							<label for="phone" class="control-label col-sm-3">Status:</label>
							<div class="col-sm-6">
								<select name="status" class="form-control" >
									<option <?php echo $obj->status == "active" ? "selected": ""?> value="active">Active</option>
									<option <?php echo $obj->status == "deactive" ? "selected": ""?> value="deactive">Deactive</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="" class="control-label col-sm-3">Calibrate date:</label>
							<div class="col-sm-6">
								<div class='input-group date' id='datetimepicker'>
									<input type='text' class="form-control" name="calibratedate" value="<?php echo $obj->calibratedate?$obj->calibratedate:time() ?>" />
									<span class="input-group-addon">
										<span class="fa fa-calendar"></span>
									</span>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label for="phone" class="control-label col-sm-3">Company:</label>
							<div class="col-sm-6">
								<select name="company" class="form-control" >
									<?php for($i=0; $i<count($companies); $i++){?>
										<option value="<?php echo $companies[$i]->id ?>" <?php echo $companies[$i]->id==$obj->company? "selected": "" ?> ><?php echo $companies[$i]->name ?></option>
									<?php } ?>
									
								</select>
							</div>
							<a href="{baseurl}do/security/company.add" class="btn btn-success">Add Company</a>
						</div>
						<div class="form-group">
							<div class="col-sm-offset-3 col-sm-6">
								<button class="btn btn-success" type="submit">Save</button>
								<?php if($obj->id){?>
								<a class="btn btn-info" href="{baseurl}do/panel/equipement.settings?id=<?php echo $obj->id?>">Settings</a>
								<?php } ?>
								<?php if($obj){?>
								<a class="btn btn-info" href="{baseurl}do/panel/sample.pagemanual?id=<?php echo $obj->id ?>">List of Manual Samples for This Sensor</a>
								<?php }?>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
