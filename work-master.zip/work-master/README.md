# work
Useful tips to use at work.

For back-end
Linux/Unix
Apache
PHP
XML

For front-end
HTML
CSS
Javascript
jQuery
Ajax
