<?php

require_once('/var/www/html/api_sync/includes/php/common.php');
require_once('/var/www/html/api_sync/includes/php/libs/lib_data.php');

echo buildJSONDataOutput() ;

?>
