# Main exectution files of the API in Python
CREATEs tables
INSERTs data
Sends to GOOGLE DRIVE
