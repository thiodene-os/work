<?php

require_once('/var/www/html/includes/php/common.php');
require_once('/var/www/html/includes/php/libs/lib_data.php');

echo buildJSONDataOutput() ;

?>
