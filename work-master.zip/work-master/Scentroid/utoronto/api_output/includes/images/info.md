# The images will have to be brought over to that folder
# And sent via JSON by name
