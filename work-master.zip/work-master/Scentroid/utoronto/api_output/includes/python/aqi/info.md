# execute main() if you want to have the AQI coming from the function calculate_aqi
# execute_class_aqi if class/object is preferred
