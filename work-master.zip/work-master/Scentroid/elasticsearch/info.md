# Comprehensive handling of JSON-style data to store and retrieve from the database

# Explained step by step in this tutorial:
https://www.tutorialspoint.com/elasticsearch/elasticsearch_installation.htm
