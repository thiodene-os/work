# All the libraries in PHP mostly list of functions
