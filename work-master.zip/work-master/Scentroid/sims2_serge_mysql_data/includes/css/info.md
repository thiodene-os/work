# CSS for the design of all the SIMS2.0 pages
