window.onload = function () 
{
  var chart = [] ;
  chart[1] = new CanvasJS.Chart("chartContainer1",
  {
    title:{
      text: "Removing and adding dataSeries Dynamically"
    },
    data: [
    {        
      type: "spline",
      dataPoints: [        
        { x: 10, y: 71 },
        { x: 20, y: 55 },
        { x: 30, y: 50 },
        { x: 40, y: 65 },
        { x: 50, y: 95 },
        { x: 60, y: 68 },
        { x: 70, y: 28 },
        { x: 80, y: 34 },
        { x: 90, y: 14 }
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 7 },
        { x: 20, y: 5 },
        { x: 30, y: 5 },
        { x: 40, y: 16 },
        { x: 50, y: 9 },
        { x: 60, y: 24 },
        { x: 70, y: 18 },
        { x: 80, y: 14 },
        { x: 90, y: 24 }      
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 44 },
        { x: 20, y: 25 },
        { x: 30, y: 41 },
        { x: 40, y: 6 },
        { x: 50, y: 29 },
        { x: 60, y: 54 },
        { x: 70, y: 12 },
        { x: 80, y: 74 },
        { x: 90, y: 29 }      
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 27 },
        { x: 20, y: 90 },
        { x: 30, y: 74 },
        { x: 40, y: 85 },
        { x: 50, y: 63 },
        { x: 60, y: 87 },
        { x: 70, y: 52 },
        { x: 80, y: 44 },
        { x: 90, y: 76 }      
      ]
    }
    ]
  });
  
  chart[1].render();
  
  chart[2] = new CanvasJS.Chart("chartContainer2",
  {
    title:{
      text: "Removing and adding dataSeries Dynamically"
    },
    data: [
    {        
      type: "spline",
      dataPoints: [        
        { x: 10, y: 90 },
        { x: 20, y: 80 },
        { x: 30, y: 70 },
        { x: 40, y: 60 },
        { x: 50, y: 50 },
        { x: 60, y: 40 },
        { x: 70, y: 30 },
        { x: 80, y: 20 },
        { x: 90, y: 10 }
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 10 },
        { x: 20, y: 20 },
        { x: 30, y: 30 },
        { x: 40, y: 40 },
        { x: 50, y: 50 },
        { x: 60, y: 60 },
        { x: 70, y: 70 },
        { x: 80, y: 80 },
        { x: 90, y: 90 }      
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 25 },
        { x: 20, y: 30 },
        { x: 30, y: 35 },
        { x: 40, y: 40 },
        { x: 50, y: 45 },
        { x: 60, y: 40 },
        { x: 70, y: 35 },
        { x: 80, y: 30 },
        { x: 90, y: 25 }      
      ]
    },
    {        
      type: "spline",        
      dataPoints: [
        { x: 10, y: 60 },
        { x: 20, y: 60 },
        { x: 30, y: 60 },
        { x: 40, y: 60 },
        { x: 50, y: 60 },
        { x: 60, y: 60 },
        { x: 70, y: 60 },
        { x: 80, y: 60 },
        { x: 90, y: 60 }      
      ]
    }
    ]
  });

  chart[2].render();
  
  // Remove one data points from the chart
  $(".remove").click(function()
  {
    // Confirm removing
    //if (! confirm("Do you really want to remove these data points?"))
    //  return false ;
    
    // Get the chart number for updated the right one
    chart_number = $(this).attr("chart") ;
  
    plot_number = $(this).attr("plot_number") ;
    if (plot_number == "")
      return false ;
    //alert(plot_number) ;
    chart[chart_number].data[plot_number].remove() ;
    
    // Now recalculate all the plots that were above the removed one!
    // And also give no number to the one that has been removed cause it can't be removed anymore...
    $(".remove").each(function()
    {
      plot_value = $(this).attr("plot_number") ;
      this_chart_number = $(this).attr("chart") ;
      //alert ("OK") ;
      
      if (this_chart_number == chart_number)
      {
        if (plot_value > plot_number)
        {
          //alert("case 1") ;
          $(this).attr("plot_number", plot_value - 1) ;
        }
        else if (plot_value == plot_number)
        {
          //alert("case 2") ;
          $(this).attr("plot_number", "") ;
        }
      }
    }) ;
    
    this_parent = $(this).parent() ;
    this_parent.find(".remove").hide() ;
    this_parent.find(".add").css('display', 'inline-block');
  
  }) ;
  
  
  // Add these new data points to the chart
  $(".add").click(function()
  {
    var not_plotted = true ;
    var series_to_plot = 0 ;
    // Confirm adding the data points
    //if (! confirm("Do you really want to add these data points?"))
    //  return false ;
    
    // Get the Chart number for altering the right one
    chart_number = $(this).attr("chart") ;
  
    series = $(this).attr("series") ;
    
    // Now check if the data series is already on the chart
    $(".remove").each(function()
    {
      plot_value = $(this).attr("plot_number") ;
      plot_series = $(this).attr("series") ;
      this_chart_number = $(this).attr("chart") ;
      
      if (this_chart_number == chart_number)
      {
        // Verify its not already showing
        if (plot_series == series && plot_value != "")
        {
          //alert("These datapoints are already on the Chart!") ;
          not_plotted = false ;
          return false ;
        }
        else if (plot_series == series && plot_value == "")
          series_to_plot = plot_series ;
      }
        
    }) ;
    
    // If already plotted stop everything
    if (!not_plotted)
      return false ;
    // Now display the new datapoints after the very curve and update its remove plot_number
    // Check the highest number of actually plotted data points
    var new_plot_number = 0 ;
    var plot_exists = false ;
    $(".remove").each(function()
    {
      this_chart_number = $(this).attr("chart") ;
      if (this_chart_number == chart_number)
      {
        plot_number = $(this).attr("plot_number") ;
        if (plot_number.toString().length > 0)
        {
          plot_exists = true ;
          if (plot_number > new_plot_number)
            new_plot_number = plot_number ;
        }
      }
    }) ;
    
    // increment the plot number for a new curve and add it to the empty remove button
    if (plot_exists)
      new_plot_number++ ;
    //alert("series_to_plot" + series_to_plot) ;
    // add new plot number to the right remove button
    $(".remove").each(function()
    {
      this_chart_number = $(this).attr("chart") ;
      if (this_chart_number == chart_number)
      {
        series = $(this).attr("series") ;
        if (series == series_to_plot)
          $(this).attr("plot_number", new_plot_number) ;
      }
    }) ;
    
    this_parent = $(this).parent() ;
    this_parent.find(".add").hide() ;
    this_parent.find(".remove").css('display', 'inline-block') ;
    
    var type= "spline" ;
    var fillOpacity= .4;
    var dataPoints = addDataPointsToChart(chart_number, series_to_plot) ;
    
    // Display the result on the correct chart!
    chart[chart_number].options.data.push( {type: type, fillOpacity: fillOpacity, dataPoints: dataPoints} );
    chart[chart_number].render();
  }) ;
    
  // Adds comma to non-empty string
  function addDataPointsToChart(chart_number, series_to_plot)
  {
    // This function returns the Data Points to be plotted
    var dataPoints = [];
    if (chart_number == 1)
    {
      if (series_to_plot == 0)
      {
        dataPoints.push({ x: 10, y: 71 });
        dataPoints.push({ x: 20, y: 55 });
        dataPoints.push({ x: 30, y: 50 });
        dataPoints.push({ x: 40, y: 65 });
        dataPoints.push({ x: 50, y: 95 });
        dataPoints.push({ x: 60, y: 68 });
        dataPoints.push({ x: 70, y: 28 });
        dataPoints.push({ x: 80, y: 34 });
        dataPoints.push({ x: 90, y: 14 });          
      }
      else if (series_to_plot == 1)
      {
        dataPoints.push({ x: 10, y: 7 });
        dataPoints.push({ x: 20, y: 5 });
        dataPoints.push({ x: 30, y: 5 });
        dataPoints.push({ x: 40, y: 16 });
        dataPoints.push({ x: 50, y: 9 });
        dataPoints.push({ x: 60, y: 24 });
        dataPoints.push({ x: 70, y: 18 });
        dataPoints.push({ x: 80, y: 14 });
        dataPoints.push({ x: 90, y: 24 });      
      }
      else if (series_to_plot == 2)
      {
        dataPoints.push({ x: 10, y: 44 });
        dataPoints.push({ x: 20, y: 25 });
        dataPoints.push({ x: 30, y: 41 });
        dataPoints.push({ x: 40, y: 6 });
        dataPoints.push({ x: 50, y: 29 });
        dataPoints.push({ x: 60, y: 54 });
        dataPoints.push({ x: 70, y: 12 });
        dataPoints.push({ x: 80, y: 74 });
        dataPoints.push({ x: 90, y: 29 });
      }
      else if (series_to_plot == 3)
      {
        dataPoints.push({ x: 10, y: 27 });
        dataPoints.push({ x: 20, y: 90 });
        dataPoints.push({ x: 30, y: 74 });
        dataPoints.push({ x: 40, y: 85 });
        dataPoints.push({ x: 50, y: 63 });
        dataPoints.push({ x: 60, y: 87 });
        dataPoints.push({ x: 70, y: 52 });
        dataPoints.push({ x: 80, y: 44 });
        dataPoints.push({ x: 90, y: 76 });
      }
    }
    else if (chart_number == 2)
    {
      if (series_to_plot == 0)
      {
        dataPoints.push({ x: 10, y: 90 });
        dataPoints.push({ x: 20, y: 80 });
        dataPoints.push({ x: 30, y: 70 });
        dataPoints.push({ x: 40, y: 60 });
        dataPoints.push({ x: 50, y: 50 });
        dataPoints.push({ x: 60, y: 40 });
        dataPoints.push({ x: 70, y: 30 });
        dataPoints.push({ x: 80, y: 20 });
        dataPoints.push({ x: 90, y: 10 });          
      }
      else if (series_to_plot == 1)
      {
        dataPoints.push({ x: 10, y: 10 });
        dataPoints.push({ x: 20, y: 20 });
        dataPoints.push({ x: 30, y: 30 });
        dataPoints.push({ x: 40, y: 40 });
        dataPoints.push({ x: 50, y: 50 });
        dataPoints.push({ x: 60, y: 60 });
        dataPoints.push({ x: 70, y: 70 });
        dataPoints.push({ x: 80, y: 80 });
        dataPoints.push({ x: 90, y: 90 });      
      }
      else if (series_to_plot == 2)
      {
        dataPoints.push({ x: 10, y: 25 });
        dataPoints.push({ x: 20, y: 30 });
        dataPoints.push({ x: 30, y: 35 });
        dataPoints.push({ x: 40, y: 40 });
        dataPoints.push({ x: 50, y: 45 });
        dataPoints.push({ x: 60, y: 40 });
        dataPoints.push({ x: 70, y: 35 });
        dataPoints.push({ x: 80, y: 30 });
        dataPoints.push({ x: 90, y: 25 });
      }
      else if (series_to_plot == 3)
      {
        dataPoints.push({ x: 10, y: 60 });
        dataPoints.push({ x: 20, y: 60 });
        dataPoints.push({ x: 30, y: 60 });
        dataPoints.push({ x: 40, y: 60 });
        dataPoints.push({ x: 50, y: 60 });
        dataPoints.push({ x: 60, y: 60 });
        dataPoints.push({ x: 70, y: 60 });
        dataPoints.push({ x: 80, y: 60 });
        dataPoints.push({ x: 90, y: 60 });
      }
    }
    return dataPoints ;
  } // addDataPointsToChart
  
}