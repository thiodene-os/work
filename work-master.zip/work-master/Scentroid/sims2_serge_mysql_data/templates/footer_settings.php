</div>
</div>

<script src="/includes/javascript/doubletaptogo.js"></script>

<script src="/includes/javascript/open_section.js"></script>

<script>
	$( function()
	{
		$( '#sidebar li:has(ul)' ).doubleTapToGo();
	});
</script>
<script src="/includes/javascript/back_to_top.js"></script>

</body>
</html>

<?php
ob_end_flush();
?>