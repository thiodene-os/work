# All the active templates for the Sims2.0 page
