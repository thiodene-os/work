# Everything related to sims API
- from Documentation to API
# Rotation 2D and 3D from formula
https://www.siggraph.org/education/materials/HyperGraph/modeling/mod_tran/2drota.htm
