<?php

// Use the customer ID to pass the user info to the payment process
$params['customer_id'] = #_GET#['customer_id'] ;

?>
