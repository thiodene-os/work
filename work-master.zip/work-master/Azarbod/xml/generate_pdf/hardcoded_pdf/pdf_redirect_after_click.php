# For javascript handle of button click

// Add other details from Inventory Count
$params['print_page_path'] = buildHRef("","multi_purpose_not_rendered") ;
