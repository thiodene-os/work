# PDF Forms
This Section shows you how to generate a PDF forms Softcoded or Hardcoded
From the HTML button handled with Javascript to the XML-PHP populated form
